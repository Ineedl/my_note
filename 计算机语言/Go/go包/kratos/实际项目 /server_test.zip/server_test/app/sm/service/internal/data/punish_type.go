package data

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	"strconv"
)

type punishTypeRepo struct {
	data *Data
	log  *log.Helper
}

func NewPunishTypeRepo(data *Data, logger log.Logger) biz.PunishTypeRepo {
	return &punishTypeRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}
func (this *punishTypeRepo) CreatePunishType(ctx context.Context, fr *v1.PunishType) (*v1.PunishType, error) {
	frModel := this.tranProtocToModel(fr)
	err := this.data.genQ.AppPunishType.WithContext(ctx).Create(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *punishTypeRepo) UpdatePunishType(ctx context.Context, fr *v1.PunishType) (*v1.PunishType, error) {
	q := this.data.genQ.AppPunishType
	frModel := this.tranProtocToModel(fr)
	_, err := q.WithContext(ctx).Where(q.ID.Eq(frModel.ID)).Updates(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *punishTypeRepo) DeletePunishType(ctx context.Context, id int32) error {
	q := this.data.genQ.AppPunishType
	_, err := q.WithContext(ctx).Where(q.ID.Eq(id)).Delete()
	if err != nil {
		return err
	}
	return nil
}

func (this *punishTypeRepo) GetPunishTypeById(ctx context.Context, id int32) (*v1.PunishType, error) {
	q := this.data.genQ.AppPunishType
	out := &v1.PunishType{}
	model, err := q.WithContext(ctx).Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	out = this.tranModelToProtoc(model)
	return out, nil
}

func (this *punishTypeRepo) GetPunishTypeByIdWithDelete(ctx context.Context, id int32) (*v1.PunishType, error) {
	q := this.data.genQ.AppPunishType
	out := &v1.PunishType{}
	model, err := q.WithContext(ctx).Unscoped().Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	out = this.tranModelToProtoc(model)
	return out, nil
}

func (this *punishTypeRepo) GetPunishTypeList(ctx context.Context, uid int32) ([]*v1.PunishType, error) {
	q := this.data.genQ.AppPunishType
	out := make([]*v1.PunishType, 0)
	list, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(uid)).Or(q.MemberID.Eq(0))).Find()
	if err != nil {
		return nil, err
	}
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *punishTypeRepo) GetMemberPunishSumData(ctx context.Context, uid int32) ([]*v1.MemberPunishTotal, error) {
	q := this.data.genQ.AppPunishType
	out := make([]*v1.MemberPunishTotal, 0)
	err := q.WithContext(ctx).Select(q.PunishCount.Sum().As("punish_count_total"), q.PunishName, q.PunishUnit).Group(q.MemberID).Where(q.MemberID.Eq(uid)).Scan(&out)
	if err != nil {
		return nil, err
	}
	return out, nil
}
func (this *punishTypeRepo) tranProtocToModel(in *v1.PunishType) *model.AppPunishType {
	out := &model.AppPunishType{}
	out.ID = in.PunishTypeId
	out.PunishName = in.PunishName
	um, _ := strconv.ParseInt(in.PunishCount, 10, 32)
	out.PunishCount = int32(um)
	out.PunishUnit = in.PunishUnit
	out.MemberID = in.MemberId
	return out
}

func (this *punishTypeRepo) tranModelToProtoc(in *model.AppPunishType) *v1.PunishType {
	out := &v1.PunishType{}
	out.PunishTypeId = in.ID
	out.PunishName = in.PunishName
	out.PunishCount = fmt.Sprintf("%d", in.PunishCount)
	out.PunishUnit = in.PunishUnit
	out.MemberId = in.MemberID
	return out
}
