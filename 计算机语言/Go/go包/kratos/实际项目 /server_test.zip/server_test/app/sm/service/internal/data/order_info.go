package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
)

var _ biz.PayOrderInfoRepo = (*payOrderInfoRepo)(nil)

type payOrderInfoRepo struct {
	data *Data
	log  *log.Helper
}

func NewPayOrderInfoRepo(data *Data, logger log.Logger) biz.PayOrderInfoRepo {
	return &payOrderInfoRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data.order_info")),
	}
}

func (this *payOrderInfoRepo) CreateOrder(ctx context.Context, in *model.AppOrderInfo) (*model.AppOrderInfo, error) {
	q := this.data.genQ.AppOrderInfo
	err := q.WithContext(ctx).Create(in)
	if err != nil {
		return nil, err
	}
	return in, nil
}

func (this *payOrderInfoRepo) UpdatePayOrder(ctx context.Context, in *model.AppOrderInfo) error {
	q := this.data.genQ.AppOrderInfo
	_, err := q.WithContext(ctx).Updates(in)
	if err != nil {
		this.log.Error("UpdatePayOrder failed:", err, " update_info:", in)
		return err
	}
	return nil
}

func (this *payOrderInfoRepo) GetOrderInfoByOrderId(ctx context.Context, orderId string) (*model.AppOrderInfo, error) {
	q := this.data.genQ.AppOrderInfo
	model, err := q.WithContext(ctx).Where(q.OrderID.Eq(orderId)).First()
	if err != nil {
		return nil, err
	}
	return model, nil
}
