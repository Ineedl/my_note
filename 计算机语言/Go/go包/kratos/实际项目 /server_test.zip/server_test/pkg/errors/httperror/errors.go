package httperror

import "github.com/go-kratos/kratos/v2/errors"

var ErrAuthFail = errors.New(401, "Authentication failed", "Missing token or token incorrect")
var ErrNotEnoughBalance = errors.New(403, "Balance failed", "Not Enough Money")
