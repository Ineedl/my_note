package data

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.FriendsRelationsRepo = (*friendRelationsRepo)(nil)

type friendRelationsRepo struct {
	log  *log.Helper
	data *Data
}

func NewFriendsRelationsRepo(data *Data, logger log.Logger) biz.FriendsRelationsRepo {
	return &friendRelationsRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data.friends_relations")),
	}
}

func (this *friendRelationsRepo) CreateFriendRelations(ctx context.Context, fr *v1.FriendRelations) (*v1.FriendRelations, error) {
	frModel := this.tranProtocToModel(fr)
	err := this.data.genQ.AppFriendRelation.WithContext(ctx).Create(frModel)
	if err != nil {
		return nil, err
	}
	//addKey := fmt.Sprintf("friend_add_apply_%d", fr.UserBId)
	//sessionKey := fmt.Sprintf(service.UserSessionKey, fr.UserBId)
	//sessionId := this.data.rdb.Get(ctx, sessionKey).Val()
	//if sessionId != "" {
	//
	//	//this.ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeFriendApply, m)
	//}
	//m := &v1.ChatMessage{}
	//m.MessageType = service.MessageTypeFriendApply
	////this.publisher.PublishEventMsg(fr.UserBId, m)
	//this.sender.SendChatMessage(websocket.SessionID(sessionId), m)
	return this.tranModelToProtoc(frModel), nil
}

func (this *friendRelationsRepo) UpdateFriendRelation(ctx context.Context, fr *v1.FriendRelations) (*v1.FriendRelations, error) {
	q := this.data.genQ.AppFriendRelation
	frModel := this.tranProtocToModel(fr)
	_, err := q.WithContext(ctx).Where(q.ID.Eq(frModel.ID)).Updates(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

// 获取用户待处理的好友申请列表
func (this *friendRelationsRepo) GetMemberApplyList(ctx context.Context, mid int32) ([]*v1.FriendRelations, error) {
	q := this.data.genQ.AppFriendRelation
	list, err := q.WithContext(ctx).Where(q.UserBID.Eq(mid)).Find()
	if err != nil {
		return nil, err
	}
	r := make([]*v1.FriendRelations, 0)
	for _, v := range list {
		r = append(r, this.tranModelToProtoc(v))
	}
	return r, nil
}

func (this *friendRelationsRepo) GetMemberFriendRelationByAAndBid(ctx context.Context, aid int32, bid int32) (*v1.FriendRelations, error) {
	q := this.data.genQ.AppFriendRelation
	fr, err := q.WithContext(ctx).Where(q.UserAID.Eq(aid), q.UserBID.Eq(bid)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(fr), nil
}

func (this *friendRelationsRepo) GetFriendRelationById(ctx context.Context, id int32) (*v1.FriendRelations, error) {
	q := this.data.genQ.AppFriendRelation
	fr, err := q.WithContext(ctx).Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(fr), nil
}

func (this *friendRelationsRepo) FriendIdsByUserId(ctx context.Context, userId int32) ([]int32, error) {
	q := this.data.genQ.AppFriendRelation
	idList := make([]int32, 0)
	err := q.WithContext(ctx).Where(q.UserAID.Eq(userId)).Where(q.Status.Eq(1)).Pluck(q.UserBID, &idList)
	if err != nil {
		return nil, err
	}
	return idList, nil
}

func (this *friendRelationsRepo) DeleteFriendRelation(ctx context.Context, userId int32, frid int32) error {
	q := this.data.genQ.AppFriendRelation
	c, err := q.WithContext(ctx).Where(q.UserAID.Eq(userId), q.UserBID.Eq(frid)).Or(q.UserBID.Eq(userId), q.UserAID.Eq(frid)).Unscoped().Delete()
	if c.RowsAffected == 0 {
		return fmt.Errorf("删除失败")
	}
	if err != nil {
		return err
	}
	return nil
}

func (this *friendRelationsRepo) GetMyFriendIsShowLocation(ctx context.Context, userId int32, frid int32) (int32, error) {
	q := this.data.genQ.AppFriendRelation
	relation, err := q.WithContext(ctx).Where(q.UserAID.Eq(frid), q.UserBID.Eq(userId)).First()
	if err != nil {
		return 0, err
	}
	return relation.ShowLocation, nil
}

func (this *friendRelationsRepo) tranModelToProtoc(in *model.AppFriendRelation) *v1.FriendRelations {
	out := &v1.FriendRelations{}
	out.ApplyId = in.ID
	out.Status = in.Status
	out.UserAAttribute = in.UserAAttribute
	out.UserAId = in.UserAID
	out.UserBAttribute = in.UserBAttribute
	out.UserBId = in.UserBID
	out.ApplyTime = in.ApplyTime
	out.Remark = in.Remark
	out.ShowLocation = in.ShowLocation
	return out
}

func (this *friendRelationsRepo) tranProtocToModel(in *v1.FriendRelations) *model.AppFriendRelation {
	out := &model.AppFriendRelation{}
	out.ID = in.ApplyId
	out.Status = in.Status
	out.UserAAttribute = in.UserAAttribute
	out.UserAID = in.UserAId
	out.UserBAttribute = in.UserBAttribute
	out.UserBID = in.UserBId
	out.ApplyTime = in.ApplyTime
	out.Remark = in.Remark
	out.ShowLocation = in.ShowLocation
	return out
}
