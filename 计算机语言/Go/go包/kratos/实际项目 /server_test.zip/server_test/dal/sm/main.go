package main

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gen"
	"gorm.io/gorm"
)

const dsn = "root:Zxc563221659.@tcp(127.0.0.1:3306)/miyou?charset=utf8mb4&parseTime=True&loc=Local"

type FindQuery interface {
	// SELECT * FROM @@table WHERE @@column=@value
	FilterWithColumn(column string, value string) (gen.T, error)
	// SELECT * FROM @@table WHERE id=@id
	GetByID(id int) (*gen.T, error) // returns struct and error
}

func main() {
	db, err := gorm.Open(mysql.Open(dsn))
	if err != nil {
		panic(fmt.Errorf("cannot establish db connection: %w", err))
	}
	// 生成实例
	g := gen.NewGenerator(gen.Config{
		OutPath:      "./orm/dal",
		ModelPkgPath: "./orm/model",
		Mode:         gen.WithDefaultQuery | gen.WithoutContext,
		// 表字段可为 null 值时, 对应结体字段使用指针类型
		//FieldNullable: true, // generate pointer when field is nullable

		// 表字段默认值与模型结构体字段零值不一致的字段, 在插入数据时需要赋值该字段值为零值的, 结构体字段须是指针类型才能成功, 即`FieldCoverable:true`配置下生成的结构体字段.
		// 因为在插入时遇到字段为零值的会被GORM赋予默认值. 如字段`age`表默认值为10, 即使你显式设置为0最后也会被GORM设为10提交.
		// 如果该字段没有上面提到的插入时赋零值的特殊需要, 则字段为非指针类型使用起来会比较方便.
		FieldCoverable: false, // generate pointer when field has default value, to fix problem zero value cannot be assign: https://gorm.io/docs/create.html#Default-Values

		// 模型结构体字段的数字类型的符号表示是否与表字段的一致, `false`指示都用有符号类型
		FieldSignable: false, // detect integer field's unsigned type, adjust generated data type
		// 生成 gorm 标签的字段索引属性
		FieldWithIndexTag: false, // generate with gorm index tag
		// 生成 gorm 标签的字段类型属性
		FieldWithTypeTag: true, // generate with gorm column type tag
	})
	// 设置目标 db
	g.UseDB(db)

	// 自定义字段的数据类型
	// 统一数字类型为int64,兼容protobuf
	dataMap := map[string]func(detailType string) (dataType string){
		"tinyint":   func(detailType string) (dataType string) { return "int32" },
		"smallint":  func(detailType string) (dataType string) { return "int32" },
		"mediumint": func(detailType string) (dataType string) { return "int32" },
		"bigint":    func(detailType string) (dataType string) { return "int64" },
		"int":       func(detailType string) (dataType string) { return "int32" },
	}
	// 要先于`ApplyBasic`执行
	g.WithDataTypeMap(dataMap)

	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_identity_verify"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_immediate_command"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_member"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_ipa_pay"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_friend_relations"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_member_online_status"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_user_location_log"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_task"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_task_type"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_punish_type"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_task_detail"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_active"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_active_join_member"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_active_remove_member"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_iap_order"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_ipa_pay"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_app_config"))
	g.ApplyInterface(func(FindQuery) {}, g.GenerateModel("app_order_info"))
	g.Execute()

}
