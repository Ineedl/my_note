package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.MemberOnlineStatusRepo = (*memberOnlineStatusRepo)(nil)

type memberOnlineStatusRepo struct {
	data *Data
	log  *log.Helper
}

func NewMemberOnlineStatusRepo(data *Data, logger log.Logger) biz.MemberOnlineStatusRepo {
	return &memberOnlineStatusRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *memberOnlineStatusRepo) UserUpLoadOnlineStatus(ctx context.Context, in *v1.MemberOnlineStatus) error {
	q := this.data.genQ.AppMemberOnlineStatus
	m := this.tranProtocToModel(in)
	c, err := q.WithContext(ctx).Where(q.MemberID.Eq(m.MemberID)).Count()
	if err != nil {
		return err
	}
	if c > 0 {
		_, err := q.WithContext(ctx).Where(q.MemberID.Eq(m.MemberID)).Updates(m)
		if err != nil {
			return err
		}
	} else {
		err := q.WithContext(ctx).Create(m)
		if err != nil {
			return err
		}
	}
	return nil
}

func (this *memberOnlineStatusRepo) GetUserOnlineStatusListByIds(ctx context.Context, userIds []int32) ([]*v1.MemberOnlineStatus, error) {
	q := this.data.genQ.AppMemberOnlineStatus
	list, err := q.WithContext(ctx).Where(q.MemberID.In(userIds...)).Find()
	if err != nil {
		return nil, err
	}
	out := make([]*v1.MemberOnlineStatus, 0)
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *memberOnlineStatusRepo) GetMemberOnlineStatusByMemberId(ctx context.Context, userId int32) (*v1.MemberOnlineStatus, error) {
	q := this.data.genQ.AppMemberOnlineStatus
	m, err := q.WithContext(ctx).Where(q.MemberID.Eq(userId)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}

func (this *memberOnlineStatusRepo) UserOnLine(ctx context.Context, userId int32) error {
	q := this.data.genQ.AppMemberOnlineStatus
	member := this.data.genQ.AppMember
	memberInfo, err := member.WithContext(ctx).Where(member.ID.Eq(userId)).First()
	if err != nil {
		return err
	}
	_, err = q.WithContext(ctx).Where(q.MemberID.Eq(userId)).Updates(&model.AppMemberOnlineStatus{
		IsOnline:  1,
		NickName:  memberInfo.NickName,
		AvatarURL: memberInfo.AvatarURL,
	})
	if err != nil {
		return err
	}
	return nil
}

func (this *memberOnlineStatusRepo) UserOffLine(ctx context.Context, userId int32) error {
	q := this.data.genQ.AppMemberOnlineStatus
	_, err := q.WithContext(ctx).Where(q.MemberID.Eq(userId)).Updates(&model.AppMemberOnlineStatus{
		IsOnline: -1,
	})
	if err != nil {
		return err
	}
	return nil
}

func (this *memberOnlineStatusRepo) tranModelToProtoc(in *model.AppMemberOnlineStatus) *v1.MemberOnlineStatus {
	out := &v1.MemberOnlineStatus{}
	out.UserId = in.MemberID
	out.DeviceName = in.DeviceName
	out.NickName = in.NickName
	out.BatteryStatus = in.BatteryStatus
	out.BatteryLevel = in.BatteryLevel
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.IsOnline = in.IsOnline
	out.StayTime = in.StayTime
	out.AvatarUrl = in.AvatarURL
	out.Wifi = in.Wifi
	return out
}

func (this *memberOnlineStatusRepo) tranProtocToModel(in *v1.MemberOnlineStatus) *model.AppMemberOnlineStatus {
	out := &model.AppMemberOnlineStatus{}
	out.MemberID = in.UserId
	out.DeviceName = in.DeviceName
	out.NickName = in.NickName
	out.BatteryStatus = in.BatteryStatus
	out.BatteryLevel = in.BatteryLevel
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.IsOnline = in.IsOnline
	out.StayTime = in.StayTime
	out.AvatarURL = in.AvatarUrl
	out.Wifi = in.Wifi
	return out
}
