package biz

import (
	"context"
	"errors"
	"github.com/go-kratos/kratos/v2/log"
	v1 "miyou/gen/api/sm/service/v1"
)

type TaskTypeRepo interface {
	CreateTaskType(ctx context.Context, fr *v1.TaskType) (*v1.TaskType, error)
	UpdateTaskType(ctx context.Context, fr *v1.TaskType) (*v1.TaskType, error)
	DeleteTaskType(ctx context.Context, id int32) error
	GetTaskTypeList(ctx context.Context, uid int32) ([]*v1.TaskType, error)
	GetTaskTypeById(ctx context.Context, id int32) (*v1.TaskType, error)
	GetTaskTypeByIdWithDelete(ctx context.Context, id int32) (*v1.TaskType, error)
}

type PunishTypeRepo interface {
	CreatePunishType(ctx context.Context, fr *v1.PunishType) (*v1.PunishType, error)
	UpdatePunishType(ctx context.Context, fr *v1.PunishType) (*v1.PunishType, error)
	DeletePunishType(ctx context.Context, id int32) error
	GetPunishTypeById(ctx context.Context, id int32) (*v1.PunishType, error)
	GetPunishTypeList(ctx context.Context, uid int32) ([]*v1.PunishType, error)
	GetPunishTypeByIdWithDelete(ctx context.Context, id int32) (*v1.PunishType, error)
	GetMemberPunishSumData(ctx context.Context, uid int32) ([]*v1.MemberPunishTotal, error)
}

type TaskRepo interface {
	CreateTask(ctx context.Context, fr *v1.Task) (*v1.Task, error)
	GetTaskList(ctx context.Context, uid int32, request *v1.GetTaskListRequest) ([]*v1.Task, error)
	GetTaskById(ctx context.Context, id int32) (*v1.Task, error)
	UpdateTask(ctx context.Context, fr *v1.Task) (*v1.Task, error)
	GetTaskDays(ctx context.Context, uid int32, mid int32) ([]string, error)
	GetTaskPunishList(ctx context.Context, uid int32, request *v1.GetTaskPunishListRequest) ([]*v1.Task, error)
	DeleteTask(ctx context.Context, id int32) error
	GetInProgressTaskList(ctx context.Context, memberId int32, carryMemberId int32) ([]*v1.Task, error)
	NotCompletedTask(ctx context.Context, memberId int32, carryMemberId int32) (int64, error)
	GetTotalTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error)
	GetCompletedTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error)
	GetInProgressTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error)
}

type TaskDetailRepo interface {
	GetTaskDetailList(ctx context.Context, taskId int32) ([]*v1.TaskDetail, error)
	CreateTaskDetail(ctx context.Context, fr *v1.TaskDetail) (*v1.TaskDetail, error)
	GetTaskDetailByDay(ctx context.Context, taskId int32, day string) (*v1.TaskDetail, error)
	GetTaskCompleteDayList(ctx context.Context, taskId int32) ([]string, error)
	DeleteTaskDetail(ctx context.Context, taskId int32) error
}

type TaskUseCase struct {
	log             *log.Helper
	taskTypeRepo    TaskTypeRepo
	memberTokenRepo MemberTokenRepo
	punishTypeRepo  PunishTypeRepo
	taskRepo        TaskRepo
	taskDetailRepo  TaskDetailRepo
}

func NewTaskUseCase(taskDetailRepo TaskDetailRepo, taskRepo TaskRepo, punishTypeRepo PunishTypeRepo, taskTypeRepo TaskTypeRepo, memberTokenRepo MemberTokenRepo, logger log.Logger) *TaskUseCase {
	return &TaskUseCase{
		memberTokenRepo: memberTokenRepo,
		taskTypeRepo:    taskTypeRepo,
		punishTypeRepo:  punishTypeRepo,
		taskRepo:        taskRepo,
		taskDetailRepo:  taskDetailRepo,
		log:             log.NewHelper(log.With(logger, "module", "task-service")),
	}
}

func (this *TaskUseCase) CreateTaskType(ctx context.Context, req *v1.CreateTaskTypeRequest) (*v1.CreateTaskTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	taskType := &v1.TaskType{}
	taskType.TaskName = req.TaskName
	taskType.TaskDes = req.TaskDes
	taskType.TaskTypeStartTime = req.TaskTypeStartTime
	taskType.TaskTypeEndTime = req.TaskTypeEndTime
	taskType.MemberId = int32(uid)
	taskType.TaskCycle = req.TaskCycle
	t, err := this.taskTypeRepo.CreateTaskType(ctx, taskType)
	if err != nil {
		return nil, err
	}
	return &v1.CreateTaskTypeResponse{
		TaskType: t,
	}, nil
}

func (this *TaskUseCase) UpdateTaskType(ctx context.Context, req *v1.UpdateTaskTypeRequest) (*v1.UpdateTaskTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	if req.TaskType.MemberId != int32(uid) {
		return nil, errors.New("参数错误")
	}
	t, err := this.taskTypeRepo.UpdateTaskType(ctx, req.TaskType)
	if err != nil {
		return nil, err
	}
	return &v1.UpdateTaskTypeResponse{
		TaskType: t,
	}, nil
}

func (this *TaskUseCase) DeleteTaskType(ctx context.Context, req *v1.DeleteTaskTypeRequest) (*v1.DeleteTaskTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	taskTypeInfo, err := this.taskTypeRepo.GetTaskTypeById(ctx, req.TaskTypeId)
	if err != nil {
		return nil, err
	}
	if taskTypeInfo.MemberId != int32(uid) {
		return nil, errors.New("参数错误")
	}
	err = this.taskTypeRepo.DeleteTaskType(ctx, req.TaskTypeId)
	if err != nil {
		return nil, err
	}
	return &v1.DeleteTaskTypeResponse{}, nil
}

func (this *TaskUseCase) GetTaskTypeList(ctx context.Context, req *v1.GetTaskTypeListRequest) (*v1.GetTaskTypeListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	taskTypeList, err := this.taskTypeRepo.GetTaskTypeList(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	return &v1.GetTaskTypeListResponse{
		TaskTypeList: taskTypeList,
	}, nil
}

func (this *TaskUseCase) CreatePunishType(ctx context.Context, req *v1.CreatePunishTypeRequest) (*v1.CreatePunishTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	p := &v1.PunishType{}
	p.MemberId = int32(uid)
	p.PunishName = req.PunishName
	p.PunishCount = req.PunishCount
	p.PunishUnit = req.PunishUnit
	_, err = this.punishTypeRepo.CreatePunishType(ctx, p)
	if err != nil {
		return nil, err
	}
	list, err := this.punishTypeRepo.GetPunishTypeList(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	result := make([]*v1.PunishType, len(list))
	for i, v := range list {
		result[i] = v
	}
	return &v1.CreatePunishTypeResponse{
		PunishType: result,
	}, nil
}

func (this *TaskUseCase) UpdatePunishType(ctx context.Context, req *v1.UpdatePunishTypeRequest) (*v1.UpdatePunishTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	if req.PunishType.MemberId != int32(uid) {
		return nil, errors.New("参数错误")
	}
	r, err := this.punishTypeRepo.UpdatePunishType(ctx, req.PunishType)
	if err != nil {
		return nil, err
	}
	return &v1.UpdatePunishTypeResponse{
		PunishType: r,
	}, nil
}

func (this *TaskUseCase) DeletePunishType(ctx context.Context, req *v1.DeletePunishTypeRequest) (*v1.DeletePunishTypeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	punishTypeInfo, err := this.punishTypeRepo.GetPunishTypeById(ctx, req.PunishTypeId)
	if err != nil {
		return nil, err
	}
	if punishTypeInfo.MemberId != int32(uid) {
		return nil, errors.New("参数错误")
	}
	err = this.punishTypeRepo.DeletePunishType(ctx, req.PunishTypeId)
	if err != nil {
		return nil, err
	}
	return &v1.DeletePunishTypeResponse{}, nil
}

func (this *TaskUseCase) GetPunishTypeList(ctx context.Context, req *v1.GetPunishTypeListRequest) (*v1.GetPunishTypeListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	punishTypeList, err := this.punishTypeRepo.GetPunishTypeList(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	return &v1.GetPunishTypeListResponse{
		PunishList: punishTypeList,
	}, nil
}

func (this *TaskUseCase) CreateTask(ctx context.Context, req *v1.CreateTaskRequest) (*v1.CreateTaskResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	task := &v1.Task{}
	task.TaskTypeId = req.TaskTypeId
	task.PunishTypeId = req.PunishTypeId
	task.TaskStartTime = req.TaskStartTime
	task.TaskEndTime = req.TaskEndTime
	task.CarryMemberId = req.CarryMemberId
	task.PunishStatus = req.PunishStatus
	task.TaskStatus = req.TaskStatus
	task.MemberId = int32(uid)
	task.TaskDes = req.TaskDes
	r, err := this.taskRepo.CreateTask(ctx, task)
	if err != nil {
		return nil, err
	}
	taskTypeInfo, _ := this.taskTypeRepo.GetTaskTypeByIdWithDelete(ctx, task.TaskTypeId)
	taskPunishInfo, _ := this.punishTypeRepo.GetPunishTypeByIdWithDelete(ctx, task.PunishTypeId)
	return &v1.CreateTaskResponse{
		Task:       r,
		TaskType:   taskTypeInfo,
		PunishType: taskPunishInfo,
	}, nil
}

func (this *TaskUseCase) GetTaskList(ctx context.Context, req *v1.GetTaskListRequest) (*v1.GetTaskListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	taskList, err := this.taskRepo.GetTaskList(ctx, int32(uid), req)
	if err != nil {
		return nil, err
	}
	result := make([]*v1.TaskListItem, len(taskList))
	for i, v := range taskList {
		v.DailyStatusList, _ = this.taskDetailRepo.GetTaskDetailList(ctx, v.TaskId)
		tmpTaskType, _ := this.taskTypeRepo.GetTaskTypeByIdWithDelete(ctx, v.TaskTypeId)
		tmpPunishType, _ := this.punishTypeRepo.GetPunishTypeByIdWithDelete(ctx, v.PunishTypeId)
		result[i] = &v1.TaskListItem{
			Task:       v,
			TaskType:   tmpTaskType,
			PunishType: tmpPunishType,
		}
	}
	return &v1.GetTaskListResponse{
		TaskList: result,
	}, nil
}

func (this *TaskUseCase) TaskSettlement(ctx context.Context, req *v1.TaskSettlementRequest) (*v1.TaskSettlementResponse, error) {
	//_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	//if err != nil {
	//	return nil, err
	//}
	task, err := this.taskRepo.GetTaskById(ctx, req.TaskId)
	if err != nil {
		return nil, err
	}
	if req.DailyStatusList != nil && len(req.DailyStatusList) > 0 {
		err = this.taskDetailRepo.DeleteTaskDetail(ctx, req.TaskId)
		for _, v := range req.DailyStatusList {
			v.TaskId = task.TaskId
			cData := &v1.TaskDetail{}
			cData.CompleteDay = v.CompleteDay
			cData.TaskId = task.TaskId
			cData.CarryMemberDone = v.CarryMemberDone
			cData.MemberConfirmed = v.MemberConfirmed
			_, err = this.taskDetailRepo.CreateTaskDetail(ctx, cData)
			if err != nil {
				return nil, err
			}
		}
	}

	if req.TaskStatus != 0 {
		task.TaskStatus = req.TaskStatus
	}

	if req.PunishStatus != 0 {
		task.PunishStatus = req.PunishStatus
	}

	if req.TaskEndTime != "" {
		task.TaskEndTime = req.TaskEndTime
	}

	task, err = this.taskRepo.UpdateTask(ctx, task)
	if err != nil {
		return nil, err
	}
	task.DailyStatusList, _ = this.taskDetailRepo.GetTaskDetailList(ctx, task.TaskId)
	taskTypeInfo, _ := this.taskTypeRepo.GetTaskTypeByIdWithDelete(ctx, task.TaskTypeId)
	taskPunishInfo, _ := this.punishTypeRepo.GetPunishTypeByIdWithDelete(ctx, task.PunishTypeId)
	return &v1.TaskSettlementResponse{
		Task:       task,
		TaskType:   taskTypeInfo,
		PunishType: taskPunishInfo,
	}, nil

}

func (this *TaskUseCase) GetMyDayTasks(ctx context.Context, req *v1.GetMyDayTasksRequest) (*v1.GetMyDayTasksResponse, error) {
	var u int32
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	u = int32(uid)
	var mid int32
	if req.UserId > 0 {
		mid = req.UserId
	}
	taskList, err := this.taskRepo.GetTaskDays(ctx, u, mid)
	if err != nil {
		return nil, err
	}
	return &v1.GetMyDayTasksResponse{
		Days: taskList,
	}, nil
}

func (this *TaskUseCase) GetTaskPunishList(ctx context.Context, req *v1.GetTaskPunishListRequest) (*v1.GetTaskPunishListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	taskList, err := this.taskRepo.GetTaskPunishList(ctx, int32(uid), req)
	if err != nil {
		return nil, err
	}
	result := make([]*v1.TaskListItem, len(taskList))
	for i, v := range taskList {
		v.DailyStatusList, _ = this.taskDetailRepo.GetTaskDetailList(ctx, v.TaskId)
		tmpTaskType, _ := this.taskTypeRepo.GetTaskTypeByIdWithDelete(ctx, v.TaskTypeId)
		tmpPunishType, _ := this.punishTypeRepo.GetPunishTypeByIdWithDelete(ctx, v.PunishTypeId)
		result[i] = &v1.TaskListItem{
			Task:       v,
			TaskType:   tmpTaskType,
			PunishType: tmpPunishType,
		}
	}
	return &v1.GetTaskPunishListResponse{
		TaskList: result,
	}, nil
}

func (this *TaskUseCase) DeleteTask(ctx context.Context, req *v1.DeleteTaskRequest) (*v1.DeleteTaskResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	task, err := this.taskRepo.GetTaskById(ctx, req.TaskId)
	if err != nil {
		return nil, err
	}
	if task.MemberId != int32(uid) && task.CarryMemberId != int32(uid) {
		return nil, errors.New("只能删除关于自己的任务")
	}
	err = this.taskRepo.DeleteTask(ctx, req.TaskId)
	if err != nil {
		return nil, err
	}
	err = this.taskDetailRepo.DeleteTaskDetail(ctx, req.TaskId)
	if err != nil {
		return nil, err
	}
	return &v1.DeleteTaskResponse{}, nil
}

func (this *TaskUseCase) GetTaskSummary(ctx context.Context, req *v1.GetTaskSummaryRequest) (*v1.GetTaskSummaryResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	memberId := int32(uid)
	if memberId != req.MemberId && memberId != req.CarryMemberId {
		return nil, errors.New("只能查看自己的任务")
	}
	taskList, err := this.taskRepo.GetInProgressTaskList(ctx, req.MemberId, req.CarryMemberId)
	if err != nil {
		return nil, err
	}
	resultTaskList := make([]*v1.TaskListItem, len(taskList))
	for i, v := range taskList {
		v.DailyStatusList, _ = this.taskDetailRepo.GetTaskDetailList(ctx, v.TaskId)
		tmpTaskType, _ := this.taskTypeRepo.GetTaskTypeByIdWithDelete(ctx, v.TaskTypeId)
		tmpPunishType, _ := this.punishTypeRepo.GetPunishTypeByIdWithDelete(ctx, v.PunishTypeId)
		resultTaskList[i] = &v1.TaskListItem{
			Task:       v,
			TaskType:   tmpTaskType,
			PunishType: tmpPunishType,
		}
	}
	completedTask, err := this.taskRepo.GetCompletedTaskCount(ctx, req.MemberId, req.CarryMemberId)
	if err != nil {
		return nil, err
	}
	notCompletedTask, err := this.taskRepo.NotCompletedTask(ctx, req.MemberId, req.CarryMemberId)
	if err != nil {
		return nil, err
	}
	totalTask, err := this.taskRepo.GetTotalTaskCount(ctx, req.MemberId, req.CarryMemberId)
	if err != nil {
		return nil, err
	}
	inProgressTask, err := this.taskRepo.GetInProgressTaskCount(ctx, req.MemberId, req.CarryMemberId)
	if err != nil {
		return nil, err
	}

	return &v1.GetTaskSummaryResponse{
		InTaskList:       resultTaskList,
		CompletedTask:    int32(completedTask),
		NotCompletedTask: int32(notCompletedTask),
		TotalTask:        int32(totalTask),
		InProgressTask:   int32(inProgressTask),
	}, nil
}
