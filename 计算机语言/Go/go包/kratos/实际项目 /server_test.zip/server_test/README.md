tame
