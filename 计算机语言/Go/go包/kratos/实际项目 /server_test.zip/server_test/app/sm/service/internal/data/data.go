package data

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/registry"
	"github.com/go-redis/redis/v8"
	_ "github.com/go-sql-driver/mysql"
	"github.com/google/wire"
	"github.com/tx7do/kratos-transport/broker"
	"github.com/tx7do/kratos-transport/broker/nsq"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"miyou/app/sm/service/internal/conf"
	"miyou/dal/sm/orm/dal"
	"miyou/pkg/util/bootstrap"
)

// ProviderSet is data providers.
var ProviderSet = wire.NewSet(
	NewData,
	NewMySql,
	NewRedis,
	NewGenQuery,
	NewDiscovery,

	NewMemberRepo,
	NewMemberTokenRepo,
	NewFriendsRelationsRepo,
	NewMemberOnlineStatusRepo,
	NewAliCommonRepo,
	NewUserLocationLogRepo,
	NewTaskTypeRepo,
	NewPunishTypeRepo,
	NewTaskRepo,
	NewActiveRepo,
	NewActiveJoinMemberRepo,
	NewActiveRemoveMemberRepo,
	NewTaskDetailRepo,
	NewTuiPushRepo,
	NewApplePayVerifier,
	NewApplePayConfig,
	NewIapOrderRepo,
	NewIapPayRepo,
	NewAppConfigRepo,
	NewNsqProducer,
)

// Data .
type Data struct {
	db   *gorm.DB
	log  *log.Helper
	rdb  *redis.Client
	genQ *dal.Query
}

func NewGenQuery(db *gorm.DB) *dal.Query {
	return dal.Use(db)
}

// NewData .
func NewData(logger log.Logger, genQ *dal.Query, db *gorm.DB, rdb *redis.Client) (*Data, func(), error) {
	cleanup := func() {
		log.NewHelper(logger).Info("closing the data resources")
	}
	l := log.NewHelper(log.With(logger, "module", "data/comment-service"))
	return &Data{rdb: rdb, genQ: genQ, db: db, log: l}, cleanup, nil
}

func NewMySql(c *conf.Bootstrap) *gorm.DB {
	db, err := gorm.Open(mysql.Open(c.Data.Database.Source), &gorm.Config{
		DisableForeignKeyConstraintWhenMigrating: true,
		SkipDefaultTransaction:                   true,
	})
	if err != nil {
		panic("failed to connect database")
	}
	return db
}

func NewNsqProducer(conf *conf.Bootstrap) broker.Broker {
	b := nsq.NewBroker(
		broker.WithAddress(conf.Nsq.NSQD_ADDR),
		broker.WithCodec("json"),
	)
	err := b.Init()
	if err != nil {
		fmt.Println("cant init broker, skip: %v", err)
	}
	err = b.Connect()
	if err != nil {
		fmt.Println("cant connect to broker, skip: %v", err)
	}
	return b
}

func NewRedis(logger log.Logger, c *conf.Bootstrap) *redis.Client {
	client := redis.NewClient(&redis.Options{
		Addr:     c.Data.Redis.Addr,
		Password: c.Data.Redis.Password, // no password set
		DB:       int(c.Data.Redis.Db),  // use default DB
	})
	//测试redis连接是否正常
	pong, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic("redis connect ping failed, err:")
	} else {
		log.NewHelper(logger).Info("redis connect ping response:", pong)
	}
	return client
}

// NewDiscovery 创建服务发现客户端
func NewDiscovery(conf *conf.Bootstrap) registry.Discovery {
	return bootstrap.NewEtcdRegistry([]string{conf.Registry.Etcd.Addr})
}
