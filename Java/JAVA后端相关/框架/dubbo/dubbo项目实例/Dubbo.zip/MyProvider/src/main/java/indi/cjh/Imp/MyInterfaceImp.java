package indi.cjh.Imp;

import indi.cjh.model.User;
import indi.cjh.outInterface.MyInterface;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

public class MyInterfaceImp implements MyInterface {
    public User getUserById(Integer id)
    {
        User tmp=new User();
        tmp.setId(id);
        tmp.setName("zhangsan");
        return tmp;
    }
}
