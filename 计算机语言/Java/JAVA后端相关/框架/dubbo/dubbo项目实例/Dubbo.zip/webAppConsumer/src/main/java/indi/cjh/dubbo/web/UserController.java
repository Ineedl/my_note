package indi.cjh.dubbo.web;

import indi.cjh.model.User;
import indi.cjh.service.SomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {

    @Autowired
    private SomeService someService;

    @RequestMapping(value="/user")
    public String userDetail(Model model , Integer id){
        User user = someService.queryUserById(id);
        model.addAttribute("user",user);
        return "userDetail";

    }
}
