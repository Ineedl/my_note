package utils

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"io"
	"math/rand"
	"os"
	"strings"
	"time"
)

const TimeFormat = "2006-01-02 15:04:05"

// 生成随机数
func GenValidateCode(width int) string {
	numeric := [10]byte{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
	r := len(numeric)
	rand.Seed(time.Now().UnixNano())

	var sb strings.Builder
	for i := 0; i < width; i++ {
		fmt.Fprintf(&sb, "%d", numeric[rand.Intn(r)])
	}
	return sb.String()
}

func GetNowDate() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

func GetMondayTimestamp() int64 {
	today := time.Now()
	weekday := today.Weekday()
	// Calculate the number of days to subtract to get to Monday (assuming Sunday is the first day of the week)
	daysToSubtract := int(weekday) - 1
	if weekday == time.Sunday {
		daysToSubtract = 6 // Sunday should be considered the last day of the week
	}
	// Calculate the timestamp for this week's Monday
	monday := today.AddDate(0, 0, -daysToSubtract)
	mondayTimestamp := time.Date(monday.Year(), monday.Month(), monday.Day(), 0, 0, 0, 0, today.Location()).Unix()
	return mondayTimestamp
}

func GetSunDayTimestamp() int64 {
	today := time.Now()
	weekday := today.Weekday()
	// Calculate the number of days to add to get to Sunday
	daysToAdd := 7 - int(weekday)
	// Calculate the timestamp for this week's Sunday
	sunday := today.AddDate(0, 0, daysToAdd)
	sundayTimestamp := time.Date(sunday.Year(), sunday.Month(), sunday.Day(), 23, 59, 59, 0, today.Location()).Unix()
	return sundayTimestamp
}

// 判断所给路径文件/文件夹是否存在

func FileExists(path string) bool {
	_, err := os.Stat(path) //os.Stat获取文件信息
	if err != nil {
		if os.IsExist(err) {
			return true
		}
		return false
	}
	return true
}

func StrToDate(str string) (time.Time, error) {
	time, err := time.ParseInLocation("2006-01-02", str, time.Local)
	if err != nil {
		return time, err
	}
	return time, err
}

func StrToDateTime(str string) (time.Time, error) {
	time, err := time.ParseInLocation("2006-01-02 15:04:05", str, time.Local)
	if err != nil {
		return time, err
	}
	return time, err
}

// 随机字符串
func GetRandomString(n int) string {
	str := "0123456789abcdefghijklmnopqrstuvwxyz"
	bytes := []byte(str)
	var result []byte
	for i := 0; i < n; i++ {
		result = append(result, bytes[rand.Intn(len(bytes))])
	}
	return string(result)
}

// 随机字数字
func GetRandomNumber(n int) string {
	str := "0123456789"
	bytes := []byte(str)
	var result []byte
	for i := 0; i < n; i++ {
		result = append(result, bytes[rand.Intn(len(bytes))])
	}
	return string(result)
}

// 订单规则
func MakeOrderNum() string {
	timeStr := time.Now().Format("200601021504")
	str := fmt.Sprintf("E3D%s%s", timeStr, GenValidateCode(6))
	return str
}

// 切片随机获取一个值
func RandSliceValue(xs []string) string {
	return xs[rand.Intn(len(xs))]
}

func FileMD5(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	hash := md5.New()
	_, _ = io.Copy(hash, file)
	return hex.EncodeToString(hash.Sum(nil)), nil
}

func MD5Str(str string) string {
	data := []byte(str)
	md5New := md5.New()
	md5New.Write(data)
	// hex转字符串
	md5String := hex.EncodeToString(md5New.Sum(nil))
	return md5String
}

// 转换interface到字符串
func FmtStrFromInterface(val interface{}) string {
	if val == nil {
		return ""
	}
	switch ret := val.(type) {
	case string:
		return ret
	case int8, uint8, int16, uint16, int, uint, int32, uint32, int64, uint64, float32, float64:
		return fmt.Sprintf("%v", ret)
	}
	return ""
}
