package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.IapPayRepo = (*iapPayRepo)(nil)

type iapPayRepo struct {
	data *Data
	log  *log.Helper
}

func NewIapPayRepo(data *Data, logger log.Logger) biz.IapPayRepo {
	return &iapPayRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data.iap_pay")),
	}
}

func (this *iapPayRepo) CreateIapPay(ctx context.Context, in *v1.IapPay) (*v1.IapPay, error) {
	out := this.tranProtocToModel(in)
	q := this.data.genQ.AppIpaPay
	err := q.WithContext(ctx).Create(out)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *iapPayRepo) GetIapPayByMemberId(ctx context.Context, memberId int32) (*v1.IapPay, error) {
	q := this.data.genQ.AppIpaPay
	out, err := q.WithContext(ctx).Where(q.MemberID.Eq(memberId)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *iapPayRepo) UpdateIapPay(ctx context.Context, in *v1.IapPay) (*v1.IapPay, error) {
	out := this.tranProtocToModel(in)
	q := this.data.genQ.AppIpaPay
	_, err := q.WithContext(ctx).Where(q.ID.Eq(out.ID)).Updates(out)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *iapPayRepo) tranProtocToModel(in *v1.IapPay) *model.AppIpaPay {
	out := &model.AppIpaPay{}
	out.ID = in.Id
	out.MemberID = in.MemberId
	out.Receipt = in.Receipt
	out.ResCode = in.ResCode
	out.TryTimes = in.TryTimes
	out.Status = in.Status
	return out
}

func (this *iapPayRepo) tranModelToProtoc(in *model.AppIpaPay) *v1.IapPay {
	out := &v1.IapPay{}
	out.Id = in.ID
	out.MemberId = in.MemberID
	out.Receipt = in.Receipt
	out.ResCode = in.ResCode
	out.TryTimes = in.TryTimes
	out.Status = in.Status
	return out
}
