package indi.cjh;

import indi.cjh.service.BuyGoodsService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        String config="beans.xml";
        ApplicationContext ctx=new ClassPathXmlApplicationContext(config);
        BuyGoodsService service=(BuyGoodsService) ctx.getBean("buyService");
        service.buy(1001,1000);
    }
}
