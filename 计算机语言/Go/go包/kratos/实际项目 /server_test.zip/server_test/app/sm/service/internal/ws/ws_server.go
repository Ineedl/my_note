package ws

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-redis/redis/v8"
	"github.com/google/wire"
	"github.com/tx7do/kratos-transport/transport/websocket"
	"miyou/app/sm/service/internal/biz"
	"miyou/app/sm/service/internal/conf"
	v1 "miyou/gen/api/sm/service/v1"
	"miyou/pkg/service"
	"net/url"
)

var ProviderSet = wire.NewSet(
	NewWsHandler,
)

type WsHandler struct {
	log                    *log.Helper
	redis                  *redis.Client
	conf                   *conf.Bootstrap
	frRepo                 biz.FriendsRelationsRepo
	memberTokenRepo        biz.MemberTokenRepo
	memberOnlineStatusRepo biz.MemberOnlineStatusRepo
	ws                     *websocket.Server
}

func NewWsHandler(
	logger log.Logger,
	redis *redis.Client,
	conf *conf.Bootstrap,
	fr biz.FriendsRelationsRepo,
	memberTokenRepo biz.MemberTokenRepo,
	memberOnlineStatus biz.MemberOnlineStatusRepo,
) *WsHandler {
	return &WsHandler{
		conf:                   conf,
		redis:                  redis,
		frRepo:                 fr,
		memberTokenRepo:        memberTokenRepo,
		memberOnlineStatusRepo: memberOnlineStatus,
		log:                    log.NewHelper(log.With(logger, "module", "ws-server/data/ws_handler")),
	}
}

func (this *WsHandler) SetWebsocketServer(ws *websocket.Server) {
	this.ws = ws
}
func (this *WsHandler) HandleChatMessage(sessionId websocket.SessionID, message *v1.ChatMessage) error {
	fmt.Printf("[%s] Payload: %v\n", sessionId, message)
	ctx := context.Background()
	switch message.MessageType {
	//心跳
	case service.MessageTypeHeartbeat:
		this.Heartbeat(ctx, sessionId)
		break
		//上报位置等信息
	case service.MessageTypeUploadUserDeviceInfo:
		this.UploadUserDeviceInfo(ctx, sessionId, message.DeviceInfo)
		break
		//获取活动列表
	case service.MessageGetActiveList:
		this.GetActiveUserSend(ctx, sessionId, message)
		break
	case service.MessageUploadPosition:
		this.UploadDevicePosition(ctx, sessionId, message.DevicePosition)
		break
	}
	return nil
}

func (this *WsHandler) HandleConnect(sessionId websocket.SessionID, queries url.Values, connect bool) {
	ctx := context.Background()
	if connect {
		fmt.Printf("[%s] connected [%+v]\n", sessionId, queries)
		//校验token
		token := queries["token"]
		if token == nil {
			m := &v1.ChatMessage{
				MessageType: -1,
			}
			this.ws.SendMessage(sessionId, service.MessageTypeChat, m)
			this.log.Error("no jwt token in context")
			return
		}
		//this.log.Debug("token", token[0])
		_, uid, err := this.memberTokenRepo.ParesTokenData(token[0])
		if err != nil {
			m := &v1.ChatMessage{
				MessageType: -1,
			}
			this.ws.SendMessage(sessionId, service.MessageTypeChat, m)
			return
		}
		this.UserOnline(ctx, uid, sessionId)
		//fmt.Printf("[%s] token: %s\n", sessionId, token)
	} else {
		this.UserOffline(ctx, sessionId)
		//fmt.Printf("[%s] disconnect\n", sessionId)
	}
}

// 用户上线将sessionId保存起来
func (this *WsHandler) UserOnline(ctx context.Context, userId int32, sessionId websocket.SessionID) {
	sid := string(sessionId)
	userSessionKey := fmt.Sprintf(service.UserSessionKey, userId)
	sessionUserKey := fmt.Sprintf(service.SessionUserKey, sid)
	err := this.redis.Set(ctx, userSessionKey, sid, 0).Err()
	if err != nil {
		this.log.Error(err)
	}
	err = this.redis.Set(ctx, sessionUserKey, userId, 0).Err()
	if err != nil {
		this.log.Error(err)
	}
	this.memberOnlineStatusRepo.UserOnLine(ctx, userId)
}

// 用户下线删除sessionId
func (this *WsHandler) UserOffline(ctx context.Context, sessionId websocket.SessionID) {
	sid := string(sessionId)
	sessionUserKey := fmt.Sprintf(service.SessionUserKey, sid)
	userId, err := this.redis.Get(ctx, sessionUserKey).Int()
	if err != nil {
		this.log.Error(err)
	}
	userSessionKey := fmt.Sprintf(service.UserSessionKey, userId)
	err = this.redis.Del(ctx, userSessionKey).Err()
	if err != nil {
		this.log.Error(err)
	}
	err = this.redis.Del(ctx, sessionUserKey).Err()
	if err != nil {
		this.log.Error(err)
	}
	this.memberOnlineStatusRepo.UserOffLine(ctx, int32(userId))
	//处理好友信息
	friendIds, err := this.frRepo.FriendIdsByUserId(ctx, int32(userId))
	if err != nil {
		this.log.Error(err)
		return
	}
	if len(friendIds) == 0 {
		this.log.Error("no friend")
		return
	}
	userStatus, err := this.memberOnlineStatusRepo.GetMemberOnlineStatusByMemberId(ctx, int32(userId))
	if err != nil {
		this.log.Error(err)
		return
	}
	userStatus.IsOnline = -1

	for _, friendId := range friendIds {
		friendSessionKey := fmt.Sprintf(service.UserSessionKey, friendId)
		friendSessionId, err := this.redis.Get(ctx, friendSessionKey).Result()
		if err != nil {
			this.log.Error(err)
			continue
		}

		m := &v1.ChatMessage{
			MessageType:  service.MessageTypeOffLine,
			Info:         "update user info",
			FriendStatus: userStatus,
		}
		this.ws.SendMessage(websocket.SessionID(friendSessionId), service.MessageTypeChat, m)
	}
}

func (this *WsHandler) GetActiveUserSend(ctx context.Context, sessionId websocket.SessionID, message *v1.ChatMessage) {
	uList, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, message.ActiveUidList)
	if err != nil {
		this.log.Error(err)
		return
	}
	this.ws.SendMessage(sessionId, service.MessageTypeChat, &v1.ChatMessage{
		MessageType: service.MessageGetActiveList,
		ActiveId:    message.ActiveId,
		Friend_List: uList,
	})
}

func (this *WsHandler) Heartbeat(ctx context.Context, sessionId websocket.SessionID) {
	m := &v1.ChatMessage{
		MessageType: 1,
		Info:        "ping",
	}
	this.ws.SendMessage(sessionId, service.MessageTypeChat, m)
}

func (this *WsHandler) UploadUserDeviceInfo(ctx context.Context, sessionId websocket.SessionID, deviceInfo *v1.DeviceInfo) {
	//this.log.Debug(deviceInfo)
	//用户上报信息
	userOnlineStatus := &v1.MemberOnlineStatus{
		UserId:           deviceInfo.UserId,
		DeviceName:       deviceInfo.DeviceName,
		NickName:         deviceInfo.NickName,
		BatteryStatus:    deviceInfo.BatteryStatus,
		BatteryLevel:     deviceInfo.BatteryLevel,
		IsOnline:         1,
		Latitude:         deviceInfo.Latitude,
		Longitude:        deviceInfo.Longitude,
		StayTime:         deviceInfo.StayTime,
		UnlockPhoneCount: deviceInfo.UnlockPhoneCount,
		ScreenUseTime:    deviceInfo.ScreenUseTime,
		Wifi:             deviceInfo.Wifi,
	}
	err := this.memberOnlineStatusRepo.UserUpLoadOnlineStatus(ctx, userOnlineStatus)
	if err != nil {
		this.log.Error(err)
		return
	}
	sid := string(sessionId)
	sessionUserKey := fmt.Sprintf(service.SessionUserKey, sid)
	userId, err := this.redis.Get(ctx, sessionUserKey).Int()
	if err != nil {
		this.log.Error(err)
		return
	}
	friendIds, err := this.frRepo.FriendIdsByUserId(ctx, int32(userId))
	if err != nil {
		this.log.Error(err)
		return
	}
	if len(friendIds) == 0 {
		this.log.Error("no friend")
		return
	}
	list, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, friendIds)
	m := &v1.ChatMessage{
		MessageType: service.MessageTypeFriendList,
		Info:        "update user info",
		Friend_List: list,
	}
	this.ws.SendMessage(sessionId, service.MessageTypeChat, m)

	//将用户的信息发送给好友
	//for _, friendId := range friendIds {
	//	friendSessionKey := fmt.Sprintf(service.UserSessionKey, friendId)
	//	friendSessionId, err := this.redis.Get(ctx, friendSessionKey).Result()
	//	if err != nil {
	//		this.log.Error(err)
	//		continue
	//	}
	//	m := &v1.ChatMessage{
	//		MessageType:  2,
	//		Info:         "update user info",
	//		FriendStatus: userOnlineStatus,
	//	}
	//	this.messageSender.SendChatMessage(websocket.SessionID(friendSessionId), service.MessageTypeChat, m)
	//}
	return
}

func (this *WsHandler) UploadDevicePosition(ctx context.Context, sessionId websocket.SessionID, position *v1.DevicePosition) {
	//this.log.Debug(position)
	sid := string(sessionId)
	sessionUserKey := fmt.Sprintf(service.SessionUserKey, sid)
	userId, err := this.redis.Get(ctx, sessionUserKey).Int()
	if err != nil {
		this.log.Error(err)
		return
	}
	//用户上报信息
	userOnlineStatus := &v1.MemberOnlineStatus{
		UserId:    int32(userId),
		Latitude:  position.Latitude,
		Longitude: position.Longitude,
	}
	err = this.memberOnlineStatusRepo.UserUpLoadOnlineStatus(ctx, userOnlineStatus)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}
