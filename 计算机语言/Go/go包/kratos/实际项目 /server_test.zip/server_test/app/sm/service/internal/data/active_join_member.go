package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
)

var _ biz.ActiveJoinMemberRepo = (*activeJoinMemberRepo)(nil)

type activeJoinMemberRepo struct {
	data *Data
	log  *log.Helper
}

func NewActiveJoinMemberRepo(data *Data, logger log.Logger) biz.ActiveJoinMemberRepo {
	return &activeJoinMemberRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *activeJoinMemberRepo) GetActiveJoinMemberIds(ctx context.Context, activeId int32) ([]int32, error) {
	type finds struct {
		ActiveID int32 `json:"active_id"`
		MemberID int32 `json:"member_id"`
	}

	var ids []finds
	q := this.data.genQ.AppActiveJoinMember
	err := q.WithContext(ctx).Select(q.ActiveID, q.MemberID).Where(q.ActiveID.Eq(activeId)).Scan(&ids)
	if err != nil {
		return nil, err
	}
	var res []int32
	for _, v := range ids {
		res = append(res, v.MemberID)
	}
	return res, nil
}

func (this *activeJoinMemberRepo) UserJoinActive(ctx context.Context, activeId int32, uid int32) error {
	q := this.data.genQ.AppActiveJoinMember
	u, _ := q.WithContext(ctx).Where(q.ActiveID.Eq(activeId), q.MemberID.Eq(uid)).First()
	s := &model.AppActiveJoinMember{}
	s.MemberID = uid
	s.ActiveID = activeId
	var err error
	if u != nil {
		s.ID = u.ID
		_, err = q.WithContext(ctx).Updates(s)
	} else {
		err = q.WithContext(ctx).Create(s)
	}

	if err != nil {
		return err
	}
	return nil
}
