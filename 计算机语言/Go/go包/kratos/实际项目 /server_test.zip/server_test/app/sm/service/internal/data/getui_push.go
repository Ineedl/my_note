package data

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"io"
	"miyou/app/sm/service/internal/biz"
	"miyou/app/sm/service/internal/conf"
	v1 "miyou/gen/api/sm/service/v1"
	"net/http"
	"strconv"
	"time"
)

var _ biz.TuiPushRepo = (*tuiPushRepo)(nil)

type tuiPushRepo struct {
	data *Data
	log  *log.Helper
	conf *conf.Bootstrap
}

func NewTuiPushRepo(data *Data, logger log.Logger, conf *conf.Bootstrap) biz.TuiPushRepo {
	return &tuiPushRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "service.data")),
		conf: conf,
	}
}

func (this *tuiPushRepo) GetAccessToken(ctx context.Context) (accessToken string, err error) {
	appId := this.conf.Getui.AppId
	cacheKey := "tui_access_token_" + appId
	redisCme := this.data.rdb.Get(ctx, cacheKey)
	accessToken = redisCme.Val()
	if len(accessToken) > 0 {
		return accessToken, nil
	}
	baseUrl := fmt.Sprintf("https://restapi.getui.com/v2/%s", appId)
	authUrl := baseUrl + "/auth"
	milliTimestamp := time.Now().UnixNano() / int64(time.Millisecond)
	timeStr := fmt.Sprintf("%d", milliTimestamp)
	sign := Sha256Hash(this.conf.Getui.AppKey + timeStr + this.conf.Getui.MasterSecret)
	data := map[string]interface{}{
		"appkey":    appId,
		"timestamp": timeStr,
		"sign":      sign,
	}

	// 发起 POST 请求
	jsonBody, _ := json.Marshal(data)
	resp, err := http.Post(authUrl, "application/json", bytes.NewBuffer(jsonBody))
	if err != nil {
		return "", err
	}
	resData, _ := io.ReadAll(resp.Body)
	defer resp.Body.Close()

	var tuiRes v1.TuiResponse
	json.Unmarshal(resData, &tuiRes)

	i, err := strconv.ParseInt(tuiRes.Data.ExpireTime, 10, 64)
	if err != nil {
		fmt.Println("转换失败:", err)
		return
	}
	exp := i/1000 - time.Now().Unix()
	str, err := this.data.rdb.Set(ctx, cacheKey, tuiRes.Data.Token, time.Duration(exp)*time.Second).Result()
	this.log.Info(str)
	if err != nil && str != "OK" {
		return accessToken, err
	}
	accessToken = tuiRes.Data.Token
	return accessToken, nil
}

// Sha256Hash 对输入字符串进行 SHA-256 加密，并返回十六进制字符串
func Sha256Hash(input string) string {
	// 创建一个 SHA-256 哈希对象
	hasher := sha256.New()

	// 写入需要加密的数据（字节流）
	hasher.Write([]byte(input))

	// 计算哈希值并返回十六进制字符串表示
	return hex.EncodeToString(hasher.Sum(nil))
}
