package service

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	v1 "miyou/gen/api/sm/service/v1"
)

type TaskService struct {
	log *log.Helper
	v1.UnimplementedTaskServiceServer
	TaskUseCase *biz.TaskUseCase
}

func NewTaskService(TaskUseCase *biz.TaskUseCase, logger log.Logger) *TaskService {
	return &TaskService{
		TaskUseCase: TaskUseCase,
		log:         log.NewHelper(log.With(logger, "module", "service/task")),
	}
}

func (this *TaskService) GetTaskTypeList(ctx context.Context, req *v1.GetTaskTypeListRequest) (*v1.GetTaskTypeListResponse, error) {
	res, err := this.TaskUseCase.GetTaskTypeList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) CreateTaskType(ctx context.Context, req *v1.CreateTaskTypeRequest) (*v1.CreateTaskTypeResponse, error) {
	res, err := this.TaskUseCase.CreateTaskType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) UpdateTaskType(ctx context.Context, req *v1.UpdateTaskTypeRequest) (*v1.UpdateTaskTypeResponse, error) {
	res, err := this.TaskUseCase.UpdateTaskType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) DeleteTaskType(ctx context.Context, req *v1.DeleteTaskTypeRequest) (*v1.DeleteTaskTypeResponse, error) {
	res, err := this.TaskUseCase.DeleteTaskType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) CreatePunishType(ctx context.Context, req *v1.CreatePunishTypeRequest) (*v1.CreatePunishTypeResponse, error) {
	res, err := this.TaskUseCase.CreatePunishType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) UpdatePunishType(ctx context.Context, req *v1.UpdatePunishTypeRequest) (*v1.UpdatePunishTypeResponse, error) {
	res, err := this.TaskUseCase.UpdatePunishType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) DeletePunishType(ctx context.Context, req *v1.DeletePunishTypeRequest) (*v1.DeletePunishTypeResponse, error) {
	res, err := this.TaskUseCase.DeletePunishType(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetPunishTypeList(ctx context.Context, req *v1.GetPunishTypeListRequest) (*v1.GetPunishTypeListResponse, error) {
	res, err := this.TaskUseCase.GetPunishTypeList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) CreateTask(ctx context.Context, req *v1.CreateTaskRequest) (*v1.CreateTaskResponse, error) {
	res, err := this.TaskUseCase.CreateTask(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetTaskList(ctx context.Context, req *v1.GetTaskListRequest) (*v1.GetTaskListResponse, error) {
	res, err := this.TaskUseCase.GetTaskList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetTaskPreType(ctx context.Context, req *v1.GetTaskPreTypeRequest) (*v1.GetTaskPreTypeResponse, error) {
	task := make([]*v1.TaskType, 0)
	tmp := &v1.TaskType{}
	tmp.TaskTypeId = 1
	tmp.TaskName = "按时睡觉"
	tmp.TaskDes = "按时睡觉"
	tmp.TaskCycle = 2
	tmp.TaskTypeStartTime = "21:00"
	tmp.TaskTypeEndTime = "8:00"
	task = append(task, tmp)
	punish := make([]*v1.PunishType, 0)
	//tmp2 := &v1.PunishType{}
	//tmp2.PunishTypeId = 1
	//tmp2.PunishName = "滴蜡"
	//tmp2.PunishCount = "1"
	//tmp2.PunishUnit = "次"
	//punish = append(punish, tmp2)
	return &v1.GetTaskPreTypeResponse{
		TaskTypeList:   task,
		PunishTypeList: punish,
	}, nil
}

func (this *TaskService) TaskSettlement(ctx context.Context, req *v1.TaskSettlementRequest) (*v1.TaskSettlementResponse, error) {
	res, err := this.TaskUseCase.TaskSettlement(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetMyDayTasks(ctx context.Context, req *v1.GetMyDayTasksRequest) (*v1.GetMyDayTasksResponse, error) {
	res, err := this.TaskUseCase.GetMyDayTasks(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetTaskPunishList(ctx context.Context, req *v1.GetTaskPunishListRequest) (*v1.GetTaskPunishListResponse, error) {
	res, err := this.TaskUseCase.GetTaskPunishList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) DeleteTask(ctx context.Context, req *v1.DeleteTaskRequest) (*v1.DeleteTaskResponse, error) {
	res, err := this.TaskUseCase.DeleteTask(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *TaskService) GetTaskSummary(ctx context.Context, req *v1.GetTaskSummaryRequest) (*v1.GetTaskSummaryResponse, error) {
	res, err := this.TaskUseCase.GetTaskSummary(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}
