package service

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	v1 "miyou/gen/api/sm/service/v1"
)

type CommonService struct {
	v1.UnimplementedCommonServiceServer
	log    *log.Helper
	common *biz.CommonUseCase
}

func NewCommonService(logger log.Logger, common *biz.CommonUseCase) *CommonService {
	return &CommonService{
		common: common,
		log:    log.NewHelper(log.With(logger, "module", "service/common")),
	}
}

func (this *CommonService) SendRegisterLoginCode(ctx context.Context, req *v1.SendRegisterLoginCodeRequest) (*v1.SendRegisterLoginCodeResponse, error) {
	res, err := this.common.SendRegisterLoginCode(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *CommonService) GetAliyunStsToken(ctx context.Context, req *v1.GetAliyunStsTokenRequest) (*v1.GetAliyunStsTokenResponse, error) {
	res, err := this.common.GetAliyunStsToken(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *CommonService) GetAllAppConfig(ctx context.Context, req *v1.GetAllAppConfigRequest) (*v1.GetAllAppConfigResponse, error) {
	res, err := this.common.GetAllAppConfig(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}
