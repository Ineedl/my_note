package server

import (
	"github.com/go-kratos/kratos/v2/registry"
	"miyou/app/sm/service/internal/conf"

	"miyou/pkg/util/bootstrap"
)

func NewRegistrar(conf *conf.Bootstrap) registry.Registrar {
	return bootstrap.NewEtcdRegistry([]string{conf.Registry.Etcd.Addr})
}
