package data

import (
	"bytes"
	"context"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"io"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	utils "miyou/pkg/util"
	"net/http"
)

var _ biz.MemberRepo = (*memberRepo)(nil)

//// 私钥（直接将私钥以 PEM 格式嵌入到代码中）测试
//const PRIVATE_KEY_PEM = `-----BEGIN PRIVATE KEY-----
//MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJa46tH51Z6IyM+P
//1T5I89Ikv0LUdAPduElTrwOEMVvrzABNrgO0pWBtdL2fjA7YwcohHgdtC5jFkTpU
//JOWdfb19jiGG7c1kk/+gjWaarMVaUdKsU/LudtzZqNyX+9mAtKxKHE5roBkjbDcE
//9MTHtLSlnKKHFWY3S7codeELjcjHAgMBAAECgYB42Q2WjG3mbiAspFPDW/T7InGk
//IPpgey8exBVIiX6WCEsKVz5WREpxNXHr9Hf1E4DWE5WjOKCavpZCIWNwI8XDpVzU
//NpQMpibNeZgRV9ljMUCm3cMGbKCL/4fJfZAR/CI8MwDntbvLMnEMz1nDZdiDYjtZ
//hJ1QdhNG6gkWyQXeCQJBAMYaoc0NT30jqbaakckMDOl+LdN2yY7Sye+4k7cNmf0S
//65bISs7CrB02fwdWBv4cJsMEEUrm4CoSXk+uF4NtkS0CQQDCxV9A3AI1FDYM18OE
//901rC20BE5a6djFcxMd2L6eUkLRfpO6E/ZNOUkpvmT4Gknkbp/fot+drCsb80ntV
//XjJDAkADAryaxS0EFdqqb8bva0N2+PfxUsjVZtay0fdMvOQuOG9kJz8bzVGYUA+2
//KNSKYBsms5UfskqN2SGdzGOHF88xAkEAmb5a1kPUqjluAO1ANPFRdzHptXPVAxLR
//HD1ohW5QhgFDoEv8y5WudaCXiUgZoe51EtOf6V9hmSlEscUj/dsBKQJAY8cLKD0s
//ULgySGs71Xi083OhtnzMY0NKUP+iiMRFJCLqzXfcb3/a2a6qK9fb5I3w4ITVDrXB
//6xR6XpygA1a42A==
//-----END PRIVATE KEY-----
//`

// 私钥（直接将私钥以 PEM 格式嵌入到代码中）
const PRIVATE_KEY_PEM = `-----BEGIN PRIVATE KEY-----
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALoOQh9IqJaR6VGC
+iCzWu3CHND63ZObqj19cjjA/7+zQBQP7RtTk5jj+hMJdhOrECPAbr8+1SQRU9e9
aD1seRjuRH1z6HIP1swhTEegDKx+8qAajPiq3/h3qtY9mwOWS/fXdwuOyK80MFLx
VchVZzvcxjHv5GtKtNf3eMhDrUkdAgMBAAECgYBQKoCXFil95xTPCE5Z9K3DMBZW
fSEnzrTFld23UoFfyg5cFpilY5d/EwvXVAZKZzSnEu0k/h+8ULL9jCD0Bl8OgNOJ
/GuFT5uOPv94qxb26UCcOfXgZGnyBvoyBZRq8j0MACuPsP/k5WUVvhJmGJwh4viD
78vtwW48MPJCbSJwgQJBAN2J2W++Cbv0cc0OaTAs6O+jT226LT5Mxxemd3+zx3/I
n/NcG+bPl26TsESncEKrVT9eWNRGYVOhMMzHgU6p8Y0CQQDW/2gOMmfvyjiUxktG
oMZU/B0tGoB7zW10bmUEcwZJGauTUJa71LQlLwUHKAqyTt79VhbJ6ucfPQO8aXtT
nanRAkBLyn5WCUjhQZaxVY3NCoBCg7eHzZru5mtyfuQBD2tgHy4BnvB4vWqMTQCP
7Eyuslj+zfNL5Cwl5U6BsHtfgyp9AkAhOOBMaU+URyxNGQMiy8857KdZg+Hcv5at
Si3D7T5IZ3YS0n4oUirwH/7n5zEX8oYUoYvt8aV7N0NvhuEuv4sxAkEArXuqh2fb
sq67+VdOfUWj0VjzLWGm+I8HDWgKisK0p6ukRDYkCaRuIGTpQ+nCWQ1bmHzc1mZt
C82NLgOb+j5SHw==
-----END PRIVATE KEY-----
`

type JgLoginResponse struct {
	Code    int    `json:"code"`
	Content string `json:"content"`
	Phone   string `json:"phone"`
}

type memberRepo struct {
	log  *log.Helper
	data *Data
}

func NewMemberRepo(data *Data, logger log.Logger) biz.MemberRepo {
	return &memberRepo{data: data, log: log.NewHelper(logger)}
}

func (this *memberRepo) GetMemberModelById(ctx context.Context, id int32) (*model.AppMember, error) {
	q := this.data.genQ.AppMember
	m, err := q.WithContext(ctx).Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	return m, nil
}

func (this *memberRepo) GetMemberById(ctx context.Context, id int32) (*v1.Member, error) {
	m, err := this.GetMemberModelById(ctx, id)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}

func (this *memberRepo) GetMemberByPhone(ctx context.Context, phone string) (*v1.Member, error) {
	q := this.data.genQ.AppMember
	m, err := q.WithContext(ctx).Where(q.Phone.Eq(phone)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}

func (this *memberRepo) GetMemberByAppleCode(ctx context.Context, appleId string) (*v1.Member, error) {
	q := this.data.genQ.AppMember
	m, err := q.WithContext(ctx).Where(q.AppleID.Eq(appleId)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}

func (this *memberRepo) CreateMember(ctx context.Context, order *v1.Member) (*v1.Member, error) {
	orderModel := this.tranProtocToModel(order)
	err := this.data.genQ.AppMember.WithContext(ctx).Create(orderModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(orderModel), nil
}

func (this *memberRepo) DeleteMember(ctx context.Context, id int32) error {
	q := this.data.genQ.AppMember
	_, err := q.WithContext(ctx).Where(q.ID.Eq(id)).Delete()
	if err != nil {
		return err
	}
	return nil
}

//func (this *memberRepo) AddFriendMessage(ctx context.Context, userId int32, friendId int32) error {
//	friendSessionKey := fmt.Sprintf(ws.UserSessionKey, friendId)
//	friendSessionId, err := this.data.rdb.Get(ctx, friendSessionKey).Result()
//	if err != nil {
//		this.log.Error(err)
//		return err
//	}
//	if friendSessionId == "" {
//		this.log.Error("no friend session")
//		return errors.New("no friend session")
//	}
//	m := &ws.ChatMessage{
//		MessageType: ws.MessageTypeFriendApply,
//		Info:        "add friend",
//	}
//	ws.wsServer.SendMessage(websocket.SessionID(friendSessionId), ws.MessageTypeChat, m)
//	return nil
//}

func (this *memberRepo) FindMemberFriends(ctx context.Context, userId int32, page int32, size int32) ([]*v1.MemberFriend, int32, error) {
	friends := this.data.genQ.AppFriendRelation
	member := this.data.genQ.AppMember
	result := make([]*v1.MemberFriend, 0)
	query := friends.Debug().
		Select(friends.UserBID.As("user_id"), member.NickName, member.AvatarURL, member.RealName, member.Gender, friends.ShowLocation.As("user_a_show_location"), friends.UserAAttribute.As("user_a_attribute"), friends.UserBAttribute.As("user_b_attribute"), friends.ApplyTime, friends.Remark, member.VipExpire).
		WithContext(ctx).
		LeftJoin(member, member.ID.EqCol(friends.UserBID)).
		Where(friends.UserAID.Eq(userId), friends.Status.Eq(1))
	err := query.Offset(int((page - 1) * size)).Limit(int(size)).Scan(&result)
	if err != nil {
		return nil, 0, err
	}
	total, err := query.Count()
	if err != nil {
		return nil, 0, err
	}
	return result, int32(total), nil
}

func (this *memberRepo) GetMemberByInviteCode(ctx context.Context, code string) (*v1.Member, error) {
	q := this.data.genQ.AppMember
	m, err := q.WithContext(ctx).Where(q.InviteCode.Eq(code)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}
func (this *memberRepo) UpdateMember(ctx context.Context, member *v1.Member) (*v1.Member, error) {
	q := this.data.genQ.AppMember
	m := this.tranProtocToModel(member)
	_, err := this.data.genQ.AppMember.WithContext(ctx).Where(q.ID.Eq(m.ID)).Updates(m)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(m), nil
}

// Step 1: 发送请求，获取加密的手机号
func (this *memberRepo) GetLoginTokenData(ctx context.Context, loginToken string) (string, error) {
	url := "https://api.verification.jpush.cn/v1/web/loginTokenVerify"
	payload := map[string]string{
		"loginToken": loginToken,
	}

	reqBody, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}
	appKey := "39cbd8f7f2af99e6871ead84"
	masterSecret := "8ac10190d0f66b8f8d81b3c5"
	auth := base64.StdEncoding.EncodeToString([]byte(appKey + ":" + masterSecret))

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(reqBody))
	if err != nil {
		return "", err
	}

	req.Header.Set("Authorization", "Basic "+auth)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	response := &JgLoginResponse{}
	fmt.Println("API Response:", string(respBody))

	err = json.Unmarshal(respBody, &response)
	if err != nil {
		return "", err
	}

	if response.Code != 8000 {
		return "", fmt.Errorf("API error: %s", response.Content)
	}

	return response.Phone, nil
}

func (this *memberRepo) DecryptPhone(ctx context.Context, phone string) (string, error) {
	// 解码 PEM 格式
	block, _ := pem.Decode([]byte(PRIVATE_KEY_PEM))
	if block == nil {
		return "", v1.ErrorApiError("private key not found")
	}

	// 解析 PKCS8 格式的私钥
	privateKey, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return "", v1.ErrorApiError("unable to parse private key")
	}

	// 转换为 *rsa.PrivateKey
	rsaPrivateKey, ok := privateKey.(*rsa.PrivateKey)
	if !ok {
		return "", v1.ErrorApiError("private key is not of type RSA")
	}

	// 将 Base64 编码的密文解码
	cipherData, err := base64.StdEncoding.DecodeString(phone)
	if err != nil {
		return "", v1.ErrorApiError("failed to decode base64 cipher text")
	}

	// 使用私钥解密数据
	decryptedData, err := rsa.DecryptPKCS1v15(nil, rsaPrivateKey, cipherData)
	if err != nil {
		return "", v1.ErrorApiError("RSA decryption failed")
	}
	return string(decryptedData), nil
}

func (this *memberRepo) tranModelToProtoc(in *model.AppMember) *v1.Member {
	out := &v1.Member{}
	out.UserId = in.ID
	out.NickName = in.NickName
	out.AvatarUrl = in.AvatarURL
	out.RealName = in.RealName
	out.Phone = in.Phone
	out.LoginTime = in.LoginTime.Format(utils.TimeFormat)
	out.Gender = in.Gender
	out.InviteCode = in.InviteCode
	out.VipExpire = in.VipExpire.Format(utils.TimeFormat)
	out.Openid = in.WxSmartOpenid
	out.JgPushId = in.JgPushID
	out.RegisterTime = in.RegisterTime.Format(utils.TimeFormat)
	out.IsModify = in.IsModify
	out.UserAttribute = in.UserAttribute
	out.AppleId = in.AppleID
	out.AutoRenewStatus = in.AutoRenewStatus
	out.GetuiCid = in.GetuiCid
	out.Email = in.Email
	out.Channel = in.Channel
	return out
}

func (this *memberRepo) tranProtocToModel(in *v1.Member) *model.AppMember {
	out := &model.AppMember{}
	out.ID = in.UserId
	out.NickName = in.NickName
	out.AvatarURL = in.AvatarUrl
	out.RealName = in.RealName
	out.Phone = in.Phone
	out.LoginTime, _ = utils.StrToDateTime(in.LoginTime)
	out.Gender = in.Gender
	out.InviteCode = in.InviteCode
	out.VipExpire, _ = utils.StrToDateTime(in.VipExpire)
	out.WxSmartOpenid = in.Openid
	out.JgPushID = in.JgPushId
	out.RegisterTime, _ = utils.StrToDateTime(in.RegisterTime)
	out.IsModify = in.IsModify
	out.UserAttribute = in.UserAttribute
	out.AppleID = in.AppleId
	out.AutoRenewStatus = in.AutoRenewStatus
	out.GetuiCid = in.GetuiCid
	out.Email = in.Email
	out.Channel = in.Channel
	return out
}
