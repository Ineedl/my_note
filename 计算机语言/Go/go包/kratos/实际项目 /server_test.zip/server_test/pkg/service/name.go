package service

import "github.com/golang-jwt/jwt/v5"

// 微服务名
const (
	SMService = "sm.miyou.service" // 数据接口 8001 9001

)

const (
	MessageTypeChat = iota + 1
	//心跳
	MessageTypeHeartbeat = 1
	//用户消息数据
	MessageTypeUploadUserDeviceInfo = 2
	//好友申请
	MessageTypeFriendAdd = 3

	MessageTypeFriendList  = 4
	MessageTypeOffLine     = 5
	MessageTypeFriendApply = 6
	MessageTypeFriendDel   = 7
	//加入活动
	MessageActiveJoin = 8
	//退出活动
	MessageActiveRemove = 9
	//获取活动列表
	MessageGetActiveList = 10
	//停止活动
	MessageActiveStop = 11
	//上报位置信息
	MessageUploadPosition = 12

	MessageImmediateCommandSend = 13

	MessageImmediateCommand = 14

	//任务接收方提交
	MessageImmediateCommandCommitSend = 15

	//任务提交提醒
	MessageImmediateCommandCommit = 16

	//任务发起方任务反馈
	MessageImmediateCommandEvaluateSend = 17

	//任务发起方任务反馈提醒
	MessageImmediateCommandEvaluate = 18

	MessageImmediateCommandRejectSend = 19

	MessageImmediateCommandReject = 20

	MessageImmediateCommandExpire = 21

	MessageImmediateCommandAck = 22

	MessageImmediateCommandQ = 23

	MessageImmediateCommandQResult = 24

	SessionUserKey = "session_user_%s"

	UserSessionKey = "user_session_%d"

	FriendAddApply = "friend_add_apply_%d"
)

type DecodedPayload struct {
	jwt.RegisteredClaims

	// 通知类型（如：CANCEL, DID_CHANGE_RENEWAL_PREF, DID_CHANGE_RENEWAL_STATUS 等）
	NotificationType string `json:"notificationType"`

	// 通知唯一 ID（UUID）
	NotificationUUID string `json:"notificationUUID"`

	// 子类型（某些通知类型下会有）
	Subtype string `json:"subtype,omitempty"`

	// 数据对象（包含收据、交易信息等）
	Data struct {
		AppAppleId    int64  `json:"appAppleId"`
		BundleId      string `json:"bundleId"`
		BundleVersion string `json:"bundleVersion"`
		Environment   string `json:"environment"` // Sandbox/Production

		// 收据相关字段
		Receipt struct {
			OriginalPurchaseDateMs string `json:"originalPurchaseDateMs"`
			SignedDateMs           string `json:"signedDateMs"`
		} `json:"receipt"`

		// 交易信息
		SignedTransactionInfo       string `json:"signedTransactionInfo,omitempty"`
		TransactionId               string `json:"transactionId,omitempty"`
		ProductId                   string `json:"productId,omitempty"`
		AutoRenewStatus             int    `json:"autoRenewStatus,omitempty"` // 0 = 已取消, 1 = 激活
		AutoRenewPreference         string `json:"autoRenewPreference,omitempty"`
		IsUpgraded                  int    `json:"isUpgraded,omitempty"`
		SubscriptionGroupIdentifier int64  `json:"subscriptionGroupIdentifier,omitempty"`
		WebOrderLineItemId          string `json:"webOrderLineItemId,omitempty"`
	} `json:"data"`

	// 版本号
	Version string `json:"version"`
}
