package biz

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	v1 "miyou/gen/api/sm/service/v1"
)

type IdentityVerifyRepo interface {
	CreateUserIdentity(ctx context.Context, info *v1.IdentityVerifyInfo) error
	QueryUserIdentity(ctx context.Context, userId int64) (*v1.IdentityVerifyInfo, error)
}

type IdentityVerifyUseCase struct {
	log                *log.Helper
	identityVerifyRepo IdentityVerifyRepo
}

func NewIdentityVerifyUseCase(identityVerifyRepo IdentityVerifyRepo, logger log.Logger) *IdentityVerifyUseCase {
	return &IdentityVerifyUseCase{
		log:                log.NewHelper(log.With(logger, "module", "identityVerify/usecase/identityVerify")),
		identityVerifyRepo: identityVerifyRepo,
	}
}

func (uc *IdentityVerifyUseCase) GetUserIdentity(ctx context.Context, userId int64) (*v1.IdentityVerifyInfo, error) {
	return uc.identityVerifyRepo.QueryUserIdentity(ctx, userId)
}
