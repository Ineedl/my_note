package indi.cjh.outInterface;

import indi.cjh.model.User;

public interface MyInterface {

    User getUserById(Integer id);
}
