package indi.cjh.service;

public interface BuyGoodsService {
        void buy(Integer goodsId,Integer nums);
}
