package indi.cjh.service;

import indi.cjh.model.User;

public interface SomeService {
    public User queryUserById(Integer id);
}
