package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
)

var _ biz.ActiveRemoveMemberRepo = (*activeRemoveMemberRepo)(nil)

type activeRemoveMemberRepo struct {
	data *Data
	log  *log.Helper
}

func NewActiveRemoveMemberRepo(data *Data, logger log.Logger) biz.ActiveRemoveMemberRepo {
	return &activeRemoveMemberRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *activeRemoveMemberRepo) GetActiveRemoveMemberIds(ctx context.Context, activeId int32) ([]int32, error) {
	type finds struct {
		ActiveID int32 `json:"active_id"`
		MemberID int32 `json:"member_id"`
	}

	var ids []finds
	q := this.data.genQ.AppActiveRemoveMember
	err := q.WithContext(ctx).Where(q.ActiveID.Eq(activeId)).Scan(&ids)
	if err != nil {
		return nil, err
	}
	var res []int32
	for _, v := range ids {
		res = append(res, v.MemberID)
	}
	return res, nil
}

func (this *activeRemoveMemberRepo) UserRemoveActive(ctx context.Context, activeId int32, uid int32) error {
	q := this.data.genQ.AppActiveRemoveMember
	s := &model.AppActiveRemoveMember{}
	s.MemberID = uid
	s.ActiveID = activeId
	err := q.WithContext(ctx).Create(s)
	if err != nil {
		return err
	}
	return nil
}
