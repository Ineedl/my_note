package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.IapOrderRepo = (*iapOrderRepo)(nil)

type iapOrderRepo struct {
	data *Data
	log  *log.Helper
}

func NewIapOrderRepo(data *Data, logger log.Logger) biz.IapOrderRepo {
	return &iapOrderRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data.iap_order")),
	}
}

func (this *iapOrderRepo) CreateIapOrder(ctx context.Context, in *v1.IapOrder) (*v1.IapOrder, error) {
	q := this.data.genQ.AppIapOrder
	model := this.tranProtocToModel(in)
	err := q.WithContext(ctx).Create(model)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(model), nil
}

func (this *iapOrderRepo) GetIapOrderByOriginalTransactionID(ctx context.Context, originalTransactionID string) (*v1.IapOrder, error) {
	q := this.data.genQ.AppIapOrder
	model, err := q.WithContext(ctx).Where(q.OriginalTransactionID.Eq(originalTransactionID)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(model), nil
}

func (this *iapOrderRepo) tranProtocToModel(in *v1.IapOrder) *model.AppIapOrder {
	out := &model.AppIapOrder{}
	out.ID = in.Id
	out.MemberID = in.MemberId
	out.OriginalTransactionID = in.OriginalTransactionId
	out.TransactionID = in.TransactionId
	out.ProductID = in.ProductId
	out.StartTime = in.StartTime
	out.ExpiryTime = in.ExpiryTime
	out.Environment = in.Environment
	out.Status = in.Status
	out.OriginStartTime = in.OriginStartTime
	out.ExpiryTime = in.ExpiryTime
	return out
}

func (this *iapOrderRepo) tranModelToProtoc(in *model.AppIapOrder) *v1.IapOrder {
	out := &v1.IapOrder{}
	out.Id = in.ID
	out.MemberId = in.MemberID
	out.OriginalTransactionId = in.OriginalTransactionID
	out.TransactionId = in.TransactionID
	out.ProductId = in.ProductID
	out.StartTime = in.StartTime
	out.ExpiryTime = in.ExpiryTime
	out.Environment = in.Environment
	out.Status = in.Status
	out.OriginStartTime = in.OriginStartTime
	out.ExpiryTime = in.ExpiryTime
	return out
}
