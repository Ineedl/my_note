package indi.cjh.main;

import indi.cjh.dao.StudentDao;
import indi.cjh.mapper.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException
    {
        String configFile="mybatis.xml";
        InputStream in = Resources.getResourceAsStream(configFile);
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);

        SqlSession sqlSession= factory.openSession(true);

        StudentDao dao = sqlSession.getMapper(StudentDao.class);

        Student stu=new Student();
        stu.setId(789);
        stu.setName("tmp");
        stu.setEmail("A@A");
        stu.setAge(198);

        int a=dao.insertStudents(stu);
        System.out.println("stttttttttttttt"+a);
        List<Student> students = dao.selectStudents("cjh",23);

        List<Student> students2 = dao.selectStudents2("cjh",23,10);

        Map<String,Object> data=new HashMap<>();
        data.put("MyName","cjh");
        data.put("MyAge",23);
        data.put("MyId",10);

        List<Student> students3 = dao.selectStudents3(data);

        List<Student> students4 = dao.selectStudents4();

        for(Student stu2 : students)
        {
            System.out.println(stu2);
        }
        for(Student stu3 : students2)
        {
            System.out.println(stu3);
        }
        for(Student stu4 : students3)
        {
            System.out.println("-"+stu4);
        }
        for(Student stu5 : students4)
        {
            System.out.println("+"+stu5);
        }

        sqlSession.close();
    }
}
