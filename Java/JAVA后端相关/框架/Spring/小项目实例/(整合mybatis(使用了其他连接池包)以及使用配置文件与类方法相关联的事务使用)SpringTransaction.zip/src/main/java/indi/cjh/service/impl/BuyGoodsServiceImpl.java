package indi.cjh.service.impl;

import indi.cjh.beanclass.Goods;
import indi.cjh.beanclass.Sale;
import indi.cjh.dao.GoodsDao;
import indi.cjh.dao.SaleDao;
import indi.cjh.service.BuyGoodsService;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.beans.Transient;

public class BuyGoodsServiceImpl implements BuyGoodsService {
    private SaleDao saledao;
    private GoodsDao goodsdao;

    public void setSaledao(SaleDao saledao) {
        this.saledao = saledao;
    }

    public void setGoodsdao(GoodsDao goodsdao) {
        this.goodsdao = goodsdao;
    }

    public void buy(Integer goodsId, Integer nums) {

        System.out.println("buy开始!!!!!!");
        Sale sale = new Sale();
        sale.setGid(goodsId);
        sale.setNums(nums);
        saledao.insertSale(sale);
        Goods goods = goodsdao.selectGoods(goodsId);

        //数据表数据请根据beans.xml中的表来建立
        //此处模拟出一个不存在的商品被购买时的异常
        if (null == goods) {
            throw new NullPointerException(goodsId + "不存在");
        //此处模拟一个商品库存不足被购买时的异常
        } else if (goods.getAmount() < nums)
            throw new RuntimeException("数量太多");
        Goods myBuyGoods = new Goods();
        myBuyGoods.setId(goodsId);
        myBuyGoods.setAmount(nums);
        goodsdao.updateGoods(myBuyGoods);
        System.out.println("buy结束!!!!!!");
    }

}
