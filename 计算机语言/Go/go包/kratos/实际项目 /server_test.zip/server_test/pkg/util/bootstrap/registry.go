package bootstrap

import (
	"github.com/go-kratos/kratos/v2/log"

	// etcd
	etcdKratos "github.com/go-kratos/kratos/contrib/registry/etcd/v2"
	etcdClient "go.etcd.io/etcd/client/v3"
)

// NewEtcdRegistry 创建一个注册发现客户端 - Etcd
func NewEtcdRegistry(address []string) *etcdKratos.Registry {
	conf := etcdClient.Config{
		Endpoints: address,
	}

	var err error
	var cli *etcdClient.Client
	if cli, err = etcdClient.New(conf); err != nil {
		log.Fatal(err)
	}

	reg := etcdKratos.New(cli)

	return reg
}
