package service

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"

	pb "miyou/gen/api/sm/service/v1"
)

type IdentityVerifyService struct {
	pb.UnimplementedIdentityVerifyServer
	log                   *log.Helper
	identityVerifyUseCase *biz.IdentityVerifyUseCase
}

func NewIdentityVerifyService(identityVerifyUseCase *biz.IdentityVerifyUseCase, logger log.Logger) *IdentityVerifyService {
	return &IdentityVerifyService{
		identityVerifyUseCase: identityVerifyUseCase,
		log:                   log.NewHelper(log.With(logger, "module", "service/common")),
	}
}

func (s *IdentityVerifyService) IdentityVerify(ctx context.Context, req *pb.IdentityVerifyInfo) (*pb.IdentityVerifyReply, error) {
	return &pb.IdentityVerifyReply{}, nil
}
func (s *IdentityVerifyService) GetUserIdentityVerify(ctx context.Context, req *pb.IdentityVerifyInfo) (*pb.IdentityVerifyInfo, error) {
	resp := &pb.IdentityVerifyInfo{
		UserId:       0,
		Name:         "",
		IdentityCard: "",
	}
	info, err := s.identityVerifyUseCase.GetUserIdentity(ctx, req.UserId)
	if err != nil {
		return resp, err
	}
	if info != nil {
		resp.UserId = info.UserId
		resp.Name = info.Name
		resp.IdentityCard = info.IdentityCard
	} else {
		resp.UserId = -1
	}
	return resp, nil
}
