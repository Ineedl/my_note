package msgnsq

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/uuid"
	"github.com/google/wire"
	"github.com/tx7do/kratos-transport/broker"
	"github.com/tx7do/kratos-transport/transport/nsq"
	"miyou/app/sm/service/internal/biz"
	"miyou/app/sm/service/internal/conf"
	v1 "miyou/gen/api/sm/service/v1"
	"miyou/pkg/service"
	"strconv"
	"sync"
	"time"
)

var ProviderSet = wire.NewSet(
	NewMsgHandler,
)

type expireRun struct {
	F          func()
	ExpireTime int64
}

type MsgHandler struct {
	log                    *log.Helper
	conf                   *conf.Bootstrap
	frRepo                 biz.FriendsRelationsRepo
	memberTokenRepo        biz.MemberTokenRepo
	memberOnlineStatusRepo biz.MemberOnlineStatusRepo
	immediateCommand       biz.ImmediateCommandRepo
	nsqServer              *nsq.Server
	nsqBroker              broker.Broker
	expireDisposeMap       map[int64]expireRun
	expireDisposeMutex     sync.Mutex
}

func NewMsgHandler(
	logger log.Logger,
	conf *conf.Bootstrap,
	fr biz.FriendsRelationsRepo,
	memberTokenRepo biz.MemberTokenRepo,
	memberOnlineStatus biz.MemberOnlineStatusRepo,
	immediateCommand biz.ImmediateCommandRepo,
	nsqBroker broker.Broker,
) *MsgHandler {
	m := &MsgHandler{
		conf:                   conf,
		frRepo:                 fr,
		memberTokenRepo:        memberTokenRepo,
		memberOnlineStatusRepo: memberOnlineStatus,
		nsqBroker:              nsqBroker,
		immediateCommand:       immediateCommand,
		log:                    log.NewHelper(log.With(logger, "module", "ws-server/data/ws_handler")),
	}
	go func() {
		for {
			time.Sleep(time.Duration(1) * time.Second)
			m.expireDisposeMutex.Lock()
			now := time.Now().Unix()
			newMap := make(map[int64]expireRun)
			for k, v := range m.expireDisposeMap {
				if now > v.ExpireTime {
					v.F()
				} else {
					newMap[k] = v
				}
			}
			m.expireDisposeMap = newMap
			m.expireDisposeMutex.Unlock()
		}
	}()
	return m
}

func (this *MsgHandler) SetWebsocketServer(ns *nsq.Server) {
	this.nsqServer = ns
}

func (this *MsgHandler) HandleChatMessage(_ context.Context, topic string, headers broker.Headers, message *v1.NsqMessage) error {
	this.log.Debug(message)
	chatMessage := &v1.ChatMessage{}
	json.Unmarshal([]byte(message.Content), &chatMessage)
	this.log.Debug(chatMessage)
	ctx := context.Background()
	uid := message.From
	userid, _ := strconv.Atoi(uid)
	switch chatMessage.MessageType {
	case service.MessageTypeUploadUserDeviceInfo:
		this.UploadUserDeviceInfo(ctx, int32(userid), chatMessage.DeviceInfo)
		break
	//获取活动列表
	//case service.MessageGetActiveList:
	//	this.GetActiveUserSend(ctx, message)
	//	break
	case service.MessageUploadPosition:
		this.UploadDevicePosition(ctx, int32(userid), chatMessage.DevicePosition)
		break
	case service.MessageImmediateCommandSend: //即时任务发送
		this.ImmediateCommandSend(ctx, chatMessage.ImmediateCommand)
		break
	case service.MessageImmediateCommandCommitSend: //任务结果提交
		this.ImmediateCommandCommitSend(ctx, chatMessage.ImmediateCommand)
		break
	case service.MessageImmediateCommandEvaluateSend: //任务评价
		this.ImmediateCommandEvaluateSend(ctx, chatMessage.ImmediateCommand)
		break
	case service.MessageImmediateCommandRejectSend:
		this.ImmediateCommandRejectSend(ctx, chatMessage.ImmediateCommand)
		break
	case service.MessageImmediateCommandAck:
		this.ImmediateCommandSendAck(ctx, chatMessage.ImmediateCommand)
		break
	case service.MessageImmediateCommandQ:
		this.ImmediateCommandQ(ctx, chatMessage.ImmediateCommand, userid)
	}
	return nil
}

func (this *MsgHandler) UploadUserDeviceInfo(ctx context.Context, userId int32, deviceInfo *v1.DeviceInfo) {
	//this.log.Debug(deviceInfo)
	//用户上报信息
	userOnlineStatus := &v1.MemberOnlineStatus{
		UserId:           deviceInfo.UserId,
		DeviceName:       deviceInfo.DeviceName,
		NickName:         deviceInfo.NickName,
		BatteryStatus:    deviceInfo.BatteryStatus,
		BatteryLevel:     deviceInfo.BatteryLevel,
		IsOnline:         1,
		Latitude:         deviceInfo.Latitude,
		Longitude:        deviceInfo.Longitude,
		StayTime:         deviceInfo.StayTime,
		UnlockPhoneCount: deviceInfo.UnlockPhoneCount,
		ScreenUseTime:    deviceInfo.ScreenUseTime,
		Wifi:             deviceInfo.Wifi,
	}
	err := this.memberOnlineStatusRepo.UserUpLoadOnlineStatus(ctx, userOnlineStatus)
	if err != nil {
		this.log.Error(err)
		return
	}
	friendIds, err := this.frRepo.FriendIdsByUserId(ctx, userId)
	if err != nil {
		this.log.Error(err)
		return
	}
	if len(friendIds) == 0 {
		this.log.Error("no friend")
		return
	}
	list, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, friendIds)
	m := &v1.ChatMessage{
		MessageType: service.MessageTypeFriendList,
		Info:        "update user info",
		Friend_List: list,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", userId)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	//p, err := json.Marshal(s)
	//if err != nil {
	//	this.log.Error(err)
	//	return
	//}
	//this.log.Debug(string(p))
	//this.nsqProducer.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, p)
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}

func (this *MsgHandler) UploadDevicePosition(ctx context.Context, userId int32, position *v1.DevicePosition) {

	//用户上报信息
	userOnlineStatus := &v1.MemberOnlineStatus{
		UserId:    userId,
		Latitude:  position.Latitude,
		Longitude: position.Longitude,
	}
	err := this.memberOnlineStatusRepo.UserUpLoadOnlineStatus(ctx, userOnlineStatus)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}

func (this *MsgHandler) ImmediateCommandQ(ctx context.Context, command *v1.ImmediateCommand, from int) {
	q, err := this.immediateCommand.GetImmediateCommandByUserId(ctx, command.MemberID, command.CarryMemberID)
	if err != nil {
		this.log.Errorf("CreateImmediateCommand error:%v", err)
		return
	}
	m := &v1.ChatMessage{
		MessageType:      service.MessageImmediateCommandQResult,
		Info:             "ImmediateCommand",
		ImmediateCommand: q,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", from)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}
}

// 发送任务 接收方Ack前不入库
func (this *MsgHandler) ImmediateCommandSendAck(ctx context.Context, command *v1.ImmediateCommand) {
	//m := &v1.ChatMessage{
	//	MessageType:      service.MessageImmediateCommand,
	//	Info:             "ImmediateCommand",
	//	ImmediateCommand: command,
	//}
	//mByte, _ := json.Marshal(m)
	//s := v1.NsqMessage{}
	//s.Content = string(mByte)
	//s.To = fmt.Sprintf("%d", command.CarryMemberID)
	//s.From = fmt.Sprintf("%d", command.MemberID)
	//s.Timestamp = time.Now().UnixMilli()
	//s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	//s.MsgId = uuid.New().String()
	//err := this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	//if err != nil {
	//	this.log.Error(err)
	//	return
	//}
	//接受超时
	command.AcceptTime = time.Now().Unix()
	err := this.immediateCommand.UpdateImmediateCommandAcceptTime(ctx, command)
	if err != nil {
		this.log.Errorf("UpdateImmediateCommandAcceptTime error:%v", err)
		return
	}
	go func() {
		r := expireRun{}
		r.F = func() {
			v, err := this.immediateCommand.ImmediateCommandExpire(context.Background(), command)
			if err != nil {
				this.log.Errorf("immediateCommandExpire error:%v", err)
				return
			}
			if v != 0 { //任务确实超时了
				command.Status = 3
				m := &v1.ChatMessage{
					MessageType:      service.MessageImmediateCommandExpire,
					Info:             "ImmediateCommand result",
					ImmediateCommand: command,
				}
				mByte, _ := json.Marshal(m)
				s := v1.NsqMessage{}
				s.Content = string(mByte)
				s.To = fmt.Sprintf("%d", command.CarryMemberID)
				s.From = "system"
				s.Timestamp = time.Now().UnixMilli()
				s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
				s.MsgId = uuid.New().String()
				err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
				if err != nil {
					this.log.Error(err)
					return
				}
				s.To = fmt.Sprintf("%d", command.MemberID)
				s.MsgId = uuid.New().String()
				err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
				if err != nil {
					this.log.Error(err)
					return
				}
			}
		}
		r.ExpireTime = time.Now().Unix() + int64(command.LimitTime)
		this.expireDisposeMutex.Lock()
		defer this.expireDisposeMutex.Unlock()
		this.expireDisposeMap[command.Id] = r //过期自动更新为拒绝
	}()
}

// 任务接收方回应
func (this *MsgHandler) ImmediateCommandSend(ctx context.Context, command *v1.ImmediateCommand) {
	err := this.immediateCommand.CreateImmediateCommand(ctx, command)
	if err != nil {
		this.log.Errorf("CreateImmediateCommand error:%v", err)
		return
	}
	command.Status = 1

	m := &v1.ChatMessage{
		MessageType:      service.MessageImmediateCommand,
		Info:             "ImmediateCommand result",
		ImmediateCommand: command,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", command.CarryMemberID)
	s.From = fmt.Sprintf("%d", command.MemberID)
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}

	//等待超时 固定30min
	go func() {
		r := expireRun{}
		r.F = func() {
			v, err := this.immediateCommand.ImmediateCommandExpire(context.Background(), command)
			if err != nil {
				this.log.Errorf("immediateCommandExpire error:%v", err)
				return
			}
			if v != 0 { //任务确实超时了
				command.Status = 3
				m := &v1.ChatMessage{
					MessageType:      service.MessageImmediateCommandExpire,
					Info:             "ImmediateCommand result",
					ImmediateCommand: command,
				}
				mByte, _ := json.Marshal(m)
				s := v1.NsqMessage{}
				s.Content = string(mByte)
				s.To = fmt.Sprintf("%d", command.CarryMemberID)
				s.From = "system"
				s.Timestamp = time.Now().UnixMilli()
				s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
				s.MsgId = uuid.New().String()
				err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
				if err != nil {
					this.log.Error(err)
					return
				}
				s.To = fmt.Sprintf("%d", command.MemberID)
				s.MsgId = uuid.New().String()
				err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
				if err != nil {
					this.log.Error(err)
					return
				}
			}
		}
		r.ExpireTime = time.Now().Unix() + 30*60
		this.expireDisposeMutex.Lock()
		defer this.expireDisposeMutex.Unlock()
		this.expireDisposeMap[command.Id] = r //过期自动更新为拒绝
	}()

	return
}

// 任务结果提交
func (this *MsgHandler) ImmediateCommandCommitSend(ctx context.Context, command *v1.ImmediateCommand) {
	err := this.immediateCommand.UpdateImmediateCommandCommitData(ctx, command)
	if err != nil {
		this.log.Errorf("UpdateImmediateCommandCommitData error:%v", err)
		return
	}
	m := &v1.ChatMessage{
		MessageType:      service.MessageImmediateCommandCommit,
		Info:             "recv commit",
		ImmediateCommand: command,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", command.MemberID)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}

// 任务反馈
func (this *MsgHandler) ImmediateCommandEvaluateSend(ctx context.Context, command *v1.ImmediateCommand) {
	err := this.immediateCommand.UpdateImmediateCommandEvaluate(ctx, command)
	if err != nil {
		this.log.Errorf("UpdateImmediateCommandEvaluate error:%v", err)
		return
	}
	m := &v1.ChatMessage{
		MessageType:      service.MessageImmediateCommandEvaluate,
		Info:             "recv evaluate",
		ImmediateCommand: command,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", command.CarryMemberID)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}

// 任务拒绝
func (this *MsgHandler) ImmediateCommandRejectSend(ctx context.Context, command *v1.ImmediateCommand) {
	command.Status = -1
	err := this.immediateCommand.UpdateImmediateCommandStatus(ctx, command)
	if err != nil {
		this.log.Errorf("UpdateImmediateCommandEvaluate error:%v", err)
		return
	}
	m := &v1.ChatMessage{
		MessageType:      service.MessageImmediateCommandReject,
		Info:             "recv reject",
		ImmediateCommand: command,
	}
	mByte, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mByte)
	s.To = fmt.Sprintf("%d", command.MemberID)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		this.log.Error(err)
		return
	}
	return
}
