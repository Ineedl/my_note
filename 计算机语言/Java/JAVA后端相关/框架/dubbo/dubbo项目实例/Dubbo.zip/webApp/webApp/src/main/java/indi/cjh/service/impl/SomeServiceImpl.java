package indi.cjh.service.impl;

import indi.cjh.model.User;
import indi.cjh.service.SomeService;

public class SomeServiceImpl implements SomeService {
    public User queryUserById(Integer id){
        User user = new User();
        user.setId(id);
        user.setUsername("pony");
        user.setAge(20);
        return user;
    }
}
