package data

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-redis/redis/v8"
	"gorm.io/gorm"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	"strconv"
	"time"
)

var _ biz.ImmediateCommandRepo = (*immediateCommandRepo)(nil)

type immediateCommandRepo struct {
	data *Data
	log  *log.Helper
}

func NewImmediateCommandRepo(data *Data, logger log.Logger) biz.ImmediateCommandRepo {
	return &immediateCommandRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

const immediateCommandKey = "immediateCommand:%v:%v"
const immediateCommandLimitKey = "immediateCommand:%v:%v:limit"
const redisMutex = "immediateCommand:%v:%v:mutex"

func (this *immediateCommandRepo) CreateImmediateCommand(ctx context.Context, fr *v1.ImmediateCommand) error {
	//redis锁 保证每次进来的ack对于某两个用户串行执行
	ok, err := this.data.rdb.SetNX(ctx, fmt.Sprintf(redisMutex, fr.MemberID, fr.CarryMemberID), "", 30*time.Second).Result()
	if err != nil {
		return err
	}
	if !ok {
		return fmt.Errorf("not get redis lock")
	}
	defer this.data.rdb.Del(ctx, fmt.Sprintf(redisMutex, fr.MemberID, fr.CarryMemberID))
	limit, err := this.data.rdb.Get(ctx, fmt.Sprintf(immediateCommandLimitKey, fr.MemberID, fr.CarryMemberID)).Result()
	if err != nil && err != redis.Nil {
		return err
	}
	limitNoFound := false
	if err != redis.Nil {
		intLimit, _ := strconv.Atoi(limit)
		if intLimit == 3 {
			return fmt.Errorf("今日任务发送数量到达最大值")
		}
	} else {
		limitNoFound = true
	}

	v, err := this.data.rdb.Get(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID)).Result()
	if err != nil && err != redis.Nil {
		return err
	}
	if err != redis.Nil {
		last := &model.AppImmediateCommand{}
		err = json.Unmarshal([]byte(v), last)
		if err != nil {
			return err
		}
		if last.Status == 1 || last.Status == 4 {
			return fmt.Errorf("上一个任务未完成! 不允许提交新任务")
		}
	} else {
		last, err := this.GetImmediateCommandByUserId(ctx, fr.MemberID, fr.CarryMemberID)
		if err != nil {
			return err
		}
		if last != nil && (last.Status == 1 || last.Status == 4) {
			return fmt.Errorf("上一个任务未完成! 不允许提交新任务")
		}
	}

	d := &model.AppImmediateCommand{}
	d.CarryMemberID = fr.CarryMemberID
	d.MemberID = fr.MemberID
	d.Name = fr.Name
	d.CommitType = fr.CommitType
	d.StartTime = time.Now().Unix()
	d.LimitTime = fr.LimitTime
	d.Describe = fr.Describe
	d.Status = 1
	err = this.data.genQ.AppImmediateCommand.WithContext(ctx).Create(d)
	if err != nil {
		return err
	}
	fr.Id = d.ID
	ic, _ := json.Marshal(d)
	this.data.rdb.Set(ctx, fmt.Sprintf(immediateCommandKey, d.MemberID, d.CarryMemberID), string(ic), time.Duration(d.LimitTime)*time.Second)
	if limitNoFound {
		now := time.Now()
		tomorrow := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, now.Location())
		duration := tomorrow.Sub(now)
		this.data.rdb.Set(ctx, fmt.Sprintf(immediateCommandLimitKey, fr.MemberID, fr.CarryMemberID), "1", duration)
	} else {
		this.data.rdb.Incr(ctx, fmt.Sprintf(immediateCommandLimitKey, fr.MemberID, fr.CarryMemberID))
	}

	return nil
}

func (this *immediateCommandRepo) GetImmediateCommandByUserId(ctx context.Context, memberId, carryMemberId int64) (*v1.ImmediateCommand, error) {
	limit, err := this.data.rdb.Get(ctx, fmt.Sprintf(immediateCommandLimitKey, memberId, carryMemberId)).Result()
	if err != nil && err != redis.Nil {
		return nil, err
	}
	intLimit := 0
	if err != redis.Nil {
		intLimit, _ = strconv.Atoi(limit)
	}

	keys, err := this.data.rdb.Keys(ctx, fmt.Sprintf(immediateCommandKey, memberId, carryMemberId)).Result()
	if err != nil || len(keys) == 0 {
		q := this.data.genQ.AppImmediateCommand
		out, err := q.WithContext(ctx).Where(q.CarryMemberID.Eq(carryMemberId)).Where(q.MemberID.Eq(memberId)).Order(q.ID.Desc()).First()
		if err != nil && err != gorm.ErrRecordNotFound {
			return nil, err
		}
		if err == gorm.ErrRecordNotFound {
			return nil, nil
		}
		ic := &v1.ImmediateCommand{
			Id:            out.ID,
			Name:          out.Name,
			MemberID:      out.MemberID,
			CarryMemberID: out.CarryMemberID,
			CommitType:    out.CommitType,
			LimitTime:     out.LimitTime,
			Describe:      out.Describe,
			Status:        out.Status,
			Evaluate:      out.Evaluate,
			StartTime:     out.StartTime,
			AcceptTime:    out.AcceptTime,
			TodaySendNum:  intLimit,
		}
		if out.Status == 1 {
			nowTime := time.Now().Unix()
			dur := nowTime - out.StartTime - int64(out.LimitTime)
			if dur > 0 { //没超时 也不在评价 再次插入缓存
				d, _ := json.Marshal(out)
				this.data.rdb.Set(ctx, fmt.Sprintf(immediateCommandKey, out.MemberID, out.CarryMemberID), string(d), time.Duration(dur)*time.Second)
			}
		}
		json.Unmarshal([]byte(out.CommitData), &ic.CommitData)
		if err != nil {
			fmt.Printf("warn json.Unmarshal commit data failed:%v\n", err)
		}
		return ic, nil
	}
	v, err := this.data.rdb.Get(ctx, keys[0]).Result()
	if err != nil {
		return nil, err
	}
	out := &model.AppImmediateCommand{}
	err = json.Unmarshal([]byte(v), out)
	if err != nil {
		return nil, err
	}
	ic := &v1.ImmediateCommand{
		Id:            out.ID,
		Name:          out.Name,
		MemberID:      out.MemberID,
		CarryMemberID: out.CarryMemberID,
		CommitType:    out.CommitType,
		LimitTime:     out.LimitTime,
		Describe:      out.Describe,
		Status:        out.Status,
		Evaluate:      out.Evaluate,
		StartTime:     out.StartTime,
		AcceptTime:    out.AcceptTime,
		TodaySendNum:  intLimit,
	}
	err = json.Unmarshal([]byte(out.CommitData), &ic.CommitData)
	if err != nil {
		fmt.Printf("warn json.Unmarshal commit data failed:%v\n", err)
	}
	return ic, nil
}

func (this *immediateCommandRepo) GetImmediateCommandByCommandId(ctx context.Context, id int64) (*v1.ImmediateCommand, error) {
	q := this.data.genQ.AppImmediateCommand
	out, err := q.WithContext(ctx).Where(q.ID.Eq(id)).Order(q.ID.Desc()).First()
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	ic := &v1.ImmediateCommand{
		Id:            out.ID,
		Name:          out.Name,
		MemberID:      out.MemberID,
		CarryMemberID: out.CarryMemberID,
		CommitType:    out.CommitType,
		LimitTime:     out.LimitTime,
		Describe:      out.Describe,
		Status:        out.Status,
		Evaluate:      out.Evaluate,
		StartTime:     out.StartTime,
		AcceptTime:    out.AcceptTime,
	}
	if out.Status == 1 {
		nowTime := time.Now().Unix()
		dur := nowTime - out.StartTime - int64(out.LimitTime)
		if dur > 0 { //没超时 也不在评价 再次插入缓存
			d, _ := json.Marshal(out)
			this.data.rdb.Set(ctx, fmt.Sprintf(immediateCommandKey, out.MemberID, out.CarryMemberID), string(d), time.Duration(dur)*time.Second)
		}
	}
	json.Unmarshal([]byte(out.CommitData), ic.CommitData)

	limit, err := this.data.rdb.Get(ctx, fmt.Sprintf(immediateCommandLimitKey, ic.MemberID, ic.CarryMemberID)).Result()
	if err != nil && err != redis.Nil {
		return nil, err
	}
	intLimit := 0
	if err != redis.Nil {
		intLimit, _ = strconv.Atoi(limit)
	}
	ic.TodaySendNum = intLimit

	return ic, nil
}

// 更新任务状态
func (this *immediateCommandRepo) UpdateImmediateCommandStatus(ctx context.Context, fr *v1.ImmediateCommand) error {
	d := model.AppImmediateCommand{}
	d.Status = fr.Status
	q := this.data.genQ.AppImmediateCommand
	_, err := q.WithContext(ctx).Select(q.Status).Where(q.ID.Eq(fr.Id)).Updates(&d)
	if err != nil {
		return err
	}
	this.data.rdb.Del(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID))
	return nil
}

// 更新提交数据 并设置状态为等待评价中
func (this *immediateCommandRepo) UpdateImmediateCommandCommitData(ctx context.Context, fr *v1.ImmediateCommand) error {
	d := model.AppImmediateCommand{}
	cmData, _ := json.Marshal(fr.CommitData)
	d.CommitData = string(cmData)
	d.Status = 4
	q := this.data.genQ.AppImmediateCommand
	_, err := q.WithContext(ctx).Select(q.CommitData, q.Status).Where(q.ID.Eq(fr.Id)).Updates(&d)
	if err != nil {
		return err
	}
	this.data.rdb.Del(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID))
	return nil
}

// 更新评价
func (this *immediateCommandRepo) UpdateImmediateCommandEvaluate(ctx context.Context, fr *v1.ImmediateCommand) error {
	d := model.AppImmediateCommand{}
	d.Evaluate = fr.Evaluate
	d.Status = 2
	q := this.data.genQ.AppImmediateCommand
	_, err := q.WithContext(ctx).Select(q.Status, q.Evaluate).Where(q.ID.Eq(fr.Id)).Updates(&d)
	if err != nil {
		return err
	}
	this.data.rdb.Del(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID))
	return nil
}

func (this *immediateCommandRepo) UpdateImmediateCommandAcceptTime(ctx context.Context, fr *v1.ImmediateCommand) error {
	d := model.AppImmediateCommand{}
	d.AcceptTime = fr.AcceptTime
	q := this.data.genQ.AppImmediateCommand
	_, err := q.WithContext(ctx).Select(q.AcceptTime).Where(q.ID.Eq(fr.Id)).Updates(&d)
	if err != nil {
		return err
	}
	this.data.rdb.Del(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID))
	return nil
}

func (this *immediateCommandRepo) ImmediateCommandExpire(ctx context.Context, fr *v1.ImmediateCommand) (int, error) {
	d := model.AppImmediateCommand{}
	d.Status = 3
	q := this.data.genQ.AppImmediateCommand
	v, err := q.WithContext(ctx).Select(q.Status, q.Evaluate).Where(q.ID.Eq(fr.Id)).Where(q.Status.Eq(1)).Updates(&d)
	if err != nil {
		return 0, err
	}
	this.data.rdb.Del(ctx, fmt.Sprintf(immediateCommandKey, fr.MemberID, fr.CarryMemberID))
	return int(v.RowsAffected), nil
}
