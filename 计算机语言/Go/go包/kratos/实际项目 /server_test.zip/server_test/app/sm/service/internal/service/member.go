package service

import (
	"context"
	"encoding/json"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/transport/http"
	"miyou/app/sm/service/internal/biz"
	v1 "miyou/gen/api/sm/service/v1"
)

type MemberService struct {
	log *log.Helper
	v1.UnimplementedMemberServiceServer
	memberUseCase *biz.MemberUseCase
}

func NewMemberService(memberUseCase *biz.MemberUseCase, logger log.Logger) *MemberService {
	return &MemberService{memberUseCase: memberUseCase, log: log.NewHelper(logger)}
}
func (this *MemberService) MemberLogin(ctx context.Context, req *v1.MemberLoginRequest) (*v1.MemberLoginResponse, error) {
	if req.LoginType == 2 {
		res, err := this.memberUseCase.MemberLoginByPhone(ctx, req)
		if err != nil {
			return nil, v1.ErrorApiError(err.Error())
		}
		return res, nil
	}

	if req.LoginType == 3 {
		res, err := this.memberUseCase.MemberLoginByAppleCode(ctx, req)
		if err != nil {
			return nil, v1.ErrorApiError(err.Error())
		}
		return res, nil
	}
	return nil, v1.ErrorApiError("登录方式错误")
}

func (this *MemberService) RefreshToken(ctx context.Context, req *v1.RefreshTokenRequest) (*v1.RefreshTokenResponse, error) {
	res, err := this.memberUseCase.RefreshToken(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) GetMemberInfo(ctx context.Context, req *v1.GetMemberInfoRequest) (*v1.GetMemberInfoResponse, error) {
	res, err := this.memberUseCase.GetMemberInfo(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) GetMyFriends(ctx context.Context, req *v1.GetMyFriendsRequest) (*v1.GetMyFriendsResponse, error) {
	res, err := this.memberUseCase.GetMyFriends(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) PhoneCodeLogin(ctx context.Context, req *v1.PhoneCodeLoginRequest) (*v1.PhoneCodeLoginResponse, error) {
	res, err := this.memberUseCase.PhoneCodeLogin(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) AddFriend(ctx context.Context, req *v1.AddFriendRequest) (*v1.AddFriendResponse, error) {
	res, err := this.memberUseCase.AddFriend(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) FriendApplyList(ctx context.Context, req *v1.FriendApplyListRequest) (*v1.FriendApplyListResponse, error) {
	res, err := this.memberUseCase.FriendApplyList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) CheckFriendApply(ctx context.Context, req *v1.CheckFriendApplyRequest) (*v1.CheckFriendApplyResponse, error) {
	res, err := this.memberUseCase.CheckFriendApply(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) GetMemberFriendInfoByInviteCode(ctx context.Context, req *v1.GetMemberFriendInfoByInviteCodeRequest) (*v1.GetMemberFriendInfoByInviteCodeResponse, error) {
	res, err := this.memberUseCase.GetMemberFriendInfoByInviteCode(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) ModifyMemberInfo(ctx context.Context, req *v1.ModifyMemberInfoRequest) (*v1.ModifyMemberInfoResponse, error) {
	res, err := this.memberUseCase.ModifyMemberInfo(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) SetFriendRemarkAndShowLocal(ctx context.Context, req *v1.SetFriendRemarkAndShowLocalRequest) (*v1.SetFriendRemarkAndShowLocalResponse, error) {
	res, err := this.memberUseCase.SetFriendRemarkAndShowLocal(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) DelFriend(ctx context.Context, req *v1.DelFriendRequest) (*v1.DelFriendResponse, error) {
	res, err := this.memberUseCase.DelFriend(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) UploadUserLocation(ctx context.Context, req *v1.UserLocationRequest) (*v1.UserLocationResponse, error) {
	res, err := this.memberUseCase.UploadUserLocation(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) GetUserLocationLog(ctx context.Context, req *v1.GetUserLocationLogRequest) (*v1.GetUserLocationLogResponse, error) {
	res, err := this.memberUseCase.GetUserLocationLog(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) UserLogOff(ctx context.Context, req *v1.UserLogOffRequest) (*v1.UserLogOffResponse, error) {
	res, err := this.memberUseCase.UserLogOff(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) SendBindPhoneCode(ctx context.Context, req *v1.SendBindPhoneCodeRequest) (*v1.SendBindPhoneCodeResponse, error) {
	res, err := this.memberUseCase.SendBindPhoneCode(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) CheckBindPhoneCode(ctx context.Context, req *v1.CheckBindPhoneCodeRequest) (*v1.CheckBindPhoneCodeResponse, error) {
	res, err := this.memberUseCase.CheckBindPhoneCode(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) CreateOrder(r http.Context) error {
	result, err := this.memberUseCase.CreateOrder(r)
	if err != nil {
		r.Response().WriteHeader(400)
		r.Response().Write([]byte(err.Error()))
		return nil
	}
	rspVal, _ := json.Marshal(result)
	r.Response().WriteHeader(200)
	r.Response().Write(rspVal)
	return nil
}

func (this *MemberService) AppleNotification(r http.Context) error {
	err := this.memberUseCase.AppleNotification(r)
	if err != nil {
		r.Response().WriteHeader(400)
		r.Response().Write([]byte("error"))
		return nil
	} else {
		r.Response().WriteHeader(200)
		r.Response().Write([]byte("OK"))
	}
	return nil
}

func (this *MemberService) WechatPayReceiptNotify(r http.Context) error {
	result, err := this.memberUseCase.WechatPayReceiptNotify(r)
	if err != nil {
		r.Response().WriteHeader(400)
		r.Response().Write([]byte("error"))
		return nil
	}
	rspVal, _ := json.Marshal(result)
	r.Response().WriteHeader(200)
	r.Response().Write(rspVal)
	return nil
}

func (this *MemberService) AliPayReceiptNotify(r http.Context) error {
	err := this.memberUseCase.AliPayReceiptNotify(r)
	if err != nil {
		r.Response().WriteHeader(400)
		r.Response().Write([]byte("error"))
		return nil
	} else {
		r.Response().WriteHeader(200)
		r.Response().Write([]byte("success"))
	}
	return nil
}

func (this *MemberService) CheckAppleReceiptData(ctx context.Context, req *v1.CheckAppleReceiptDataRequest) (*v1.CheckAppleReceiptDataResponse, error) {
	//this.log.Debug("CheckAppleReceiptData", req)
	res, err := this.memberUseCase.CheckAppleReceiptData(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) GetMemberPunishTotalData(ctx context.Context, req *v1.GetMemberPunishTotalDataRequest) (*v1.GetMemberPunishTotalDataResponse, error) {
	res, err := this.memberUseCase.GetMemberPunishTotalData(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) SetMemberGeTuiCid(ctx context.Context, req *v1.SetMemberGeTuiCidRequest) (*v1.SetMemberGeTuiCidResponse, error) {
	res, err := this.memberUseCase.SetMemberGeTuiCid(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *MemberService) CheckMemberToken(ctx context.Context, req *v1.CheckMemberTokenRequest) (*v1.CheckMemberTokenResponse, error) {
	res, err := this.memberUseCase.CheckMemberToken(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}
