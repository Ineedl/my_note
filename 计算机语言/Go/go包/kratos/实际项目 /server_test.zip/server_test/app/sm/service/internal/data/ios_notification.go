package data

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"io"
	"miyou/app/sm/service/internal/biz"
	v1 "miyou/gen/api/sm/service/v1"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"

	appstore "github.com/izniburak/appstore-notifications-go"
)

var _ biz.ApplePayVerifierRepo = (*applePayVerifierRepo)(nil)

// 常量定义
const (
	ProductionVerifyURL = "https://buy.itunes.apple.com/verifyReceipt"
	SandboxVerifyURL    = "https://sandbox.itunes.apple.com/verifyReceipt"
	StatusKey           = "status"
	ReceiptKey          = "receipt"
	LatestReceiptInfo   = "latest_receipt_info"
	InAppKey            = "in_app"
	EnvironmentKey      = "environment"
)

// 公钥缓存
var keyCache = sync.Map{}

// 验证状态码枚举
var statusMessages = map[int32]string{
	0:     "成功",
	21000: "App Store无法读取你提供的JSON数据",
	21002: "收据数据不符合格式",
	21003: "收据无法通过验证",
	21004: "提供的共享密钥和账户的共享密钥不一致",
	21005: "收据服务器当前不可用",
	21006: "收据有效但订阅已过期",
	21007: "测试环境收据发送到生产环境验证",
	21008: "生产环境收据发送到测试环境验证",
}

// ApplePayVerifier 苹果支付验证器
type applePayVerifierRepo struct {
	config *v1.ApplePayConfig
	client *http.Client
	log    *log.Helper
}

func NewApplePayConfig() *v1.ApplePayConfig {
	return &v1.ApplePayConfig{
		IsProduction: true,
		//Password:     "fb5d893005b449c1bb3b9e1f6bfe6d6d",
	}
}

// NewApplePayVerifier 创建新的苹果支付验证器
func NewApplePayVerifier(config *v1.ApplePayConfig, logger log.Logger) biz.ApplePayVerifierRepo {
	return &applePayVerifierRepo{
		config: config,
		client: &http.Client{
			Timeout: 10 * time.Second,
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
			},
		},
		log: log.NewHelper(log.With(logger, "module", "service/common")),
	}
}

// Verify 验证苹果支付收据
func (v *applePayVerifierRepo) VerifyIapPay(ctx context.Context, receiptData string, isSubscription bool) (*v1.PayItemRes, error) {
	// 1. 确定验证环境URL
	verifyURL := SandboxVerifyURL
	password := "fb5d893005b449c1bb3b9e1f6bfe6d6d"
	if v.config.IsProduction {
		verifyURL = ProductionVerifyURL
		password = "2cdb823875814925b76bf0abec778f90"
	}

	// 2. 构建请求体
	requestBody := map[string]interface{}{
		"receipt-data":             receiptData,
		"password":                 password,
		"exclude-old-transactions": true,
	}

	// 3. 发送验证请求
	resp, err := v.sendVerifyRequest(verifyURL, requestBody)
	if err != nil {
		return nil, fmt.Errorf("验证请求失败: %w", err)
	}
	//v.log.Debug("验证结果: %+v", resp)
	// 4. 处理环境切换（状态码21007）
	if resp.Status == 21007 {
		return v.verifyInSandbox(requestBody, isSubscription)
	}

	// 5. 处理验证结果
	return v.handleVerificationResult(resp, isSubscription)
}

// verifyInSandbox 在沙盒环境验证
func (v *applePayVerifierRepo) verifyInSandbox(requestBody map[string]interface{}, isSubscription bool) (*v1.PayItemRes, error) {
	resp, err := v.sendVerifyRequest(SandboxVerifyURL, requestBody)
	if err != nil {
		return nil, fmt.Errorf("沙盒验证失败: %w", err)
	}
	return v.handleVerificationResult(resp, isSubscription)
}

// sendVerifyRequest 发送验证请求
func (v *applePayVerifierRepo) sendVerifyRequest(url string, body map[string]interface{}) (*v1.VerifyResponse, error) {
	jsonBody, err := json.Marshal(body)
	if err != nil {
		return nil, fmt.Errorf("JSON编码失败: %w", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonBody))
	if err != nil {
		return nil, fmt.Errorf("创建请求失败: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := v.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP请求失败: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("服务器返回非200状态码: %d", resp.StatusCode)
	}

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("读取响应失败: %w", err)
	}
	//v.log.Debug("响应内容: %s", string(bodyBytes))
	var verifyResp v1.VerifyResponse
	if err := json.Unmarshal(bodyBytes, &verifyResp); err != nil {
		return nil, fmt.Errorf("JSON解析失败: %w", err)
	}

	return &verifyResp, nil
}

// handleVerificationResult 处理验证结果
func (v *applePayVerifierRepo) handleVerificationResult(resp *v1.VerifyResponse, isSubscription bool) (*v1.PayItemRes, error) {
	// 检查状态码
	if resp.Status != 0 {
		reason, ok := statusMessages[resp.Status]
		if !ok {
			reason = fmt.Sprintf("未知错误: %d", resp.Status)
		}
		return &v1.PayItemRes{
			Success: false,
			Reason:  reason,
		}, nil
	}

	// 获取最新交易信息
	latestTx, err := v.getLatestTransaction(resp)
	if err != nil {
		return nil, fmt.Errorf("获取交易信息失败: %w", err)
	}

	// 构建响应
	result := &v1.PayItemRes{
		Success:               true,
		TransactionId:         latestTx.TransactionId,
		OriginalTransactionId: latestTx.OriginalTransactionId,
		ProductId:             latestTx.ProductId,
		Environment:           resp.Environment,
	}
	// 使用时转换为 int64
	purchaseDateMs, err := strconv.ParseInt(latestTx.PurchaseDateMs, 10, 64)
	if err != nil {
		return nil, err
	}
	// 转换时间
	if purchaseDateMs > 0 {
		result.OriginStartTime = time.Unix(0, purchaseDateMs*int64(time.Millisecond)).Format(time.DateTime)
		result.StartTime = v.toLocalTime(purchaseDateMs).Format(time.DateTime)
	}

	// 使用时转换为 int64
	expiresDateMs, err := strconv.ParseInt(latestTx.ExpiresDateMs, 10, 64)
	if err != nil {
		return nil, err
	}
	if expiresDateMs > 0 {
		result.OriginEndTime = time.Unix(0, expiresDateMs*int64(time.Millisecond)).UTC().Format(time.DateTime)
		result.ExpiryTime = v.toLocalTime(expiresDateMs).Format(time.DateTime)
	}

	// 检查订阅状态
	if isSubscription && expiresDateMs > 0 {
		expiryTime := time.Unix(0, expiresDateMs*int64(time.Millisecond))
		if time.Now().After(expiryTime) {
			result.Success = false
			result.Reason = "订阅已过期"
		}
	}

	return result, nil
}

// getLatestTransaction 获取最新交易信息
func (v *applePayVerifierRepo) getLatestTransaction(resp *v1.VerifyResponse) (*v1.TransactionInfo, error) {
	// 优先使用latest_receipt_info（包含最新订阅状态）
	if len(resp.LatestReceiptInfo) > 0 {
		return findLatestTransaction(resp.LatestReceiptInfo), nil
	}

	// 回退到in_app
	if len(resp.Receipt.InApp) > 0 {
		return findLatestTransaction(resp.Receipt.InApp), nil
	}

	return nil, errors.New("未找到交易信息")
}

// findLatestTransaction 查找最新交易
func findLatestTransaction(transactions []*v1.TransactionInfo) *v1.TransactionInfo {
	var latest *v1.TransactionInfo
	for i := range transactions {
		tx := transactions[i]
		if latest == nil || tx.PurchaseDateMs > latest.PurchaseDateMs {
			latest = tx
		}
	}
	return latest
}

// toLocalTime 将毫秒时间戳转换为本地时间
func (v *applePayVerifierRepo) toLocalTime(millis int64) time.Time {
	return time.Unix(0, millis*int64(time.Millisecond)).Local()
}

// 加载 Apple 根证书
func loadAppleRootCert() (*ecdsa.PublicKey, error) {
	certPEM, err := os.ReadFile("../../pem/appleapns.pem")
	if err != nil {
		return nil, err
	}

	block, _ := pem.Decode(certPEM)
	if block == nil {
		return nil, errors.New("failed to parse certificate PEM")
	}

	cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		return nil, err
	}

	publicKey, ok := cert.PublicKey.(*ecdsa.PublicKey)
	if !ok {
		return nil, errors.New("证书中不是 ECDSA 公钥")
	}

	return publicKey, nil
}

func (v *applePayVerifierRepo) ParseAndVerifySignedPayload(signedPayload string) (*appstore.AppStoreServerNotification, error) {
	rootCert := "-----BEGIN CERTIFICATE-----\nMIICQzCCAcmgAwIBAgIILcX8iNLFS5UwCgYIKoZIzj0EAwMwZzEbMBkGA1UEAwwS\nQXBwbGUgUm9vdCBDQSAtIEczMSYwJAYDVQQLDB1BcHBsZSBDZXJ0aWZpY2F0aW9u\nIEF1dGhvcml0eTETMBEGA1UECgwKQXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwHhcN\nMTQwNDMwMTgxOTA2WhcNMzkwNDMwMTgxOTA2WjBnMRswGQYDVQQDDBJBcHBsZSBS\nb290IENBIC0gRzMxJjAkBgNVBAsMHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9y\naXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzB2MBAGByqGSM49\nAgEGBSuBBAAiA2IABJjpLz1AcqTtkyJygRMc3RCV8cWjTnHcFBbZDuWmBSp3ZHtf\nTjjTuxxEtX/1H7YyYl3J6YRbTzBPEVoA/VhYDKX1DyxNB0cTddqXl5dvMVztK517\nIDvYuVTZXpmkOlEKMaNCMEAwHQYDVR0OBBYEFLuw3qFYM4iapIqZ3r6966/ayySr\nMA8GA1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgEGMAoGCCqGSM49BAMDA2gA\nMGUCMQCD6cHEFl4aXTQY2e3v9GwOAEZLuN+yRhHFD/3meoyhpmvOwgPUnPWTxnS4\nat+qIxUCMG1mihDK1A3UT82NQz60imOlM27jbdoXt2QfyFMm+YhidDkLF1vLUagM\n6BgD56KyKA==\n-----END CERTIFICATE-----"
	if rootCert == "" {
		panic("Apple Root Cert not valid")
	}
	appStoreServerNotification := appstore.New(signedPayload, rootCert)
	//v.log.Debug("AppleNotification", appStoreServerNotification.IsValid)
	//v.log.Debug("Product Id: %s\n", appStoreServerNotification.TransactionInfo)
	return appStoreServerNotification, nil
}
