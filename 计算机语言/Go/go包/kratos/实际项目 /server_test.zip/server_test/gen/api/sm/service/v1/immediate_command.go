package v1

type ImmediateCommand struct {
	Id            int64                      `json:"id"`
	Name          string                     `json:"name"`            // 任务名
	MemberID      int64                      `json:"member_id"`       // 发送人id
	CarryMemberID int64                      `json:"carry_member_id"` // 接受人id
	CommitType    int32                      `json:"commit_type"`     // 1拍照提交  2文字提交
	LimitTime     int32                      `json:"limit_time"`      // 限时 单位s
	Describe      string                     `json:"describe"`        // 描述
	Status        int32                      `json:"status"`          // -1 被拒绝 1.发布中 2.完成 3.执行中 4.反馈中
	CommitData    ImmediateCommandCommitData `json:"commit_data"`     // 任务提交数据 json类型
	Evaluate      int32                      `json:"evaluate"`        // 评价 0 未评价 1 通过 2不通过
	StartTime     int64                      `json:"start_time"`      // 任务开始时间 秒级时间戳
	AcceptTime    int64                      `json:"accept_time"`     //任务被接受时间
	TodaySendNum  int                        `json:"today_send_num"`
}

type ImmediateCommandCommitData struct {
	Id      int64  `json:"id"`       //提交的任务id
	Text    string `json:"text"`     //文字提交
	ImageId string `json:"image_id"` //图片提交
}
