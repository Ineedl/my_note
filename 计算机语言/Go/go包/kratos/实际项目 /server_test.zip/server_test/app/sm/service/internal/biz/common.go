package biz

import (
	"context"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"fmt"
	sts20150401 "github.com/alibabacloud-go/sts-20150401/v2/client"
	"github.com/go-kratos/kratos/v2/log"
	"hash"
	"io"
	v1 "miyou/gen/api/sm/service/v1"
	utils "miyou/pkg/util"
	"time"
)

type AliCommonRepo interface {
	GetAliOssSts() (resToken *sts20150401.AssumeRoleResponseBodyCredentials, err error)
	SendPhoneCode(ctx context.Context, phoneNumber string, code string) (string, error)
	CheckRegisterCode(ctx context.Context, phoneNumber string, code string) error
	CheckForgetCode(ctx context.Context, phoneNumber string, code string) error
	SendRegisterCode(ctx context.Context, phoneNumber string, code string) error
	SendForgetCode(ctx context.Context, phoneNumber string, code string) error
	SendBindPhoneCode(ctx context.Context, phoneNumber string, code string) error
	CheckBindPhoneCode(ctx context.Context, phoneNumber string, code string) error
}

type AppConfigRepo interface {
	GetAllAppConfig(ctx context.Context) ([]*v1.AppConfig, error)
}

type CommonUseCase struct {
	log           *log.Helper
	aliCommonRepo AliCommonRepo
	appConfigRepo AppConfigRepo
}

func NewCommonUseCase(appConfigRepo AppConfigRepo, aliCommonRepo AliCommonRepo, logger log.Logger) *CommonUseCase {
	return &CommonUseCase{
		log:           log.NewHelper(log.With(logger, "module", "common/usecase/common")),
		aliCommonRepo: aliCommonRepo,
		appConfigRepo: appConfigRepo,
	}
}

func (this *CommonUseCase) SendRegisterLoginCode(ctx context.Context, req *v1.SendRegisterLoginCodeRequest) (*v1.SendRegisterLoginCodeResponse, error) {
	code := utils.GetRandomNumber(6)
	err := this.aliCommonRepo.SendRegisterCode(ctx, req.Phone, code)
	if err != nil {
		return nil, err
	}
	return &v1.SendRegisterLoginCodeResponse{}, nil
}

func (this *CommonUseCase) GetAliyunStsToken(ctx context.Context, req *v1.GetAliyunStsTokenRequest) (*v1.GetAliyunStsTokenResponse, error) {
	stsToken, err := this.aliCommonRepo.GetAliOssSts()
	if err != nil {
		return nil, err
	}

	expireEnd, _ := time.ParseInLocation("2006-01-02T15:04:05Z", *stsToken.Expiration, time.UTC)
	//expireEnd, _ := utils.StrToDateTime(*stsToken.Expiration)
	uploadStamp := time.Now().Format("2006-01-02")

	dir := fmt.Sprintf("miyou/%s", uploadStamp)
	//create post policy json
	var config struct {
		Expiration string     `json:"expiration"`
		Conditions [][]string `json:"conditions"`
	}
	var tokenExpire = *stsToken.Expiration
	config.Expiration = tokenExpire
	var condition []string
	condition = append(condition, "starts-with")
	condition = append(condition, "$key")
	condition = append(condition, dir)
	config.Conditions = append(config.Conditions, condition)

	//calucate signature
	result, err := json.Marshal(config)
	deByte := base64.StdEncoding.EncodeToString(result)
	h := hmac.New(func() hash.Hash { return sha1.New() }, []byte(*stsToken.AccessKeySecret))
	io.WriteString(h, deByte)
	signedStr := base64.StdEncoding.EncodeToString(h.Sum(nil))
	policyToken := &v1.GetAliyunStsTokenResponse{}
	policyToken.Accessid = *stsToken.AccessKeyId
	policyToken.AccessKeySecret = *stsToken.AccessKeySecret
	policyToken.Host = "https://lovetame.oss-cn-shanghai.aliyuncs.com"
	policyToken.Expire = expireEnd.Local().Unix()
	policyToken.Signature = signedStr
	policyToken.Dir = dir
	policyToken.Policy = deByte
	policyToken.SecurityToken = *stsToken.SecurityToken
	fmt.Println(policyToken.Policy)
	//res, err := json.Marshal(policyToken)
	//if err != nil {
	//	fmt.Println("json err:", err)
	//}
	return policyToken, nil
}

func (this *CommonUseCase) GetAllAppConfig(ctx context.Context, req *v1.GetAllAppConfigRequest) (*v1.GetAllAppConfigResponse, error) {
	appConfig, err := this.appConfigRepo.GetAllAppConfig(ctx)
	if err != nil {
		return nil, err
	}
	return &v1.GetAllAppConfigResponse{
		Items: appConfig,
	}, nil
}
