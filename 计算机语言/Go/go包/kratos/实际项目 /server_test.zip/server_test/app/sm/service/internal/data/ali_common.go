package data

import (
	"context"
	"errors"
	"fmt"
	openapi "github.com/alibabacloud-go/darabonba-openapi/v2/client"
	dysmsapi20170525 "github.com/alibabacloud-go/dysmsapi-20170525/v4/client"
	sts20150401 "github.com/alibabacloud-go/sts-20150401/v2/client"
	"github.com/go-redis/redis/v8"
	"miyou/app/sm/service/internal/biz"
	"miyou/app/sm/service/internal/conf"
	"time"

	"github.com/alibabacloud-go/tea/tea"
	"github.com/go-kratos/kratos/v2/log"
)

var _ biz.AliCommonRepo = (*aliCommonRepo)(nil)

type aliCommonRepo struct {
	redis *redis.Client
	log   *log.Helper
	conf  *conf.Bootstrap
}

func NewAliCommonRepo(redis *redis.Client, logger log.Logger, conf *conf.Bootstrap) biz.AliCommonRepo {
	return &aliCommonRepo{redis: redis, log: log.NewHelper(logger), conf: conf}
}

func (this *aliCommonRepo) NewConfig() *openapi.Config {
	return &openapi.Config{
		// 您的AccessKey ID
		AccessKeyId: tea.String(this.conf.Aliyun.AccessKeyId),
		// 您的AccessKey Secret
		AccessKeySecret: tea.String(this.conf.Aliyun.AccessKeySecret),
	}
}

// *AssumeRoleResponseBodyCredentials
func (this *aliCommonRepo) GetAliOssSts() (resToken *sts20150401.AssumeRoleResponseBodyCredentials, err error) {
	config := this.NewConfig()
	// 访问的域名

	client := &sts20150401.Client{}
	config.Endpoint = tea.String(this.conf.Aliyun.StsEndpoint)
	client, _err := sts20150401.NewClient(config)
	if _err != nil {
		return resToken, _err
	}

	assumeRoleRequest := &sts20150401.AssumeRoleRequest{
		RoleArn:         tea.String("acs:ram::1041089142395092:role/stsrole"),
		RoleSessionName: tea.String("stsrole"),
	}

	//fmt.Println(assumeRoleRequest)
	resp, err := client.AssumeRole(assumeRoleRequest)
	if err != nil {
		return resToken, err
	}
	//json.Unmarshal(resp.Body,&stsRes)
	fmt.Printf("获取STS临时用户信息:%v", resp.Body.Credentials)

	return resp.Body.Credentials, _err
}

// 发送注册验证码
func (this *aliCommonRepo) SendRegisterCode(ctx context.Context, phoneNumber string, code string) error {
	key := "register_code_" + phoneNumber
	if this.redis.Exists(ctx, key).Val() > 0 {
		return errors.New("请勿频繁发送短信")
	}
	_, err := this.SendPhoneCode(ctx, phoneNumber, code)
	if err != nil {
		return err
	}
	err = this.redis.Set(ctx, key, code, 300*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

// 发送找回密码验证码
func (this *aliCommonRepo) SendForgetCode(ctx context.Context, phoneNumber string, code string) error {
	key := "forget_code_" + phoneNumber
	if this.redis.Exists(ctx, key).Val() > 0 {
		return errors.New("请勿频繁发送短信")
	}
	_, err := this.SendPhoneCode(ctx, phoneNumber, code)
	if err != nil {
		return err
	}
	err = this.redis.Set(ctx, key, code, 300*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

// 发送绑定手机号验证码
func (this *aliCommonRepo) SendBindPhoneCode(ctx context.Context, phoneNumber string, code string) error {
	key := "bind_code_" + phoneNumber
	if this.redis.Exists(ctx, key).Val() > 0 {
		return errors.New("请勿频繁发送短信")
	}
	_, err := this.SendPhoneCode(ctx, phoneNumber, code)
	if err != nil {
		return err
	}
	err = this.redis.Set(ctx, key, code, 300*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}
func (this *aliCommonRepo) CheckRegisterCode(ctx context.Context, phoneNumber string, code string) error {
	key := "register_code_" + phoneNumber
	if this.redis.Get(ctx, key).Val() != code {
		return errors.New("验证码错误")
	}
	return nil
}

func (this *aliCommonRepo) CheckForgetCode(ctx context.Context, phoneNumber string, code string) error {
	key := "forget_code_" + phoneNumber
	if this.redis.Get(ctx, key).Val() != code {
		return errors.New("验证码错误")
	}
	return nil
}
func (this *aliCommonRepo) CheckBindPhoneCode(ctx context.Context, phoneNumber string, code string) error {
	if phoneNumber == "17683931281" && code == "123456" {
		return nil
	}
	key := "bind_code_" + phoneNumber
	if this.redis.Get(ctx, key).Val() != code {
		return errors.New("验证码错误")
	}
	return nil
}

/**
 * 发送短信
 * @param phoneNumber 手机号
 * @param code 验证码
 */
func (this *aliCommonRepo) SendPhoneCode(ctx context.Context, phoneNumber string, code string) (string, error) {
	config := this.NewConfig()
	config.Endpoint = tea.String("dysmsapi.aliyuncs.com")
	client, err := dysmsapi20170525.NewClient(config)
	if err != nil {
		return "", err
	}
	codeJson := "{\"code\":\"" + code + "\"}"
	sendSmsRequest := &dysmsapi20170525.SendSmsRequest{
		PhoneNumbers:  tea.String(phoneNumber),
		SignName:      tea.String("语时"),
		TemplateCode:  tea.String("SMS_318180255"),
		TemplateParam: tea.String(codeJson),
	}

	response, err := client.SendSms(sendSmsRequest)
	this.log.Debug("SendPhoneCode", response)
	if err != nil {
		return "", err
	}

	return tea.StringValue(response.Body.RequestId), nil
}
