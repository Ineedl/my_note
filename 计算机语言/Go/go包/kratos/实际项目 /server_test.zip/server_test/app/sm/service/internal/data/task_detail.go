package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.TaskDetailRepo = (*taskDetailRepo)(nil)

type taskDetailRepo struct {
	data *Data
	log  *log.Helper
}

func NewTaskDetailRepo(data *Data, logger log.Logger) biz.TaskDetailRepo {
	return &taskDetailRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}
func (this *taskDetailRepo) CreateTaskDetail(ctx context.Context, fr *v1.TaskDetail) (*v1.TaskDetail, error) {
	frModel := this.tranProtocToModel(fr)
	return this.tranModelToProtoc(frModel), this.data.genQ.AppTaskDetail.WithContext(ctx).Create(frModel)
}

func (this *taskDetailRepo) DeleteTaskDetail(ctx context.Context, taskId int32) error {
	q := this.data.genQ.AppTaskDetail
	_, err := q.WithContext(ctx).Where(q.TaskID.Eq(taskId)).Unscoped().Delete()
	return err
}

func (this *taskDetailRepo) GetTaskDetailByDay(ctx context.Context, taskId int32, day string) (*v1.TaskDetail, error) {
	q := this.data.genQ.AppTaskDetail
	taskDetailList, err := q.WithContext(ctx).Where(q.TaskID.Eq(taskId), q.CompleteDay.Eq(day)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(taskDetailList), err
}

func (this *taskDetailRepo) GetTaskCompleteDayList(ctx context.Context, taskId int32) ([]string, error) {
	q := this.data.genQ.AppTaskDetail
	taskDetailList, err := q.WithContext(ctx).Where(q.TaskID.Eq(taskId)).Find()
	if err != nil {
		return nil, err
	}
	var taskDetailListOut []string
	for _, v := range taskDetailList {
		taskDetailListOut = append(taskDetailListOut, v.CompleteDay)
	}
	return taskDetailListOut, nil
}

func (this *taskDetailRepo) GetTaskDetailList(ctx context.Context, taskId int32) ([]*v1.TaskDetail, error) {
	taskDetailList, err := this.data.genQ.AppTaskDetail.WithContext(ctx).Where(this.data.genQ.AppTaskDetail.TaskID.Eq(taskId)).Find()
	if err != nil {
		return nil, err
	}
	var taskDetailListOut []*v1.TaskDetail
	for _, taskDetail := range taskDetailList {
		taskDetailListOut = append(taskDetailListOut, this.tranModelToProtoc(taskDetail))
	}
	return taskDetailListOut, nil
}

func (this *taskDetailRepo) tranProtocToModel(in *v1.TaskDetail) *model.AppTaskDetail {
	out := &model.AppTaskDetail{}
	out.ID = in.TaskDetailId
	out.TaskID = in.TaskId
	out.CompleteDay = in.CompleteDay
	out.CarryMemberDone = in.CarryMemberDone
	out.MemberConfirmed = in.MemberConfirmed
	return out
}

func (this *taskDetailRepo) tranModelToProtoc(in *model.AppTaskDetail) *v1.TaskDetail {
	out := &v1.TaskDetail{}
	out.TaskDetailId = in.ID
	out.TaskId = in.TaskID
	out.CompleteDay = in.CompleteDay
	out.CarryMemberDone = in.CarryMemberDone
	out.MemberConfirmed = in.MemberConfirmed
	return out
}
