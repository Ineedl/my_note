package indi.cjh.dao;

import indi.cjh.beanclass.Goods;

public interface GoodsDao {
    int updateGoods(Goods good);

    Goods selectGoods(Integer id);
}
