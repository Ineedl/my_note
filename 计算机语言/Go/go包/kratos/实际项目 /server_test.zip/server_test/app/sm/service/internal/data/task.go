package data

import (
	"context"
	"errors"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	utils "miyou/pkg/util"
	"regexp"
)

var _ biz.TaskRepo = (*taskRepo)(nil)

type taskRepo struct {
	data *Data
	log  *log.Helper
}

func NewTaskRepo(data *Data, logger log.Logger) biz.TaskRepo {
	return &taskRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *taskRepo) CreateTask(ctx context.Context, fr *v1.Task) (*v1.Task, error) {
	frModel := this.tranProtocToModel(fr)
	err := this.data.genQ.AppTask.WithContext(ctx).Create(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *taskRepo) GetTaskById(ctx context.Context, id int32) (*v1.Task, error) {
	q := this.data.genQ.AppTask
	out, err := q.WithContext(ctx).Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *taskRepo) UpdateTask(ctx context.Context, fr *v1.Task) (*v1.Task, error) {
	frModel := this.tranProtocToModel(fr)
	q := this.data.genQ.AppTask
	_, err := q.WithContext(ctx).Where(q.ID.Eq(frModel.ID)).Updates(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *taskRepo) DeleteTask(ctx context.Context, id int32) error {
	q := this.data.genQ.AppTask
	_, err := q.WithContext(ctx).Where(q.ID.Eq(id)).Unscoped().Delete()
	if err != nil {
		return err
	}
	return nil
}

func (this *taskRepo) GetTaskDays(ctx context.Context, uid int32, mid int32) ([]string, error) {
	m := this.data.genQ.AppFriendRelation
	u, _ := m.WithContext(ctx).Where(m.UserAID.Eq(uid), m.UserBID.Eq(mid)).First()

	type r struct {
		Date string `json:"date"`
	}
	results := make([]r, 0)
	var err error
	if u.UserBAttribute == "M" {
		err = this.data.db.Debug().Raw("select date_format(task_start_time,'%Y-%m-%d') as date from app_task where member_id = ? and carry_member_id = ? group by date_format(task_start_time,'%Y-%m-%d')", uid, mid).Scan(&results).Error
	}
	if u.UserBAttribute == "S" {
		err = this.data.db.Debug().Raw("select date_format(task_start_time,'%Y-%m-%d') as date from app_task where member_id = ? and carry_member_id = ? group by date_format(task_start_time,'%Y-%m-%d')", mid, uid).Scan(&results).Error
	}
	if err != nil {
		return nil, err
	}
	res := make([]string, len(results))
	for i, v := range results {
		res[i] = v.Date
	}
	return res, nil
}

func (this *taskRepo) GetTaskList(ctx context.Context, uid int32, request *v1.GetTaskListRequest) ([]*v1.Task, error) {
	q := this.data.genQ.AppTask
	query := q.Debug().WithContext(ctx).Where(q.Where(q.MemberID.Eq(uid)).Or(q.CarryMemberID.Eq(uid)))

	if request.Date != "" {
		re := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}$`)
		if !re.MatchString(request.Date) {
			return nil, errors.New("日期格式错误")
		}
		dataTime, _ := utils.StrToDate(request.Date)
		d := dataTime.Format(utils.TimeFormat)
		query = query.Where(q.TaskStartTime.Lte(d+" 00:00:00"), q.TaskEndTime.Gte(d+" 23:59:59"))
	}
	list, err := query.Find()

	if err != nil {
		return nil, err
	}
	out := make([]*v1.Task, 0)
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *taskRepo) GetTaskPunishList(ctx context.Context, uid int32, request *v1.GetTaskPunishListRequest) ([]*v1.Task, error) {
	q := this.data.genQ.AppTask
	query := q.Debug().WithContext(ctx).Where(q.Where(q.MemberID.Eq(uid)).Or(q.CarryMemberID.Eq(uid)))
	query = q.Where(q.PunishStatus.Neq(0))
	if request.Date != "" {
		re := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}$`)
		if !re.MatchString(request.Date) {
			return nil, errors.New("日期格式错误")
		}
		dataTime, _ := utils.StrToDate(request.Date)
		d := dataTime.Format(utils.TimeFormat)
		query = query.Where(q.TaskStartTime.Lte(d+" 00:00:00"), q.TaskEndTime.Gte(d+" 23:59:59"))
	}
	list, err := query.Find()

	if err != nil {
		return nil, err
	}
	out := make([]*v1.Task, 0)
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *taskRepo) GetInProgressTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error) {
	//q := this.data.genQ.AppTask
	//c, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(memberId), q.CarryMemberID.Eq(carryMemberId)), q.TaskStatus.Neq(2), q.TaskStatus.Neq(4)).Count()
	//return c, err
	t := this.data.genQ.AppTask
	tt := this.data.genQ.AppTaskType
	td := this.data.genQ.AppTaskDetail
	query := t.LeftJoin(tt, tt.ID.EqCol(t.TaskTypeID))
	c, err := query.WithContext(ctx).Where(t.Where(t.MemberID.Eq(memberId), t.CarryMemberID.Eq(carryMemberId))).
		Where(tt.TaskCycle.Eq(1), t.TaskStatus.Eq(1)).Count()
	if err != nil {
		return 0, err
	}
	dc, err := td.WithContext(ctx).
		LeftJoin(t, td.TaskID.EqCol(t.ID)).
		LeftJoin(tt, t.TaskTypeID.EqCol(tt.ID)).
		Where(
			tt.TaskCycle.Eq(2),       // 打卡任务
			td.MemberConfirmed.Eq(1), // 发布者未确认
		).
		Count()
	if err != nil {
		return 0, err
	}
	return dc + c, err
}

func (this *taskRepo) GetCompletedTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error) {
	//q := this.data.genQ.AppTask
	//c, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(memberId), q.CarryMemberID.Eq(carryMemberId)), q.TaskStatus.Neq(2)).Count()
	//return c, err
	t := this.data.genQ.AppTask
	tt := this.data.genQ.AppTaskType
	td := this.data.genQ.AppTaskDetail
	query := t.LeftJoin(tt, tt.ID.EqCol(t.TaskTypeID))
	c, err := query.WithContext(ctx).Where(t.Where(t.MemberID.Eq(memberId), t.CarryMemberID.Eq(carryMemberId))).
		Where(tt.TaskCycle.Eq(1), t.TaskStatus.Eq(2)).Count()
	if err != nil {
		return 0, err
	}
	dc, err := td.WithContext(ctx).
		LeftJoin(t, td.TaskID.EqCol(t.ID)).
		LeftJoin(tt, t.TaskTypeID.EqCol(tt.ID)).
		Where(
			tt.TaskCycle.Eq(2),       // 打卡任务
			td.MemberConfirmed.Eq(2), // 发布者未确认
		).
		Count()
	if err != nil {
		return 0, err
	}
	return dc + c, err
}

func (this *taskRepo) GetTotalTaskCount(ctx context.Context, memberId int32, carryMemberId int32) (int64, error) {
	//q := this.data.genQ.AppTask
	//c, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(memberId), q.CarryMemberID.Eq(carryMemberId))).Count()
	//return c, err
	t := this.data.genQ.AppTask
	tt := this.data.genQ.AppTaskType
	td := this.data.genQ.AppTaskDetail
	query := t.LeftJoin(tt, tt.ID.EqCol(t.TaskTypeID))
	c, err := query.WithContext(ctx).Where(t.Where(t.MemberID.Eq(memberId), t.CarryMemberID.Eq(carryMemberId))).
		Count()
	if err != nil {
		return 0, err
	}
	dc, err := td.WithContext(ctx).
		LeftJoin(t, td.TaskID.EqCol(t.ID)).
		LeftJoin(tt, t.TaskTypeID.EqCol(tt.ID)).
		Where(
			tt.TaskCycle.Eq(2), // 打卡任务
		).
		Count()
	if err != nil {
		return 0, err
	}
	return dc + c, err
}

func (this *taskRepo) NotCompletedTask(ctx context.Context, memberId int32, carryMemberId int32) (int64, error) {
	t := this.data.genQ.AppTask
	tt := this.data.genQ.AppTaskType
	td := this.data.genQ.AppTaskDetail
	query := t.LeftJoin(tt, tt.ID.EqCol(t.TaskTypeID))
	c, err := query.WithContext(ctx).Where(t.Where(t.MemberID.Eq(memberId), t.CarryMemberID.Eq(carryMemberId))).
		Where(tt.TaskCycle.Eq(1), t.PunishStatus.Neq(-1)).Count()
	if err != nil {
		return 0, err
	}
	dc, err := td.WithContext(ctx).
		LeftJoin(t, td.TaskID.EqCol(t.ID)).
		LeftJoin(tt, t.TaskTypeID.EqCol(tt.ID)).
		Where(
			tt.TaskCycle.Eq(2),        // 打卡任务
			td.MemberConfirmed.Neq(2), // 发布者未确认
		).
		Count()
	if err != nil {
		return 0, err
	}
	return dc + c, err
}

func (this *taskRepo) GetInProgressTaskList(ctx context.Context, memberId int32, carryMemberId int32) ([]*v1.Task, error) {
	q := this.data.genQ.AppTask
	c, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(memberId), q.CarryMemberID.Eq(carryMemberId)), q.TaskStatus.Neq(2), q.TaskStatus.Neq(4)).Find()
	out := make([]*v1.Task, 0)
	for _, v := range c {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, err
}

func (this *taskRepo) tranProtocToModel(in *v1.Task) *model.AppTask {
	out := &model.AppTask{}
	out.ID = in.TaskId
	out.MemberID = in.MemberId
	out.CarryMemberID = in.CarryMemberId
	out.TaskTypeID = in.TaskTypeId
	out.PunishTypeID = in.PunishTypeId
	out.TaskStartTime = in.TaskStartTime
	out.TaskEndTime = in.TaskEndTime
	out.TaskStatus = in.TaskStatus
	out.PunishStatus = in.PunishStatus
	out.TaskDes = in.TaskDes
	out.TaskType = in.TaskType
	return out
}

func (this *taskRepo) tranModelToProtoc(in *model.AppTask) *v1.Task {
	out := &v1.Task{}
	out.TaskId = in.ID
	out.MemberId = in.MemberID
	out.CarryMemberId = in.CarryMemberID
	out.TaskTypeId = in.TaskTypeID
	out.PunishTypeId = in.PunishTypeID
	out.TaskStartTime = in.TaskStartTime
	out.TaskEndTime = in.TaskEndTime
	out.TaskStatus = in.TaskStatus
	out.PunishStatus = in.PunishStatus
	out.TaskDes = in.TaskDes
	out.TaskType = in.TaskType
	return out
}
