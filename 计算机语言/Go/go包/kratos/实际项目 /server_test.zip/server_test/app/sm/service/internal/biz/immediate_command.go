package biz

import (
	"context"
	v1 "miyou/gen/api/sm/service/v1"
)

type ImmediateCommandRepo interface {
	CreateImmediateCommand(ctx context.Context, fr *v1.ImmediateCommand) error
	//使用接收者获取最新的一个任务
	GetImmediateCommandByUserId(ctx context.Context, memberId, CarryMemberId int64) (*v1.ImmediateCommand, error)

	GetImmediateCommandByCommandId(ctx context.Context, id int64) (*v1.ImmediateCommand, error)
	//更新任务状态
	UpdateImmediateCommandStatus(ctx context.Context, fr *v1.ImmediateCommand) error
	//更新提交数据
	UpdateImmediateCommandCommitData(ctx context.Context, fr *v1.ImmediateCommand) error
	//更新评价
	UpdateImmediateCommandEvaluate(ctx context.Context, fr *v1.ImmediateCommand) error

	UpdateImmediateCommandAcceptTime(ctx context.Context, fr *v1.ImmediateCommand) error

	ImmediateCommandExpire(ctx context.Context, fr *v1.ImmediateCommand) (int, error)
}
