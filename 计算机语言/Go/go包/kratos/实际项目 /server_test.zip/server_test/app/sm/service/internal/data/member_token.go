package data

import (
	"context"
	"errors"
	"fmt"
	"github.com/go-kratos/kratos/v2/middleware/auth/jwt"
	"miyou/app/sm/service/internal/biz"
	"miyou/app/sm/service/internal/conf"
	v1 "miyou/gen/api/sm/service/v1"
	"strconv"
	"time"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-redis/redis/v8"
	jwtV5 "github.com/golang-jwt/jwt/v5"
)

var _ biz.MemberTokenRepo = (*memberTokenRepo)(nil)

// 官方的7个字段
const (
	ClaimID        = "jti" // 编号
	ClaimSubject   = "sub" // 主题
	ClaimIssuer    = "iss" // 签发人
	ClaimAudience  = "aud" // 受众
	ClaimExpiresAt = "exp" // 过期时间
	ClaimNotBefore = "nbf" // 生效时间
	ClaimIssuedAt  = "iat" // 签发时间
	ClaimScopes    = "scopes"
	ClaimUserId    = "userId"
	ClaimEnabled   = "enabled"
)

type memberTokenRepo struct {
	redis *redis.Client
	log   *log.Helper
	key   []byte
}

func NewMemberTokenRepo(redis *redis.Client, conf *conf.Bootstrap, logger log.Logger) biz.MemberTokenRepo {
	l := log.NewHelper(log.With(logger, "module", "user-token/repo/user-service"))
	return &memberTokenRepo{
		redis: redis,
		log:   l,
		key:   []byte(conf.Auth.ServiceKey),
	}
}

func (r *memberTokenRepo) createAccessJwtToken(username string, userId int32) string {
	nowTime := time.Now()

	claims := jwtV5.NewWithClaims(jwtV5.SigningMethodHS256,
		jwtV5.MapClaims{
			ClaimSubject:  username,
			ClaimUserId:   strconv.FormatUint(uint64(userId), 10),
			ClaimIssuedAt: nowTime.Unix(),
		})

	signedToken, err := claims.SignedString(r.key)
	if err != nil {
		return ""
	}

	return signedToken
}

func (r *memberTokenRepo) parseAccessJwtTokenFromString(token string) (string, int32, error) {
	parseAuth, err := jwtV5.Parse(token, func(*jwtV5.Token) (interface{}, error) {
		return r.key, nil
	})
	if err != nil {
		return "", 0, err
	}

	claims, ok := parseAuth.Claims.(jwtV5.MapClaims)
	if !ok {
		return "", 0, errors.New("no jwt token in context")
	}

	userName, userId, err := r.parseAccessJwtToken(claims)
	if err != nil {
		return "", 0, err
	}

	return userName, userId, nil
}

func (r *memberTokenRepo) ParesTokenData(token string) (string, int32, error) {
	return r.parseAccessJwtTokenFromString(token)
}
func (r *memberTokenRepo) parseAccessJwtToken(claims jwtV5.Claims) (string, int32, error) {
	if claims == nil {
		return "", 0, errors.New("claims is nil")
	}

	mc, ok := claims.(jwtV5.MapClaims)
	if !ok {
		return "", 0, errors.New("claims is not map claims")
	}

	var strUserName string
	userName, ok := mc[ClaimSubject]
	if ok {
		strUserName = userName.(string)
	}

	var userId int32
	strUserId, ok := mc[ClaimUserId]
	if ok {
		userId_, err := strconv.Atoi(strUserId.(string))
		if err != nil {
			return "", 0, err
		}
		userId = int32(userId_)
	}

	return strUserName, userId, nil
}

func (r *memberTokenRepo) GenerateToken(ctx context.Context, user *v1.Member) (string, error) {
	r.deleteToken(ctx, user.GetUserId())
	token := r.createAccessJwtToken(user.GetNickName(), user.GetUserId())
	if token == "" {
		return "", errors.New("create token failed")
	}

	err := r.setToken(ctx, user.GetUserId(), token)
	if err != nil {
		return "", err
	}

	return token, nil
}

func (r *memberTokenRepo) GetToken(ctx context.Context, userId int32) string {
	return r.getToken(ctx, userId)
}

func (r *memberTokenRepo) ParseFromContext(ctx context.Context) (string, uint32, error) {
	claims, ok := jwt.FromContext(ctx)
	if !ok {
		return "", 0, errors.New("no jwt token in context")
	}

	mc := *(claims.(*jwtV5.MapClaims))
	var strUserName string
	userName, ok := mc["sub"]
	if ok {
		strUserName = userName.(string)
	}

	var userId uint32
	strUserId, ok := mc["userId"]
	if ok {
		userId_, err := strconv.Atoi(strUserId.(string))
		if err != nil {
			return "", 0, err
		}
		userId = uint32(userId_)
	}

	return strUserName, userId, nil
}

func (r *memberTokenRepo) ValidateToken(ctx context.Context, token string) error {
	_, userId, err := r.parseAccessJwtTokenFromString(token)
	if err != nil {
		return errors.New("非法的令牌")
	}

	validToken := r.getToken(ctx, userId)
	if validToken == "" {
		return errors.New("令牌不存在")
	}

	return nil
}

func (r *memberTokenRepo) RemoveToken(ctx context.Context, userId int32) error {
	validToken := r.getToken(ctx, userId)
	if validToken == "" {
		return errors.New("令牌不存在")
	}

	return r.deleteToken(ctx, userId)
}

func (r *memberTokenRepo) RemoveUserToken(ctx context.Context, userId int32) error {
	validToken := r.getToken(ctx, userId)
	if validToken == "" {
		return errors.New("令牌不存在")
	}

	return r.deleteToken(ctx, userId)
}

const userTokenKeyPrefix = "miyou_"

func (r *memberTokenRepo) setToken(ctx context.Context, userId int32, token string) error {
	key := fmt.Sprintf("%s%d", userTokenKeyPrefix, userId)
	return r.redis.Set(ctx, key, token, 0).Err()
}

func (r *memberTokenRepo) getToken(ctx context.Context, userId int32) string {
	key := fmt.Sprintf("%s%d", userTokenKeyPrefix, userId)
	result, err := r.redis.Get(ctx, key).Result()
	if err != nil {
		if err != redis.Nil {
			r.log.Errorf("get redis user token failed: %s", err.Error())
		}
		return ""
	}
	return result
}

func (r *memberTokenRepo) RefreshToken(ctx context.Context) (string, error) {
	// 1. 解析旧 Token
	username, userId, err := r.ParseFromContext(ctx)
	if err != nil {
		return "", errors.New("无效的令牌")
	}
	uid := int32(userId)
	// 2. 获取用户信息
	userKey := fmt.Sprintf("%s%d", userTokenKeyPrefix, uid)
	userInfo, err := r.redis.Get(ctx, userKey).Result()
	if err != nil || userInfo == "" {
		return "", errors.New("用户不存在或令牌已失效")
	}

	// 3. 生成新的 Token
	newToken := r.createAccessJwtToken(username, uid)
	if newToken == "" {
		return "", errors.New("创建新令牌失败")
	}

	// 4. 更新 Redis 中的 Token
	err = r.setToken(ctx, uid, newToken)
	if err != nil {
		return "", err
	}

	// 5. 返回新 Token
	return newToken, nil
}

func (r *memberTokenRepo) deleteToken(ctx context.Context, userId int32) error {
	key := fmt.Sprintf("%s%d", userTokenKeyPrefix, userId)
	return r.redis.Del(ctx, key).Err()
}
