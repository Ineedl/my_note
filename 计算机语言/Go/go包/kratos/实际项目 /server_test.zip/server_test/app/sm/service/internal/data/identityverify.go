package data

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"gorm.io/gorm"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.IdentityVerifyRepo = (*identityVerifyRepo)(nil)

type identityVerifyRepo struct {
	data *Data
	log  *log.Helper
}

func NewIdentityVerifyRepo(data *Data, logger log.Logger) biz.IdentityVerifyRepo {
	return &identityVerifyRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *identityVerifyRepo) CreateUserIdentity(ctx context.Context, info *v1.IdentityVerifyInfo) error {
	q := this.data.genQ.AppIdentityVerify
	out, err := q.WithContext(ctx).Where(q.UserID.Eq(info.UserId)).First()
	if err != nil && err != gorm.ErrRecordNotFound {
		return err
	}
	if out != nil {
		return fmt.Errorf("user identity already exists")
	}
	c := model.AppIdentityVerify{
		ID:           0,
		UserID:       info.UserId,
		Name:         info.Name,
		IdentityCard: info.IdentityCard,
	}
	err = q.WithContext(ctx).Create(&c)
	if err != nil {
		return err
	}
	return nil
}

func (this *identityVerifyRepo) QueryUserIdentity(ctx context.Context, userId int64) (*v1.IdentityVerifyInfo, error) {
	q := this.data.genQ.AppIdentityVerify
	out, err := q.WithContext(ctx).Where(q.UserID.Eq(userId)).First()
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return &v1.IdentityVerifyInfo{
		UserId:       out.UserID,
		Name:         out.Name,
		IdentityCard: out.IdentityCard,
	}, nil
}
