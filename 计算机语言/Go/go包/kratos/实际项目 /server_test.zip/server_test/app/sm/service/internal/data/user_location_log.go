package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	utils "miyou/pkg/util"
)

var _ biz.UserLocationLogRepo = (*userLocationLogRepo)(nil)

type userLocationLogRepo struct {
	data *Data
	log  *log.Helper
}

func NewUserLocationLogRepo(data *Data, logger log.Logger) biz.UserLocationLogRepo {
	return &userLocationLogRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *userLocationLogRepo) CreateUserLocationLog(ctx context.Context, in *v1.UserLocationLog) (*v1.UserLocationLog, error) {
	model := this.tranProtocToModel(in)
	q := this.data.genQ.AppUserLocationLog
	err := q.WithContext(ctx).Create(model)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(model), nil
}

func (this *userLocationLogRepo) GetUserLocationLog(ctx context.Context, req *v1.GetUserLocationLogRequest) ([]*v1.UserLocationLog, error) {
	q := this.data.genQ.AppUserLocationLog
	start, _ := utils.StrToDateTime(req.StartTime)
	end, _ := utils.StrToDateTime(req.EndTime)
	list, err := q.WithContext(ctx).Where(q.UserID.Eq(req.UserId), q.DataTime.Between(start.Format(utils.TimeFormat), end.Format(utils.TimeFormat))).Order(q.DataTime.Desc()).Find()
	if err != nil {
		return nil, err
	}
	l := make([]*v1.UserLocationLog, 0)
	for _, v := range list {
		l = append(l, this.tranModelToProtoc(v))
	}
	return l, nil
}

func (this *userLocationLogRepo) tranProtocToModel(in *v1.UserLocationLog) *model.AppUserLocationLog {
	out := &model.AppUserLocationLog{}
	out.UserID = in.UserId
	out.State = in.State
	out.DurationSeconds = in.DurationSeconds
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.StartLocationDescription = in.StartLocationDescription
	out.EndLocationDescription = in.EndLocationDescription
	out.DataTime = in.DataTime
	out.StartTime = in.StartTime
	out.EndTime = in.EndTime
	out.ScreenUseTime = in.ScreenUseTime
	out.UnlockPhoneCount = in.UnlockPhoneCount
	out.SystemInfoDescription = in.SystemInfoDescription
	return out
}

func (this *userLocationLogRepo) tranModelToProtoc(in *model.AppUserLocationLog) *v1.UserLocationLog {
	out := &v1.UserLocationLog{}
	out.UserId = in.UserID
	out.State = in.State
	out.DurationSeconds = in.DurationSeconds
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.StartLocationDescription = in.StartLocationDescription
	out.EndLocationDescription = in.EndLocationDescription
	out.DataTime = in.DataTime
	out.StartTime = in.StartTime
	out.EndTime = in.EndTime
	out.ScreenUseTime = in.ScreenUseTime
	out.UnlockPhoneCount = in.UnlockPhoneCount
	out.SystemInfoDescription = in.SystemInfoDescription
	return out
}
