package biz

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"miyou/app/sm/service/internal/conf"
	"miyou/app/sm/service/internal/def"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	"miyou/pkg/service"
	utils "miyou/pkg/util"
	http2 "net/http"
	"strings"
	"time"

	alipay2 "github.com/go-pay/gopay/alipay"
	"github.com/go-pay/gopay/wechat/v3"

	"github.com/MicahParks/keyfunc"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/transport/http"
	"github.com/go-pay/gopay"
	"github.com/go-pay/gopay/alipay/v3"
	"github.com/go-redis/redis/v8"
	"github.com/golang-jwt/jwt/v4"
	"github.com/google/uuid"
	appstore "github.com/izniburak/appstore-notifications-go"
	"github.com/tx7do/kratos-transport/broker"
)

type CreateOrderRequest struct {
	PayType   string `json:"pay_type"`
	ProductId string `json:"product_id"`
}

// CreateOrderResponse 创建订单响应
type CreateOrderResponse struct {
	OutTradeNo  string               `json:"out_trade_no"`
	PayStr      string               `json:"pay_str"`
	PayAppParam *wechat.AppPayParams `json:"pay_app_param"`
}

// AliPayNotifyData 支付宝通知数据结构
type AliPayNotifyData struct {
	AppID              string `json:"app_id"`
	AuthAppID          string `json:"auth_app_id"`
	Charset            string `json:"charset"`
	OutTradeNo         string `json:"out_trade_no"`
	TradeNo            string `json:"trade_no"`
	TradeStatus        string `json:"trade_status"`
	TotalAmount        string `json:"total_amount"`
	ReceiptAmount      string `json:"receipt_amount"`
	BuyerPayAmount     string `json:"buyer_pay_amount"`
	PointAmount        string `json:"point_amount"`
	InvoiceAmount      string `json:"invoice_amount"`
	BuyerID            string `json:"buyer_id"`
	BuyerLogonID       string `json:"buyer_logon_id"`
	FundBillList       string `json:"fund_bill_list"`
	GmtPayment         string `json:"gmt_payment"`
	GmtCreate          string `json:"gmt_create"`
	GmtRefund          string `json:"gmt_refund"`
	GmtClose           string `json:"gmt_close"`
	Subject            string `json:"subject"`
	Body               string `json:"body"`
	AlipayStoreID      string `json:"alipay_store_id"`
	StoreID            string `json:"store_id"`
	TerminalID         string `json:"terminal_id"`
	IndustrySpecDetail string `json:"industry_sepc_detail"`
	PassbackParams     string `json:"passback_params"`
	VoucherDetailList  string `json:"voucher_detail_list"`
	Sign               string `json:"sign"`
	SignType           string `json:"sign_type"`
}

// WechatPayNotifyData 微信支付通知数据结构
type WechatPayNotifyData struct {
	ReturnCode         string `xml:"return_code"`
	ReturnMsg          string `xml:"return_msg"`
	ResultCode         string `xml:"result_code"`
	ErrCode            string `xml:"err_code"`
	ErrCodeDes         string `xml:"err_code_des"`
	AppID              string `xml:"appid"`
	MchID              string `xml:"mch_id"`
	DeviceInfo         string `xml:"device_info"`
	NonceStr           string `xml:"nonce_str"`
	Sign               string `xml:"sign"`
	SignType           string `xml:"sign_type"`
	OpenID             string `xml:"openid"`
	IsSubscribe        string `xml:"is_subscribe"`
	TradeType          string `xml:"trade_type"`
	BankType           string `xml:"bank_type"`
	TotalFee           int32  `xml:"total_fee"`
	SettlementTotalFee int32  `xml:"settlement_total_fee"`
	FeeType            string `xml:"fee_type"`
	CashFee            int32  `xml:"cash_fee"`
	CashFeeType        string `xml:"cash_fee_type"`
	CouponFee          int32  `xml:"coupon_fee"`
	CouponCount        int32  `xml:"coupon_count"`
	CouponType0        string `xml:"coupon_type_0"`
	CouponID0          string `xml:"coupon_id_0"`
	CouponFee0         int32  `xml:"coupon_fee_0"`
	TransactionID      string `xml:"transaction_id"`
	OutTradeNo         string `xml:"out_trade_no"`
	Attach             string `xml:"attach"`
	TimeEnd            string `xml:"time_end"`
}

type MemberRepo interface {
	GetMemberById(context.Context, int32) (*v1.Member, error)
	GetMemberModelById(context.Context, int32) (*model.AppMember, error)
	DecryptPhone(ctx context.Context, code string) (string, error)
	GetMemberByPhone(context.Context, string) (*v1.Member, error)
	GetMemberByAppleCode(ctx context.Context, appleId string) (*v1.Member, error)
	CreateMember(ctx context.Context, order *v1.Member) (*v1.Member, error)
	GetLoginTokenData(ctx context.Context, loginToken string) (string, error)
	UpdateMember(ctx context.Context, member *v1.Member) (*v1.Member, error)
	FindMemberFriends(ctx context.Context, userId int32, page int32, size int32) ([]*v1.MemberFriend, int32, error)

	GetMemberByInviteCode(ctx context.Context, code string) (*v1.Member, error)
	DeleteMember(ctx context.Context, id int32) error
}

type MemberTokenRepo interface {
	GetToken(ctx context.Context, userId int32) string
	ValidateToken(ctx context.Context, token string) error
	GenerateToken(ctx context.Context, user *v1.Member) (string, error)
	RemoveToken(ctx context.Context, userId int32) error
	ParseFromContext(ctx context.Context) (string, uint32, error)
	RefreshToken(ctx context.Context) (string, error)
	ParesTokenData(token string) (string, int32, error)
}

type FriendsRelationsRepo interface {
	CreateFriendRelations(ctx context.Context, fr *v1.FriendRelations) (*v1.FriendRelations, error)
	GetMemberApplyList(ctx context.Context, mid int32) ([]*v1.FriendRelations, error)
	GetMemberFriendRelationByAAndBid(ctx context.Context, aid int32, bid int32) (*v1.FriendRelations, error)
	GetFriendRelationById(ctx context.Context, id int32) (*v1.FriendRelations, error)
	UpdateFriendRelation(ctx context.Context, fr *v1.FriendRelations) (*v1.FriendRelations, error)
	FriendIdsByUserId(ctx context.Context, userId int32) ([]int32, error)
	DeleteFriendRelation(ctx context.Context, userId int32, frid int32) error
	GetMyFriendIsShowLocation(ctx context.Context, userId int32, frid int32) (int32, error)
}

type MemberOnlineStatusRepo interface {
	UserUpLoadOnlineStatus(ctx context.Context, in *v1.MemberOnlineStatus) error
	UserOnLine(ctx context.Context, userId int32) error
	UserOffLine(ctx context.Context, userId int32) error
	GetUserOnlineStatusListByIds(ctx context.Context, userIds []int32) ([]*v1.MemberOnlineStatus, error)
	GetMemberOnlineStatusByMemberId(ctx context.Context, userId int32) (*v1.MemberOnlineStatus, error)
}

type UserLocationLogRepo interface {
	CreateUserLocationLog(ctx context.Context, in *v1.UserLocationLog) (*v1.UserLocationLog, error)
	GetUserLocationLog(ctx context.Context, req *v1.GetUserLocationLogRequest) ([]*v1.UserLocationLog, error)
}

type TuiPushRepo interface {
}

type ApplePayVerifierRepo interface {
	VerifyIapPay(ctx context.Context, receiptData string, isSubscription bool) (*v1.PayItemRes, error)
	ParseAndVerifySignedPayload(signedPayload string) (*appstore.AppStoreServerNotification, error)
}

type IapOrderRepo interface {
	CreateIapOrder(ctx context.Context, in *v1.IapOrder) (*v1.IapOrder, error)
	GetIapOrderByOriginalTransactionID(ctx context.Context, originalTransactionID string) (*v1.IapOrder, error)
}

type IapPayRepo interface {
	CreateIapPay(ctx context.Context, in *v1.IapPay) (*v1.IapPay, error)
	UpdateIapPay(ctx context.Context, in *v1.IapPay) (*v1.IapPay, error)
}

type PayOrderInfoRepo interface {
	CreateOrder(ctx context.Context, in *model.AppOrderInfo) (*model.AppOrderInfo, error)
	GetOrderInfoByOrderId(ctx context.Context, orderId string) (*model.AppOrderInfo, error)
	UpdatePayOrder(ctx context.Context, in *model.AppOrderInfo) error
}

type MemberUseCase struct {
	log                    *log.Helper
	memberRepo             MemberRepo
	memberTokenRepo        MemberTokenRepo
	aliCommonRepo          AliCommonRepo
	friendsRelationsRepo   FriendsRelationsRepo
	memberOnlineStatusRepo MemberOnlineStatusRepo
	userLocationLogRepo    UserLocationLogRepo
	redis                  *redis.Client
	applePayVerifierRepo   ApplePayVerifierRepo
	iapPayRepo             IapPayRepo
	iapOrderRepo           IapOrderRepo
	punishTypeRepo         PunishTypeRepo
	nsqBroker              broker.Broker
	conf                   *conf.Bootstrap
	payOrderInfoRepo       PayOrderInfoRepo
}

func NewMemberUseCase(iapPayRepo IapPayRepo,
	applePayVerifierRepo ApplePayVerifierRepo,
	redis *redis.Client,
	userLocationLogRepo UserLocationLogRepo,
	memberOnlineStatusRepo MemberOnlineStatusRepo,
	friendsRelationsRepo FriendsRelationsRepo,
	aliCommonRepo AliCommonRepo,
	memberTokenRepo MemberTokenRepo,
	memberRepo MemberRepo,
	iapOrderRepo IapOrderRepo,
	punishTypeRepo PunishTypeRepo,
	payOrderInfoRepo PayOrderInfoRepo,
	nsqBroker broker.Broker,
	conf *conf.Bootstrap,
	logger log.Logger) *MemberUseCase {
	return &MemberUseCase{
		iapPayRepo:             iapPayRepo,
		applePayVerifierRepo:   applePayVerifierRepo,
		redis:                  redis,
		userLocationLogRepo:    userLocationLogRepo,
		memberOnlineStatusRepo: memberOnlineStatusRepo,
		friendsRelationsRepo:   friendsRelationsRepo,
		aliCommonRepo:          aliCommonRepo,
		memberTokenRepo:        memberTokenRepo,
		memberRepo:             memberRepo,
		iapOrderRepo:           iapOrderRepo,
		punishTypeRepo:         punishTypeRepo,
		payOrderInfoRepo:       payOrderInfoRepo,
		nsqBroker:              nsqBroker,
		conf:                   conf,
		log:                    log.NewHelper(logger)}
}

func (this *MemberUseCase) MemberLoginByPhone(ctx context.Context, req *v1.MemberLoginRequest) (*v1.MemberLoginResponse, error) {
	phoneStr, err := this.memberRepo.GetLoginTokenData(ctx, req.Code)
	if err != nil {
		return nil, err
	}
	phone, err := this.memberRepo.DecryptPhone(ctx, phoneStr)
	if err != nil {
		return nil, err
	}
	var m *v1.Member
	var isRegister int32
	exist, _ := this.memberRepo.GetMemberByPhone(ctx, phone)
	if exist == nil {
		tmp := &v1.Member{
			Phone:        phone,
			NickName:     "密友用户",
			InviteCode:   utils.GetRandomString(6),
			RegisterTime: time.Now().Format(utils.TimeFormat),
			LoginTime:    time.Now().Format(utils.TimeFormat),
			VipExpire:    time.Now().AddDate(0, 0, 7).Format(utils.TimeFormat),
		}
		isRegister = 1
		m, err = this.memberRepo.CreateMember(ctx, tmp)
		if err != nil {
			return nil, err
		}
	} else {
		m = exist
		m.LoginTime = time.Now().Format(utils.TimeFormat)
		_, err = this.memberRepo.UpdateMember(ctx, m)
		if err != nil {
			return nil, err
		}
	}
	token, err := this.memberTokenRepo.GenerateToken(ctx, m)
	if err != nil {
		return nil, err
	}
	return &v1.MemberLoginResponse{
		Member:     m,
		Token:      token,
		IsRegister: isRegister,
	}, nil
}

func (this *MemberUseCase) PhoneCodeLogin(ctx context.Context, req *v1.PhoneCodeLoginRequest) (*v1.PhoneCodeLoginResponse, error) {
	var err error
	if (req.Phone == "17764216996" && req.Code == "123456") || (req.Phone == "17340532022" && req.Code == "123456") || (req.Phone == "18571636860" && req.Code == "123456") || (req.Phone == "18971109247" && req.Code == "393848") {

	} else {
		if req.Code == "" {
			return nil, v1.ErrorApiError("验证码不能为空")
		}
		err := this.aliCommonRepo.CheckRegisterCode(ctx, req.Phone, req.Code)
		if err != nil {
			return nil, err
		}
	}

	var m *v1.Member
	var isRegister int32
	exist, _ := this.memberRepo.GetMemberByPhone(ctx, req.Phone)
	if exist == nil {
		tmp := &v1.Member{
			Phone:        req.Phone,
			NickName:     "密友用户",
			InviteCode:   utils.GetRandomString(6),
			RegisterTime: time.Now().Format(utils.TimeFormat),
			LoginTime:    time.Now().Format(utils.TimeFormat),
			VipExpire:    time.Now().AddDate(0, 0, 7).Format(utils.TimeFormat),
		}
		isRegister = 1
		m, err = this.memberRepo.CreateMember(ctx, tmp)
		if err != nil {
			return nil, err
		}
	} else {
		m = exist
		m.LoginTime = time.Now().Format(utils.TimeFormat)
		_, err = this.memberRepo.UpdateMember(ctx, m)
		if err != nil {
			return nil, err
		}
	}
	token, err := this.memberTokenRepo.GenerateToken(ctx, m)
	if err != nil {
		return nil, err
	}
	return &v1.PhoneCodeLoginResponse{
		Member:     m,
		Token:      token,
		IsRegister: isRegister,
	}, nil
}

func (this *MemberUseCase) RefreshToken(ctx context.Context, req *v1.RefreshTokenRequest) (*v1.RefreshTokenResponse, error) {
	token, err := this.memberTokenRepo.RefreshToken(ctx)
	if err != nil {
		return nil, err
	}
	return &v1.RefreshTokenResponse{
		Token: token,
	}, nil
}

func (this *MemberUseCase) GetMemberInfo(ctx context.Context, req *v1.GetMemberInfoRequest) (*v1.GetMemberInfoResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	deviceInfo, _ := this.memberOnlineStatusRepo.GetMemberOnlineStatusByMemberId(ctx, int32(uid))
	return &v1.GetMemberInfoResponse{
		Member:     member,
		DeviceInfo: deviceInfo,
	}, nil
}

func (this *MemberUseCase) GetMyFriends(ctx context.Context, req *v1.GetMyFriendsRequest) (*v1.GetMyFriendsResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	lists, total, err := this.memberRepo.FindMemberFriends(ctx, int32(uid), req.Page, req.PageSize)
	if err != nil {
		return nil, err
	}
	member := make([]*v1.MyFriendsItem, 0)
	for _, v := range lists {
		v.UserBShowLocation, _ = this.friendsRelationsRepo.GetMyFriendIsShowLocation(ctx, int32(uid), v.UserId)
		onlineStatus, _ := this.memberOnlineStatusRepo.GetMemberOnlineStatusByMemberId(ctx, v.UserId)
		tmp := &v1.MyFriendsItem{
			Member:     v,
			DeviceInfo: onlineStatus,
		}
		member = append(member, tmp)
	}
	return &v1.GetMyFriendsResponse{
		Items: member,
		Total: total,
	}, nil
}

func (this *MemberUseCase) AddFriend(ctx context.Context, req *v1.AddFriendRequest) (*v1.AddFriendResponse, error) {
	bUser, err := this.memberRepo.GetMemberByInviteCode(ctx, req.InviteCode)
	if err != nil {
		return nil, err
	}
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	exist, _ := this.friendsRelationsRepo.GetMemberFriendRelationByAAndBid(ctx, int32(uid), bUser.UserId)
	if exist != nil {
		if exist.Status == -1 {
			this.friendsRelationsRepo.DeleteFriendRelation(ctx, int32(uid), bUser.UserId)
		}
		if exist.Status == 1 {
			return &v1.AddFriendResponse{}, nil
		}
		//return nil, v1.ErrorApiError("已经提交过申请了")
	}
	fr := &v1.FriendRelations{
		UserAId:        int32(uid),
		UserBId:        bUser.UserId,
		ApplyTime:      time.Now().Format(utils.TimeFormat),
		UserAAttribute: req.MyAttribute,
		UserBAttribute: req.AddAttribute,
		Status:         0,
		Remark:         req.Remark,
		ShowLocation:   req.ShowLocation,
	}
	addRelation, err := this.friendsRelationsRepo.CreateFriendRelations(ctx, fr)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	m := &v1.ChatMessage{}
	addMsg := &v1.SocketAddFriend{}
	addMsg.UserAAttribute = req.MyAttribute
	addMsg.ApplyId = addRelation.ApplyId
	addMsg.NickName = member.NickName
	addMsg.AvatarUrl = member.AvatarUrl
	m.AddFriend = addMsg
	m.MessageType = service.MessageTypeFriendAdd
	mStr, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mStr)
	s.To = fmt.Sprintf("%d", bUser.UserId)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	//p, _ := json.Marshal(s)
	this.log.Debug(s)
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		return nil, err
	}
	//添加好友
	//this.memberRepo.AddFriendMessage(ctx, int32(uid), req.UserId)
	//sessionKey := fmt.Sprintf(service.UserSessionKey, bUser.UserId)
	//sessionId := this.redis.Get(ctx, sessionKey).Val()
	//if sessionId != "" {
	//	ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, m)
	//}

	return &v1.AddFriendResponse{}, nil
}

func (this *MemberUseCase) FriendApplyList(ctx context.Context, req *v1.FriendApplyListRequest) (*v1.FriendApplyListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	frList, err := this.friendsRelationsRepo.GetMemberApplyList(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	res := make([]*v1.FriendApplyItem, 0)
	for _, v := range frList {
		tmpMember, err := this.memberRepo.GetMemberById(ctx, v.UserAId)
		if err != nil {
			continue
		}
		tmpFriendMember := this.transMemberToFriendMember(ctx, tmpMember)
		tmpFriendMember.ApplyTime = v.ApplyTime
		tmp := &v1.FriendApplyItem{
			ApplyMember: tmpFriendMember,
			Relations:   v,
		}
		res = append(res, tmp)
	}
	return &v1.FriendApplyListResponse{
		Items: res,
	}, nil
}

func (this *MemberUseCase) CheckFriendApply(ctx context.Context, req *v1.CheckFriendApplyRequest) (*v1.CheckFriendApplyResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	frInfo, err := this.friendsRelationsRepo.GetFriendRelationById(ctx, req.ApplyId)
	if err != nil {
		return nil, err
	}
	if frInfo.UserBId != int32(uid) {
		return nil, v1.ErrorApiError("非法操作")
	}
	if frInfo.Status == 1 {
		return nil, v1.ErrorApiError("已经通过过了")
	}
	frInfo.Status = req.Status
	_, err = this.friendsRelationsRepo.UpdateFriendRelation(ctx, frInfo)
	if err != nil {
		return nil, err
	}
	if req.Status == -1 {
		return &v1.CheckFriendApplyResponse{}, nil
	}
	m := &v1.ChatMessage{}
	m.MessageType = service.MessageTypeFriendApply
	mStr, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mStr)
	s.To = fmt.Sprintf("%d", frInfo.UserAId)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	//p, _ := json.Marshal(s)
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		return nil, err
	}

	s1 := v1.NsqMessage{}
	s1.Content = string(mStr)
	s1.To = fmt.Sprintf("%d", frInfo.UserBId)
	s1.From = "system"
	s1.Timestamp = time.Now().UnixMilli()
	s1.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s1.MsgId = uuid.New().String()
	//p1, _ := json.Marshal(s1)
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s1)
	if err != nil {
		return nil, err
	}
	////添加好友
	////this.memberRepo.AddFriendMessage(ctx, int32(uid), req.UserId)
	//sessionKey := fmt.Sprintf(service.UserSessionKey, frInfo.UserAId)
	//sessionId := this.redis.Get(ctx, sessionKey).Val()
	//if sessionId != "" {
	//	ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, m)
	//}
	//
	//sessionKeyB := fmt.Sprintf(service.UserSessionKey, frInfo.UserBId)
	//sessionIdB := this.redis.Get(ctx, sessionKeyB).Val()
	//if sessionIdB != "" {
	//	ws.SendMessage(websocket.SessionID(sessionIdB), service.MessageTypeChat, m)
	//}
	//添加之后双向绑定
	_, err = this.friendsRelationsRepo.CreateFriendRelations(ctx, &v1.FriendRelations{
		UserAId:        frInfo.UserBId,
		UserBId:        frInfo.UserAId,
		ApplyTime:      time.Now().Format(utils.TimeFormat),
		UserAAttribute: frInfo.UserBAttribute,
		UserBAttribute: frInfo.UserAAttribute,
		Status:         1,
		Remark:         frInfo.Remark,
		ShowLocation:   frInfo.ShowLocation,
	})
	if err != nil {
		return nil, err
	}
	return &v1.CheckFriendApplyResponse{}, nil
}

func (this *MemberUseCase) transMemberToFriendMember(ctx context.Context, member *v1.Member) *v1.MemberFriend {
	tmpFriendMember := &v1.MemberFriend{}
	tmpFriendMember.UserId = member.UserId
	tmpFriendMember.NickName = member.NickName
	tmpFriendMember.AvatarUrl = member.AvatarUrl
	tmpFriendMember.RealName = member.RealName
	tmpFriendMember.Gender = member.Gender
	tmpFriendMember.UserAAttribute = member.UserAttribute
	return tmpFriendMember
}

func (this *MemberUseCase) GetMemberFriendInfoByInviteCode(ctx context.Context, req *v1.GetMemberFriendInfoByInviteCodeRequest) (*v1.GetMemberFriendInfoByInviteCodeResponse, error) {
	member, err := this.memberRepo.GetMemberByInviteCode(ctx, req.InviteCode)
	if err != nil {
		return nil, err
	}
	return &v1.GetMemberFriendInfoByInviteCodeResponse{
		Member: this.transMemberToFriendMember(ctx, member),
	}, nil
}

func (this *MemberUseCase) ModifyMemberInfo(ctx context.Context, req *v1.ModifyMemberInfoRequest) (*v1.ModifyMemberInfoResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	if member.Channel == "" {
		member.Channel = req.InviteCode
	}
	member.NickName = req.NickName
	member.AvatarUrl = req.AvatarUrl
	member.Gender = req.Gender
	member.UserAttribute = req.UserAttribute
	member.IsModify = 1
	m, err := this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		return nil, err
	}
	return &v1.ModifyMemberInfoResponse{
		Member: m,
	}, nil
}

func (this *MemberUseCase) SetFriendRemarkAndShowLocal(ctx context.Context, req *v1.SetFriendRemarkAndShowLocalRequest) (*v1.SetFriendRemarkAndShowLocalResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	if int32(uid) == req.UserId {
		return nil, v1.ErrorApiError("无法对自己设置位置信息")
	}
	fr, err := this.friendsRelationsRepo.GetMemberFriendRelationByAAndBid(ctx, int32(uid), req.UserId)
	if err != nil {
		return nil, err
	}
	fr.Remark = req.Remark
	fr.ShowLocation = req.ShowLocation
	_, err = this.friendsRelationsRepo.UpdateFriendRelation(ctx, fr)
	if err != nil {
		return nil, err
	}
	return &v1.SetFriendRemarkAndShowLocalResponse{}, nil
}

func (this *MemberUseCase) DelFriend(ctx context.Context, req *v1.DelFriendRequest) (*v1.DelFriendResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	err = this.friendsRelationsRepo.DeleteFriendRelation(ctx, int32(uid), req.UserId)
	if err != nil {
		return nil, err
	}
	m := &v1.ChatMessage{}
	m.MessageType = service.MessageTypeFriendDel

	opUser, err := this.memberOnlineStatusRepo.GetMemberOnlineStatusByMemberId(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	m.DelFriend = opUser

	mStr, _ := json.Marshal(m)
	s := v1.NsqMessage{}
	s.Content = string(mStr)
	s.To = fmt.Sprintf("%d", uid)
	s.From = "system"
	s.Timestamp = time.Now().UnixMilli()
	s.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s)
	if err != nil {
		return nil, err
	}

	s1 := v1.NsqMessage{}
	s1.Content = string(mStr)
	s1.To = fmt.Sprintf("%d", req.UserId)
	s1.From = "system"
	s1.Timestamp = time.Now().UnixMilli()
	s1.Topic = this.conf.Nsq.GATEWAY_TOPIC_NOTIFY
	s1.MsgId = uuid.New().String()
	err = this.nsqBroker.Publish(ctx, this.conf.Nsq.GATEWAY_TOPIC_NOTIFY, s1)
	if err != nil {
		return nil, err
	}

	//sessionKey := fmt.Sprintf(service.UserSessionKey, int32(uid))
	//sessionId := this.redis.Get(ctx, sessionKey).Val()
	//if sessionId != "" {
	//	ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, m)
	//}
	//
	//sessionKeyB := fmt.Sprintf(service.UserSessionKey, req.UserId)
	//sessionIdB := this.redis.Get(ctx, sessionKeyB).Val()
	//if sessionIdB != "" {
	//	m.DelFriend = opUser
	//	ws.SendMessage(websocket.SessionID(sessionIdB), service.MessageTypeChat, m)
	//}

	return &v1.DelFriendResponse{}, nil
}

func (this *MemberUseCase) UploadUserLocation(ctx context.Context, req *v1.UserLocationRequest) (*v1.UserLocationResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	s := &v1.UserLocationLog{
		UserId:                   int32(uid),
		StartLocationDescription: req.StartLocationDescription,
		EndLocationDescription:   req.EndLocationDescription,
		State:                    req.State,
		DurationSeconds:          req.DurationSeconds,
		Latitude:                 req.Latitude,
		Longitude:                req.Longitude,
		StartTime:                req.StartTime,
		EndTime:                  req.EndTime,
		DataTime:                 time.Now().Format(utils.TimeFormat),
		UnlockPhoneCount:         req.UnlockPhoneCount,
		ScreenUseTime:            req.ScreenUseTime,
		SystemInfoDescription:    req.SystemInfoDescription,
	}
	this.log.Debug(s)
	_, err = this.userLocationLogRepo.CreateUserLocationLog(ctx, s)
	if err != nil {
		return nil, err
	}
	return &v1.UserLocationResponse{}, nil
}

func (this *MemberUseCase) GetUserLocationLog(ctx context.Context, req *v1.GetUserLocationLogRequest) (*v1.GetUserLocationLogResponse, error) {
	list, err := this.userLocationLogRepo.GetUserLocationLog(ctx, req)
	if err != nil {
		return nil, err
	}
	res := make([]*v1.UserLocationLogItem, len(list))
	for i, v := range list {
		res[i] = &v1.UserLocationLogItem{
			Log: v,
		}
	}
	return &v1.GetUserLocationLogResponse{
		Items: res,
	}, nil
}

func (this *MemberUseCase) UserLogOff(ctx context.Context, req *v1.UserLogOffRequest) (*v1.UserLogOffResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	err = this.memberRepo.DeleteMember(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	return &v1.UserLogOffResponse{}, nil
}

func (this *MemberUseCase) SendBindPhoneCode(ctx context.Context, req *v1.SendBindPhoneCodeRequest) (*v1.SendBindPhoneCodeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	if member.Phone != "" {
		return nil, v1.ErrorApiError("已绑定过手机号")
	}
	code := utils.GetRandomNumber(6)
	err = this.aliCommonRepo.SendBindPhoneCode(ctx, req.Phone, code)
	if err != nil {
		return nil, err
	}
	return &v1.SendBindPhoneCodeResponse{}, nil
}

func (this *MemberUseCase) CheckBindPhoneCode(ctx context.Context, req *v1.CheckBindPhoneCodeRequest) (*v1.CheckBindPhoneCodeResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	err = this.aliCommonRepo.CheckBindPhoneCode(ctx, req.Phone, req.Code)
	if err != nil {
		return nil, err
	}
	member.Phone = req.Phone
	_, err = this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		return nil, err
	}

	return &v1.CheckBindPhoneCodeResponse{}, nil
}

func (this *MemberUseCase) CheckAppleReceiptData(ctx context.Context, req *v1.CheckAppleReceiptDataRequest) (*v1.CheckAppleReceiptDataResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	iapPayData := &v1.IapPay{}
	iapPayData.Receipt = req.ReceiptData
	iapPayData.MemberId = int32(uid)
	_, err = this.iapPayRepo.CreateIapPay(ctx, iapPayData)
	if err != nil {
		return nil, err
	}
	res, err := this.applePayVerifierRepo.VerifyIapPay(ctx, req.ReceiptData, false)
	this.log.Debug(res)
	if err != nil {
		return nil, err
	}
	iapPayData.Status = 1
	_, err = this.iapPayRepo.UpdateIapPay(ctx, iapPayData)
	if err != nil {
		return nil, err
	}
	iapOrderData := &v1.IapOrder{}
	iapOrderData.MemberId = int32(uid)
	iapOrderData.ProductId = res.ProductId
	iapOrderData.TransactionId = res.TransactionId
	iapOrderData.OriginalTransactionId = res.OriginalTransactionId
	iapOrderData.Environment = res.Environment
	iapOrderData.StartTime = res.StartTime
	iapOrderData.ExpiryTime = res.ExpiryTime
	iapOrderData.Status = 1
	iapOrderData.OriginStartTime = res.OriginStartTime
	iapOrderData.OriginEndTime = res.OriginEndTime
	_, err = this.iapOrderRepo.CreateIapOrder(ctx, iapOrderData)
	if err != nil {
		return nil, err
	}
	member.VipExpire = res.ExpiryTime
	_, err = this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		return nil, err
	}
	return &v1.CheckAppleReceiptDataResponse{
		PayItem: res,
		Member:  member,
	}, nil
}

func (this *MemberUseCase) MemberLoginByAppleCode(ctx context.Context, req *v1.MemberLoginRequest) (*v1.MemberLoginResponse, error) {
	if req.Code == "" {
		return nil, v1.ErrorApiError("验证码不能为空")
	}
	appleUser, err := this.verifyAndParseAppleToken(ctx, req.Code)
	if err != nil {
		return nil, err
	}
	var m *v1.Member
	var isRegister int32
	exist, _ := this.memberRepo.GetMemberByAppleCode(ctx, appleUser.AppleID)
	if exist == nil {
		tmp := &v1.Member{
			AppleId:      appleUser.AppleID,
			NickName:     "密友用户",
			InviteCode:   utils.GetRandomString(6),
			RegisterTime: time.Now().Format(utils.TimeFormat),
			LoginTime:    time.Now().Format(utils.TimeFormat),
			Email:        appleUser.Email,
		}
		isRegister = 1
		m, err = this.memberRepo.CreateMember(ctx, tmp)
		if err != nil {
			return nil, err
		}
	} else {
		m = exist
		m.LoginTime = time.Now().Format(utils.TimeFormat)
		m.Email = appleUser.Email
		_, err = this.memberRepo.UpdateMember(ctx, m)
		if err != nil {
			return nil, err
		}
	}
	token, err := this.memberTokenRepo.GenerateToken(ctx, m)
	if err != nil {
		return nil, err
	}
	return &v1.MemberLoginResponse{
		Member:     m,
		Token:      token,
		IsRegister: isRegister,
	}, nil
}

const AppleJWKSEndpoint = "https://appleid.apple.com/auth/keys"

// 替换为你的 Bundle ID
const AppBundleID = "love.tame.ios"

type AppleUser struct {
	AppleID        string
	Email          string
	EmailVerified  bool
	RealUserStatus int
}

func (this *MemberUseCase) verifyAndParseAppleToken(ctx context.Context, tokenStr string) (*AppleUser, error) {
	// 获取 Apple 公钥
	jwks, err := keyfunc.Get(AppleJWKSEndpoint, keyfunc.Options{
		RefreshTimeout: time.Second * 10,
	})
	if err != nil {
		return nil, fmt.Errorf("获取 Apple 公钥失败: %v", err)
	}

	claims := jwt.MapClaims{}
	token, err := jwt.ParseWithClaims(tokenStr, claims, func(token *jwt.Token) (any, error) {
		return jwks.Keyfunc(token)
	})
	if err != nil || !token.Valid {
		return nil, fmt.Errorf("token 无效: %v", err)
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		return nil, errors.New("解析 claims 失败")
	}

	// 验证 iss 和 aud
	if claims["iss"] != "https://appleid.apple.com" {
		return nil, fmt.Errorf("非法签发者")
	}
	if claims["aud"] != AppBundleID {
		return nil, errors.New("aud 不匹配")
	}
	this.log.Debug(claims)
	// 提取字段
	user := &AppleUser{
		AppleID:       claims["sub"].(string),
		Email:         claims["email"].(string),
		EmailVerified: claims["email_verified"] == true,
		//RealUserStatus: claims["real_user_status"].(int),
	}

	return user, nil
}

func (this *MemberUseCase) AppleNotification(r http.Context) error {
	startTime := time.Now()
	log := func(msg string) {
		fmt.Printf("[%s] %s - %s\n", time.Since(startTime).Round(time.Millisecond), r.Request().RemoteAddr, msg)
	}

	// 读取请求体
	body, err := io.ReadAll(r.Request().Body)
	defer r.Request().Body.Close()
	if err != nil {
		r.Response().WriteHeader(http2.StatusBadRequest)
		r.Response().Write([]byte("Error reading request body"))
		log("Error reading request body")
		return nil
	}
	//this.log.Debug("AppleNotification", string(body))
	//this.log.Debug("AppleNotification", body)
	// 尝试解析为JSON（signedPayload格式）
	var notification v1.AppleNotification
	if err := json.Unmarshal(body, &notification); err != nil {
		return err
	}
	res, err := this.applePayVerifierRepo.ParseAndVerifySignedPayload(notification.SignedPayload)
	if err != nil {
		return err
	}
	if !res.IsValid {
		return errors.New("验证失败")
	}
	ctx := context.Background()
	this.log.Debug("AppleNotification", res)
	result, _ := json.Marshal(res)
	r.Response().Write(result)
	id := res.TransactionInfo.OriginalTransactionId
	iapOrder, err := this.iapOrderRepo.GetIapOrderByOriginalTransactionID(ctx, id)
	if err != nil {
		return err
	}
	member, err := this.memberRepo.GetMemberById(ctx, iapOrder.MemberId)
	if err != nil {
		return err
	}

	// 根据通知类型处理
	switch res.Payload.NotificationType {
	case "DID_CHANGE_RENEWAL_STATUS": // 自动续订状态变更
		autoRenewStatus := res.RenewalInfo.AutoRenewStatus == 1
		if autoRenewStatus {
			member.AutoRenewStatus = 1
		} else {
			member.AutoRenewStatus = -1
		}
		this.memberRepo.UpdateMember(ctx, member)
		return nil

	case "DID_CHANGE_RENEWAL_PREF": // 续订计划变更
		return nil

	case "DID_FAIL_TO_RENEW": // 续订失败
		return nil

	case "DID_RECOVER": // 恢复订阅
		return nil

	case "RENEWAL": // 成功续订
		member.VipExpire = time.Unix(int64(res.TransactionInfo.ExpiresDate)/1000, 0).Format(utils.TimeFormat)
		this.memberRepo.UpdateMember(ctx, member)
		return nil

	case "CANCEL": // 取消订阅
		member.AutoRenewStatus = -1
		this.memberRepo.UpdateMember(ctx, member)
		return nil
	// 添加其他通知类型的处理...
	default:
		this.log.Debug("Unhandled notification type: %s", res.Payload.NotificationType)
	}
	return nil
}

func (this *MemberUseCase) GetMemberPunishTotalData(ctx context.Context, req *v1.GetMemberPunishTotalDataRequest) (*v1.GetMemberPunishTotalDataResponse, error) {
	member, err := this.memberRepo.GetMemberById(ctx, req.UserId)
	if err != nil {
		return nil, err
	}
	punishTotalData, err := this.punishTypeRepo.GetMemberPunishSumData(ctx, member.UserId)
	if err != nil {
		return nil, err
	}
	return &v1.GetMemberPunishTotalDataResponse{
		Items: punishTotalData,
	}, nil
}

func (this *MemberUseCase) SetMemberGeTuiCid(ctx context.Context, req *v1.SetMemberGeTuiCidRequest) (*v1.SetMemberGeTuiCidResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	member, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	member.GetuiCid = req.Cid
	_, err = this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		return nil, err
	}
	return &v1.SetMemberGeTuiCidResponse{}, nil
}

func (this *MemberUseCase) CheckMemberToken(ctx context.Context, req *v1.CheckMemberTokenRequest) (*v1.CheckMemberTokenResponse, error) {
	_, uid, err := this.memberTokenRepo.ParesTokenData(req.Token)
	if err != nil {
		return nil, err
	}
	return &v1.CheckMemberTokenResponse{
		UserId: int32(uid),
	}, nil
}

// ========== 订单支付相关 ==============

var wechatClient *wechat.ClientV3

func (this *MemberUseCase) WechatPayReceiptNotify(r http.Context) (*wechat.V3NotifyRsp, error) {
	ctx := r.Request().Context()
	notifyReq, err := wechat.V3ParseNotify(r.Request())
	if err != nil {
		this.log.Error("WechatPayReceiptNotify ParseNotifyToBodyMap failed:", err)
		return nil, err
	}
	client, err := this.getWechatClient()
	if err != nil {
		this.log.Error("WechatPayReceiptNotify getWechatClient failed:", err)
		return nil, err
	}
	// 验证异步通知的签名
	if err = notifyReq.VerifySignByPKMap(client.WxPublicKeyMap()); err != nil {
		this.log.Error("WechatPayReceiptNotify VerifySignByPK failed:", err, " public key:", client.WxPublicKeyMap(), "sign_body", notifyReq.SignInfo.SignBody)
		return nil, err
	}
	notifyResult, err := notifyReq.DecryptPayCipherText(def.WechatApiKey)
	if err != nil {
		this.log.Error("WechatPayReceiptNotify DecryptPayCipherText failed:", err)
		return nil, err
	}

	if notifyResult.TradeState != wechat.TradeStateSuccess {
		this.log.Error("WechatPayReceiptNotify TradeState not succ:", notifyResult)
		return nil, err
	}
	//处理支付成功逻辑
	//查找订单（这里需要实现微信支付订单的Repository）
	orderInfo, err := this.payOrderInfoRepo.GetOrderInfoByOrderId(ctx, notifyResult.OutTradeNo)
	if err != nil {
		this.log.Error("WechatPayReceiptNotify GetWechatPayOrderByOutTradeNo failed:", err)
		return nil, err
	}

	//更新订单状态
	orderInfo.TransactionID = notifyResult.TransactionId
	orderInfo.Status = 1 // 支付成功
	orderInfo.FinishTime = time.Now().UnixMilli()
	orderInfo.UpdatedTime = time.Now().UnixMilli()

	err = this.payOrderInfoRepo.UpdatePayOrder(ctx, orderInfo)
	if err != nil {
		this.log.Error("WechatPayReceiptNotify UpdateWechatPayOrder failed:", err)
		return nil, err
	}

	//更新用户VIP状态
	member, err := this.memberRepo.GetMemberById(ctx, orderInfo.MemberID)
	if err != nil {
		this.log.Error("WechatPayReceiptNotify GetMemberById failed:", err)
		return nil, err
	}

	//根据产品ID设置VIP到期时间
	vipExpire := this.calculateVipExpireTime(orderInfo.ProductID, member.VipExpire)
	member.VipExpire = vipExpire.Format(utils.TimeFormat)

	_, err = this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		this.log.Error("WechatPayReceiptNotify UpdateMember failed:", err)
		return nil, err
	}
	rsp := &wechat.V3NotifyRsp{Code: gopay.SUCCESS, Message: "成功"}
	return rsp, nil
}

func (this *MemberUseCase) AliPayReceiptNotify(r http.Context) error {
	ctx := r.Request().Context()
	notifyReq, err := alipay2.ParseNotifyToBodyMap(r.Request())
	if err != nil {
		this.log.Error("AliPayReceiptNotify ParseNotifyToBodyMap failed:", err)
		return err
	}

	// 支付宝异步通知验签（公钥证书模式）
	succ, err := alipay2.VerifySignWithCert([]byte(def.AliPayPublicCert), notifyReq)
	if err != nil {
		this.log.Error("AliPayReceiptNotify VerifySignWithCert failed:", err)
		return err
	}
	if !succ {
		this.log.Error("AliPayReceiptNotify VerifySignWithCert failed false")
		return errors.New("AliPayReceiptNotify VerifySignWithCert failed")
	}

	// 解析通知数据
	var notifyData AliPayNotifyData
	err = notifyReq.Unmarshal(&notifyData)
	if err != nil {
		this.log.Error("AliPayReceiptNotify Unmarshal failed:", err)
		return err
	}

	// 检查交易状态
	if notifyData.TradeStatus != "TRADE_SUCCESS" {
		this.log.Info("AliPayReceiptNotify trade status not success:", notifyData.TradeStatus)
		r.Response().WriteHeader(http2.StatusOK)
		r.Response().Write([]byte("success"))
		return nil
	}

	// 处理支付成功逻辑
	// 查找订单
	order, err := this.payOrderInfoRepo.GetOrderInfoByOrderId(ctx, notifyData.OutTradeNo)
	if err != nil {
		this.log.Error("AliPayReceiptNotify GetOrderInfoByOrderId failed:", err)
		return err
	}
	// 更新订单状态
	order.TransactionID = notifyData.TradeNo
	order.Status = 1 // 支付成功
	order.UpdatedTime = time.Now().UnixMilli()
	order.FinishTime = time.Now().UnixMilli()

	err = this.payOrderInfoRepo.UpdatePayOrder(ctx, order)
	if err != nil {
		this.log.Error("AliPayReceiptNotify UpdateAliPayOrder failed:", err)
		return err
	}

	// 更新用户VIP状态
	member, err := this.memberRepo.GetMemberById(ctx, order.MemberID)
	if err != nil {
		this.log.Error("AliPayReceiptNotify GetMemberById failed:", err)
		return err
	}

	// 根据产品ID设置VIP到期时间
	vipExpire := this.calculateVipExpireTime(order.ProductID, member.VipExpire)
	member.VipExpire = vipExpire.Format(utils.TimeFormat)

	_, err = this.memberRepo.UpdateMember(ctx, member)
	if err != nil {
		this.log.Error("AliPayReceiptNotify UpdateMember failed:", err)
		return err
	}
	return nil
}

func (this *MemberUseCase) CreateOrder(r http.Context) (*CreateOrderResponse, error) {
	// 获取用户ID
	jwtToken := r.Request().Header.Get("Authorization")
	jwtToken = strings.TrimPrefix(jwtToken, "bearer ")
	ctx := r.Request().Context()
	_, uid, err := this.memberTokenRepo.ParesTokenData(jwtToken)
	if err != nil {
		return nil, err
	}

	if uid <= 0 {
		return nil, errors.New("uid empty")
	}

	// 读取请求体
	body, err := io.ReadAll(r.Request().Body)
	defer r.Request().Body.Close()
	if err != nil {
		this.log.Error("CreateOrder param failed:", err)
		return nil, v1.ErrorApiError("参数错误")
	}

	createParam := CreateOrderRequest{}
	err = json.Unmarshal(body, &createParam)
	if err != nil {
		this.log.Error("CreateOrder param failed:", body)
		return nil, v1.ErrorApiError("参数错误")
	}

	if createParam.ProductId == "" || createParam.PayType == "" {
		this.log.Error("CreateOrder param failed: pay_type:", createParam.PayType, " product_id:", createParam.ProductId)
		return nil, v1.ErrorApiError("参数不完整")
	}
	productItem, ok := def.GetProductItem(createParam.ProductId)
	if !ok {
		return nil, v1.ErrorApiError("ProductId不存在")
	}
	// 生成订单号
	outTradeNo := fmt.Sprintf("%d_%s", uid, time.Now().Format("20060102150405"))

	// 根据支付类型创建订单
	switch createParam.PayType {
	case "alipay":
		return this.createAliPayOrder(ctx, int32(uid), outTradeNo, createParam.ProductId, productItem.ProductAmount)
	case "wechat":
		return this.createWechatPayOrder(ctx, int32(uid), outTradeNo, createParam.ProductId, productItem.ProductAmount)
	default:
		return nil, v1.ErrorApiError("不支持的支付类型")
	}
}

// 创建支付宝订单
func (this *MemberUseCase) createAliPayOrder(ctx context.Context, memberId int32, outTradeNo, productId string, productAmount float64) (*CreateOrderResponse, error) {
	// 创建支付宝订单记录
	order := &model.AppOrderInfo{
		MemberID:   memberId,
		OrderID:    outTradeNo,
		ProductID:  productId,
		PayType:    def.PayTypeAlipay,
		Amount:     productAmount,
		CreateTime: time.Now().UnixMilli(),
		Status:     0, // 待支付
	}
	_, err := this.payOrderInfoRepo.CreateOrder(ctx, order)
	if err != nil {
		return nil, err
	}

	// 使用go-pay SDK创建支付宝订单
	payStr, err := this.createAliPayTrade(outTradeNo, productAmount, productId)
	if err != nil {
		return nil, err
	}

	return &CreateOrderResponse{
		OutTradeNo: outTradeNo,
		PayStr:     payStr,
	}, nil
}

// 创建微信支付订单
func (this *MemberUseCase) createWechatPayOrder(ctx context.Context, memberId int32, outTradeNo, productId string, productAmount float64) (*CreateOrderResponse, error) {
	// 创建支付宝订单记录
	order := &model.AppOrderInfo{
		MemberID:   memberId,
		OrderID:    outTradeNo,
		ProductID:  productId,
		PayType:    def.PayTypeWechat,
		Amount:     productAmount,
		CreateTime: time.Now().UnixMilli(),
		Status:     0, // 待支付
	}
	_, err := this.payOrderInfoRepo.CreateOrder(ctx, order)
	if err != nil {
		return nil, err
	}
	// 使用go-pay SDK创建支付宝订单
	payAppParam, err := this.createWechatTrade(outTradeNo, productAmount, productId)
	if err != nil {
		return nil, err
	}

	return &CreateOrderResponse{
		OutTradeNo:  outTradeNo,
		PayAppParam: payAppParam,
	}, nil
}

// 生成支付宝支付字符串
func (this *MemberUseCase) createAliPayTrade(outTradeNo string, amount float64, productId string) (string, error) {
	// 初始化支付宝客户端
	client, err := alipay.NewClientV3(def.AliaAppId, def.AliPrivateKey, true)
	if err != nil {
		return "", fmt.Errorf("初始化支付宝客户端失败: %v", err)
	}
	client.DebugSwitch = gopay.DebugOn
	err = client.SetCert([]byte(def.AliAppPublicCert), []byte(def.AliPayRootCert), []byte(def.AliPayPublicCert))
	if err != nil {
		return "", fmt.Errorf("初始化支付宝证书设置不正确: %v", err)
	}
	// 构建支付请求参数
	bm := make(gopay.BodyMap)
	bm.Set("tips", productId)
	bm.Set("out_trade_no", outTradeNo)
	bm.Set("total_amount", fmt.Sprintf("%.2f", amount))
	bm.Set("subject", "VIP会员服务")
	bm.Set("timeout_express", "30m")
	bm.Set("notify_url", def.AliPayNotifyUrl)
	// 调用支付宝API创建订单
	aliRsp, err := client.TradeAppPay(context.Background(), bm)
	if err != nil {
		return "", fmt.Errorf("创建支付宝订单失败: %v", err)
	}
	// 返回支付表单字符串
	return aliRsp, nil
}

func (this *MemberUseCase) getWechatClient() (*wechat.ClientV3, error) {
	if wechatClient != nil {
		return wechatClient, nil
	}
	// NewClientV3 初始化微信客户端 v3
	// mchid：商户ID 或者服务商模式的 sp_mchid
	// serialNo：商户证书的证书序列号
	// apiV3Key：apiV3Key，商户平台获取
	// privateKey：私钥 apiclient_key.pem 读取后的内容
	client, err := wechat.NewClientV3(def.WechatMerchantId, def.WechatSerialNo, def.WechatApiKey, def.WechatPrivateKey)
	if err != nil {
		this.log.Error("getWechatClient NewClientV3 failed:", err)
		return nil, err
	}
	// 打开Debug开关，输出日志，默认是关闭的
	client.DebugSwitch = gopay.DebugOn

	err = client.AutoVerifySignByPublicKey([]byte(def.WechatPubKeyContent), def.WechatPubKeyId)
	if err != nil {
		this.log.Error("getWechatClient NewClientV3 failed:", err)
		return nil, err
	}
	wechatClient = client
	return client, nil
}

func (this *MemberUseCase) createWechatTrade(outTradeNo string, amount float64, productId string) (*wechat.AppPayParams, error) {
	client, err := this.getWechatClient()
	if err != nil {
		this.log.Error("createWechatTrade getWechatClient failed:", err)
		return nil, err
	}
	expire := time.Now().Add(30 * time.Minute).Format(time.RFC3339)
	// 初始化 BodyMap
	bm := make(gopay.BodyMap)
	bm.Set("appid", def.WechatAppId).
		Set("mchid", def.WechatMerchantId).
		Set("description", productId).
		Set("out_trade_no", outTradeNo).
		SetBodyMap("amount", func(bm gopay.BodyMap) {
			bm.Set("total", amount*100).Set("currency", "CNY")
		}).
		Set("time_expire", expire).
		Set("notify_url", def.WechatPayNotifyUrl)
	wxRsp, err := client.V3TransactionApp(context.Background(), bm)
	if err != nil {
		this.log.Error("createWechatTrade V3TransactionApp failed:", err)
		return nil, err
	}
	if wxRsp.Code != wechat.Success {
		this.log.Error("createWechatTrade V3TransactionApp failed:", err)
		return nil, errors.New(wxRsp.Error)
	}
	payAppParam, err := client.PaySignOfApp(def.WechatAppId, wxRsp.Response.PrepayId)
	if err != nil {
		this.log.Error("createWechatTrade PaySignOfApp failed:", err)
		return nil, err
	}
	return payAppParam, nil
}

// 计算VIP到期时间
func (this *MemberUseCase) calculateVipExpireTime(productId string, oriVipExpire string) time.Time {
	now := time.Now()
	vipExpireTime, _ := utils.StrToDateTime(oriVipExpire)
	switch productId {
	case "vip_month":
		if vipExpireTime.Unix() <= now.Unix() {
			return now.AddDate(0, 0, 30)
		}
		return vipExpireTime.AddDate(0, 0, 30)
	case "vip_quarter":
		if vipExpireTime.Unix() <= now.Unix() {
			return now.AddDate(0, 0, 90)
		}
		return vipExpireTime.AddDate(0, 0, 90)
	case "vip_year":
		if vipExpireTime.Unix() <= now.Unix() {
			return now.AddDate(0, 0, 365)
		}
		return vipExpireTime.AddDate(0, 0, 365)
	default:
		return now.AddDate(0, 0, 7) // 默认7天
	}
}
