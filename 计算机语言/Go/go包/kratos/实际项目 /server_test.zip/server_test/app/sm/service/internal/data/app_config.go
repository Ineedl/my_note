package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.AppConfigRepo = (*appConfigRepo)(nil)

type appConfigRepo struct {
	data *Data
	log  *log.Helper
}

func NewAppConfigRepo(data *Data, logger log.Logger) biz.AppConfigRepo {
	return &appConfigRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data.app_config")),
	}
}

func (this *appConfigRepo) CreateAppConfig(ctx context.Context, fr *v1.AppConfig) (*v1.AppConfig, error) {
	in := this.tranProtocToModel(fr)
	err := this.data.genQ.AppAppConfig.WithContext(ctx).Create(in)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(in), nil
}

func (this *appConfigRepo) GetAllAppConfig(ctx context.Context) ([]*v1.AppConfig, error) {
	out := make([]*v1.AppConfig, 0)
	in, err := this.data.genQ.AppAppConfig.WithContext(ctx).Find()
	if err != nil {
		return nil, err
	}
	for _, v := range in {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *appConfigRepo) tranProtocToModel(in *v1.AppConfig) *model.AppAppConfig {
	out := &model.AppAppConfig{}
	out.ID = in.Id
	out.Key = in.Key
	out.Value = in.Value
	return out
}

func (this *appConfigRepo) tranModelToProtoc(in *model.AppAppConfig) *v1.AppConfig {
	out := &v1.AppConfig{}
	out.Id = in.ID
	out.Key = in.Key
	out.Value = in.Value
	return out
}
