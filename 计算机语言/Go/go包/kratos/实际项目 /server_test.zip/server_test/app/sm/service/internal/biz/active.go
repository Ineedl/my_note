package biz

import (
	"context"
	"errors"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-redis/redis/v8"
	"github.com/tx7do/kratos-transport/transport/websocket"
	v1 "miyou/gen/api/sm/service/v1"
	"miyou/pkg/service"
)

type ActiveUseCase struct {
	log                    *log.Helper
	activeRepo             ActiveRepo
	memberTokenRepo        MemberTokenRepo
	memberOnlineStatusRepo MemberOnlineStatusRepo
	activeJoinMemberRepo   ActiveJoinMemberRepo
	activeRemoveMemberRepo ActiveRemoveMemberRepo
	redis                  *redis.Client
	memberRepo             MemberRepo
}

type ActiveRepo interface {
	CreateActive(ctx context.Context, fr *v1.Active) (*v1.Active, error)
	GetActiveList(ctx context.Context, req *v1.GetActiveListRequest, uid int32) ([]*v1.Active, error)
	UpdateActive(ctx context.Context, fr *v1.Active) (*v1.Active, error)
	GetActive(ctx context.Context, activeId int32) (*v1.Active, error)
	GetMemberActiveList(ctx context.Context, uid int32) ([]*v1.Active, error)
}

type ActiveJoinMemberRepo interface {
	GetActiveJoinMemberIds(ctx context.Context, activeId int32) ([]int32, error)
	UserJoinActive(ctx context.Context, activeId int32, uid int32) error
}

type ActiveRemoveMemberRepo interface {
	GetActiveRemoveMemberIds(ctx context.Context, activeId int32) ([]int32, error)
	UserRemoveActive(ctx context.Context, activeId int32, uid int32) error
}

func NewActiveUseCase(memberRepo MemberRepo,
	redis *redis.Client,
	activeRemoveMemberRepo ActiveRemoveMemberRepo,
	activeJoinMemberRepo ActiveJoinMemberRepo,
	memberOnlineStatusRepo MemberOnlineStatusRepo,
	activeRepo ActiveRepo,
	memberTokenRepo MemberTokenRepo,
	logger log.Logger) *ActiveUseCase {
	return &ActiveUseCase{
		activeRepo:             activeRepo,
		memberTokenRepo:        memberTokenRepo,
		memberOnlineStatusRepo: memberOnlineStatusRepo,
		activeJoinMemberRepo:   activeJoinMemberRepo,
		activeRemoveMemberRepo: activeRemoveMemberRepo,
		redis:                  redis,
		memberRepo:             memberRepo,
		log:                    log.NewHelper(log.With(logger, "module", "sm/biz")),
	}
}

func (this *ActiveUseCase) CreateActive(ctx context.Context, req *v1.CreateActiveRequest) (*v1.CreateActiveResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	memberInfo, err := this.memberRepo.GetMemberById(ctx, int32(uid))
	if err != nil {
		return nil, err
	}
	active := &v1.Active{}
	active.MemberId = int32(uid)
	active.ActiveStartTime = req.ActiveStartTime
	active.ActiveEndTime = req.ActiveEndTime
	active.MaxDistance = req.MaxDistance
	active.MaxPeople = req.MaxPeople
	active.WantKnowGender = req.WantKnowGender
	active.MyGender = req.MyGender
	active.Province = req.Province
	active.Region = req.Region
	active.City = req.City
	active.Latitude = req.Latitude
	active.Longitude = req.Longitude
	active.ActiveStatus = req.ActiveStatus
	active.NickName = memberInfo.NickName
	active.Avatar = memberInfo.AvatarUrl
	a, err := this.activeRepo.CreateActive(ctx, active)
	if err != nil {
		return nil, err
	}
	return &v1.CreateActiveResponse{
		Active: a,
	}, nil
}

func (this *ActiveUseCase) GetActiveList(ctx context.Context, req *v1.GetActiveListRequest) (*v1.GetActiveListResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	list, err := this.activeRepo.GetActiveList(ctx, req, int32(uid))
	if err != nil {
		return nil, err
	}
	r := make([]*v1.ActiveListItem, len(list))
	for k, v := range list {
		tmp := &v1.ActiveListItem{}
		tmp.Active = v
		joinIds, _ := this.activeJoinMemberRepo.GetActiveJoinMemberIds(ctx, v.ActiveId)
		if len(joinIds) > 0 {
			tmp.JoinMembers, _ = this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, joinIds)
		}
		removeIds, _ := this.activeRemoveMemberRepo.GetActiveRemoveMemberIds(ctx, v.ActiveId)
		if len(removeIds) > 0 {
			tmp.RemoveMembers, _ = this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, removeIds)
		}
		r[k] = tmp
	}
	return &v1.GetActiveListResponse{
		Items: r,
	}, nil
}

func (this *ActiveUseCase) JoinActive(ctx context.Context, req *v1.JoinActiveRequest, ws *websocket.Server) (*v1.JoinActiveResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	err = this.activeJoinMemberRepo.UserJoinActive(ctx, req.ActiveId, int32(uid))
	if err != nil {
		return nil, err
	}

	mids, err := this.activeJoinMemberRepo.GetActiveJoinMemberIds(ctx, req.ActiveId)
	if err != nil {
		return nil, err
	}
	mlist, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, mids)
	if err != nil {
		return nil, err
	}
	active, err := this.activeRepo.GetActive(ctx, req.ActiveId)
	if err != nil {
		return nil, err
	}
	sessionKey := fmt.Sprintf(service.UserSessionKey, active.MemberId)
	sessionId := this.redis.Get(ctx, sessionKey).Val()
	ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, &v1.ChatMessage{
		MessageType: service.MessageActiveJoin,
		Friend_List: mlist,
		ActiveId:    active.ActiveId,
	})

	//sessionKey = fmt.Sprintf(service.UserSessionKey, uid)
	//sessionId = this.redis.Get(ctx, sessionKey).Val()
	//ownList, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, []int32{int32(uid)})
	//if err != nil {
	//	return nil, err
	//}
	//ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, &v1.ChatMessage{
	//	MessageType: service.MessageActiveJoin,
	//	Friend_List: ownList,
	//	ActiveId:    active.ActiveId,
	//})

	return nil, nil
}

func (this *ActiveUseCase) ActiveRemovePeople(ctx context.Context, req *v1.ActiveRemovePeopleRequest, ws *websocket.Server) (*v1.ActiveRemovePeopleResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	err = this.activeRemoveMemberRepo.UserRemoveActive(ctx, req.ActiveId, req.UserId)
	if err != nil {
		return nil, err
	}

	sessionKey := fmt.Sprintf(service.UserSessionKey, req.UserId)
	sessionId := this.redis.Get(ctx, sessionKey).Val()
	ownList, err := this.memberOnlineStatusRepo.GetUserOnlineStatusListByIds(ctx, []int32{int32(uid)})
	if err != nil {
		return nil, err
	}
	ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, &v1.ChatMessage{
		MessageType: service.MessageActiveRemove,
		Friend_List: ownList,
	})
	return nil, nil
}

func (this *ActiveUseCase) ActiveStop(ctx context.Context, req *v1.ActiveStopRequest, ws *websocket.Server) (*v1.ActiveStopResponse, error) {
	_, uid, err := this.memberTokenRepo.ParseFromContext(ctx)
	if err != nil {
		return nil, err
	}
	active, _ := this.activeRepo.GetActive(ctx, req.ActiveId)
	if active.MemberId != int32(uid) {
		return nil, errors.New("参数错误")
	}
	active.ActiveStatus = 2
	_, err = this.activeRepo.UpdateActive(ctx, active)
	if err != nil {
		return nil, err
	}
	ids, _ := this.activeJoinMemberRepo.GetActiveJoinMemberIds(ctx, req.ActiveId)
	for _, v := range ids {
		sessionKey := fmt.Sprintf(service.UserSessionKey, v)
		sessionId := this.redis.Get(ctx, sessionKey).Val()
		ws.SendMessage(websocket.SessionID(sessionId), service.MessageTypeChat, &v1.ChatMessage{
			MessageType: service.MessageActiveStop,
			ActiveId:    active.ActiveId,
		})
	}
	return nil, nil
}
