package indi.cjh.dao;

import indi.cjh.mapper.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StudentDao {
    public List<Student> selectStudents(@Param("MyName") String name,
                                        @Param("MyAge") Integer age);
    public int insertStudents(Student stu);

    public List<Student> selectStudents2(String name,Integer age,Integer id);

    public List<Student> selectStudents3(Map<String,Object> map);

    public List<Student> selectStudents4();
}
