package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
	"time"
)

var _ biz.ActiveRepo = (*activeRepo)(nil)

type activeRepo struct {
	data *Data
	log  *log.Helper
}

func NewActiveRepo(data *Data, logger log.Logger) biz.ActiveRepo {
	return &activeRepo{
		data: data,
		log:  log.NewHelper(log.With(logger, "module", "data/active")),
	}
}
func (this *activeRepo) CreateActive(ctx context.Context, fr *v1.Active) (*v1.Active, error) {
	frModel := this.tranProtocToModel(fr)
	err := this.data.genQ.AppActive.WithContext(ctx).Create(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *activeRepo) GetMemberActiveList(ctx context.Context, uid int32) ([]*v1.Active, error) {
	q := this.data.genQ.AppActive
	list, err := q.WithContext(ctx).Where(q.MemberID.Eq(uid)).Find()
	if err != nil {
		return nil, err
	}
	out := make([]*v1.Active, 0)
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *activeRepo) GetActive(ctx context.Context, activeId int32) (*v1.Active, error) {
	q := this.data.genQ.AppActive
	model, err := q.WithContext(ctx).Where(q.ID.Eq(activeId)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(model), nil
}

func (this *activeRepo) UpdateActive(ctx context.Context, fr *v1.Active) (*v1.Active, error) {
	q := this.data.genQ.AppActive
	frModel := this.tranProtocToModel(fr)
	_, err := q.WithContext(ctx).Where(q.ID.Eq(frModel.ID)).Updates(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *activeRepo) GetActiveList(ctx context.Context, req *v1.GetActiveListRequest, uid int32) ([]*v1.Active, error) {
	q := this.data.genQ.AppActive
	nowTime := time.Now().Format("2006-01-02 15:04:05")
	query := q.WithContext(ctx).Debug().Where(q.ActivityStatus.NotIn(0, 2)).Where(q.EndTime.Gt(nowTime))
	if req.QueryType == 1 {
		query = query.Where(q.MemberID.Eq(uid))
	} else {
		if req.MyGender != "" || req.WantKnowGender != "" {
			query = query.Where(q.Where(q.Where(q.WantKnowGender.Eq(req.MyGender)).Or(q.WantKnowGender.Eq(req.WantKnowGender))))
		}

		if req.Province != "" {
			query = query.Where(q.Province.Eq(req.Province))
		}
	}
	//query = query.Where(q.ActivityStatus.Eq(1))

	list, err := query.Debug().Find()
	if err != nil {
		return nil, err
	}
	out := make([]*v1.Active, len(list))
	for k, v := range list {
		out[k] = this.tranModelToProtoc(v)
	}
	return out, nil
}

func (this *activeRepo) tranProtocToModel(in *v1.Active) *model.AppActive {
	out := &model.AppActive{}
	out.ID = in.ActiveId
	out.MemberID = in.MemberId
	out.MyGender = in.MyGender
	out.WantKnowGender = in.WantKnowGender
	out.MaxPeople = in.MaxPeople
	out.MaxDistance = in.MaxDistance
	out.StartTime = in.ActiveStartTime
	out.EndTime = in.ActiveEndTime
	out.Province = in.Province
	out.City = in.City
	out.Region = in.Region
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.ActivityStatus = in.ActiveStatus
	out.NickName = in.NickName
	out.Avatar = in.Avatar
	return out
}

func (this *activeRepo) tranModelToProtoc(in *model.AppActive) *v1.Active {
	out := &v1.Active{}
	out.ActiveId = in.ID
	out.MemberId = in.MemberID
	out.MyGender = in.MyGender
	out.WantKnowGender = in.WantKnowGender
	out.MaxPeople = in.MaxPeople
	out.MaxDistance = in.MaxDistance
	out.ActiveStartTime = in.StartTime
	out.ActiveEndTime = in.EndTime
	out.Province = in.Province
	out.City = in.City
	out.Region = in.Region
	out.Latitude = in.Latitude
	out.Longitude = in.Longitude
	out.ActiveStatus = in.ActivityStatus
	out.NickName = in.NickName
	out.Avatar = in.Avatar
	return out
}
