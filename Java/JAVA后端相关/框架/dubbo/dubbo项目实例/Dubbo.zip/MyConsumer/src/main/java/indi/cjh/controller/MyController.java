package indi.cjh.controller;

import indi.cjh.model.User;

import indi.cjh.outInterface.MyInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

    @Autowired
    private MyInterface myInterface;

    @RequestMapping(value="/user")
    public String userDetail(Model model , Integer id){
        User user = myInterface.getUserById(id);
        model.addAttribute("user",user);
        return "user";
    }
}
