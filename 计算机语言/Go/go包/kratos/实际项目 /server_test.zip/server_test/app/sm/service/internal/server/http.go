package server

import (
	"context"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/auth/jwt"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/middleware/selector"
	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/transport/http"
	jwtV5 "github.com/golang-jwt/jwt/v5"
	"github.com/gorilla/handlers"
	"github.com/tx7do/kratos-transport/broker"
	"github.com/tx7do/kratos-transport/transport/nsq"
	"miyou/app/sm/service/internal/msgnsq"

	"miyou/app/sm/service/internal/conf"

	"miyou/app/sm/service/internal/service"
	v1 "miyou/gen/api/sm/service/v1"
)

func NewWhiteListMatcher() selector.MatchFunc {

	whiteList := make(map[string]struct{})
	whiteList["/sm.service.v1.MemberService/MemberLogin"] = struct{}{}
	whiteList["/sm.service.v1.MemberService/PhoneCodeLogin"] = struct{}{}
	whiteList["/sm.service.v1.MemberService/CheckMemberToken"] = struct{}{}
	whiteList["/sm.service.v1.CommonService/SendRegisterLoginCode"] = struct{}{}
	return func(ctx context.Context, operation string) bool {
		if _, ok := whiteList[operation]; ok {
			return false
		}
		return true
	}
}

// NewMiddleware 创建中间件
func NewMiddleware(ac *conf.Bootstrap, logger log.Logger) http.ServerOption {
	return http.Middleware(
		recovery.Recovery(),
		tracing.Server(),
		logging.Server(logger),
		selector.Server(
			jwt.Server(
				func(token *jwtV5.Token) (interface{}, error) {
					return []byte(ac.Auth.ApiKey), nil
				},
				jwt.WithSigningMethod(jwtV5.SigningMethodHS256),
				jwt.WithClaims(func() jwtV5.Claims {
					return &jwtV5.MapClaims{}
				}),
			),
		).Match(NewWhiteListMatcher()).Build(),
	)
}

// NewHTTPServer new an HTTP server.
func NewHTTPServer(
	logger log.Logger,
	c *conf.Bootstrap,
	m *service.MemberService,
	common *service.CommonService,
	task *service.TaskService,
	active *service.ActiveService,
	identityverify *service.IdentityVerifyService,
) *http.Server {
	var opts = []http.ServerOption{
		NewMiddleware(c, logger),
		http.Filter(handlers.CORS(
			handlers.AllowedHeaders([]string{"X-Requested-With", "Content-Type", "Authorization"}),
			handlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS"}),
			handlers.AllowedOrigins([]string{"*"}),
		)),
	}
	if c.Server.Http.Network != "" {
		opts = append(opts, http.Network(c.Server.Http.Network))
	}
	if c.Server.Http.Addr != "" {
		opts = append(opts, http.Address(c.Server.Http.Addr))
	}
	if c.Server.Http.Timeout != nil {
		opts = append(opts, http.Timeout(c.Server.Http.Timeout.AsDuration()))
	}

	srv := http.NewServer(opts...)
	v1.RegisterMemberServiceHTTPServer(srv, m)
	v1.RegisterCommonServiceHTTPServer(srv, common)
	v1.RegisterTaskServiceHTTPServer(srv, task)
	v1.RegisterActiveServiceHTTPServer(srv, active)
	v1.RegisterIdentityVerifyHTTPServer(srv, identityverify)
	// 自定义路由
	route := srv.Route("/api")
	route.POST("/purchase", m.AppleNotification)
	route.POST("/create_order", m.CreateOrder)
	route.POST("/wechat_pay_receipt_notify", m.WechatPayReceiptNotify)
	route.POST("/alipay_receipt_notify", m.AliPayReceiptNotify)
	return srv
}

//// NewHTTPServer new an HTTP server.
//func NewWsServer(
//	wsHandler *ws.WsHandler,
//	active *service.ActiveService,
//) *websocket.Server {
//	wsServer := websocket.NewServer(
//		websocket.WithAddress(":8880"),
//		websocket.WithPath("/ws"),
//		websocket.WithConnectHandle(wsHandler.HandleConnect),
//		websocket.WithCodec("json"),
//	)
//	wsHandler.SetWebsocketServer(wsServer)
//	active.SetWebsocketServer(wsServer)
//	wsServer.RegisterMessageHandler(service2.MessageTypeChat,
//		func(sessionId websocket.SessionID, payload websocket.MessagePayload) error {
//			switch t := payload.(type) {
//			case *v1.ChatMessage:
//				return wsHandler.HandleChatMessage(sessionId, t)
//			default:
//				return errors.New("invalid payload type")
//			}
//		},
//		func() websocket.Any { return &v1.ChatMessage{} },
//	)
//	return wsServer
//}

func NewNConsumer(
	conf *conf.Bootstrap,
	msgHandler *msgnsq.MsgHandler,
) *nsq.Server {
	fmt.Println(conf.Nsq)
	brk := nsq.NewServer(
		nsq.WithLookupdAddress([]string{conf.Nsq.NSQLOOKUPD_ADDR}),
		nsq.WithAddress([]string{conf.Nsq.NSQD_ADDR}),
		nsq.WithCodec("json"),
	)
	brk.Connect()

	msgHandler.SetWebsocketServer(brk)
	nsq.RegisterSubscriber(brk, conf.Nsq.GATEWAY_TOPIC_REPORT, msgHandler.HandleChatMessage, broker.WithQueueName("report"))
	return brk
}
