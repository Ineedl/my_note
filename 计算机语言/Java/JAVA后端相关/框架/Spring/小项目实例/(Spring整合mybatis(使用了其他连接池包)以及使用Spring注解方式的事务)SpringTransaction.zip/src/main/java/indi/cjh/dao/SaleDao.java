package indi.cjh.dao;

import indi.cjh.beanclass.Sale;

public interface SaleDao {
    int insertSale(Sale sale);
}
