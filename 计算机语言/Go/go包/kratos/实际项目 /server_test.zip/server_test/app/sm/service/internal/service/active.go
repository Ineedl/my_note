package service

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/tx7do/kratos-transport/transport/websocket"
	"miyou/app/sm/service/internal/biz"
	v1 "miyou/gen/api/sm/service/v1"
)

type ActiveService struct {
	activeUseCase *biz.ActiveUseCase
	v1.UnimplementedActiveServiceServer
	log *log.Helper
	ws  *websocket.Server
}

func NewActiveService(activeUseCase *biz.ActiveUseCase, logger log.Logger) *ActiveService {
	return &ActiveService{
		activeUseCase: activeUseCase,
		log:           log.NewHelper(log.With(logger, "module", "service.active")),
	}
}
func (this *ActiveService) SetWebsocketServer(ws *websocket.Server) {
	this.ws = ws
}
func (this *ActiveService) CreateActive(ctx context.Context, req *v1.CreateActiveRequest) (*v1.CreateActiveResponse, error) {
	res, err := this.activeUseCase.CreateActive(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *ActiveService) GetActiveList(ctx context.Context, req *v1.GetActiveListRequest) (*v1.GetActiveListResponse, error) {
	res, err := this.activeUseCase.GetActiveList(ctx, req)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *ActiveService) JoinActive(ctx context.Context, req *v1.JoinActiveRequest) (*v1.JoinActiveResponse, error) {
	res, err := this.activeUseCase.JoinActive(ctx, req, this.ws)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *ActiveService) ActiveRemovePeople(ctx context.Context, req *v1.ActiveRemovePeopleRequest) (*v1.ActiveRemovePeopleResponse, error) {
	res, err := this.activeUseCase.ActiveRemovePeople(ctx, req, this.ws)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}

func (this *ActiveService) ActiveStop(ctx context.Context, req *v1.ActiveStopRequest) (*v1.ActiveStopResponse, error) {
	res, err := this.activeUseCase.ActiveStop(ctx, req, this.ws)
	if err != nil {
		return nil, v1.ErrorApiError(err.Error())
	}
	return res, nil
}
