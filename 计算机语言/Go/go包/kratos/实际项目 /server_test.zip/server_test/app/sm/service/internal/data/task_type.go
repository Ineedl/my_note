package data

import (
	"context"
	"github.com/go-kratos/kratos/v2/log"
	"miyou/app/sm/service/internal/biz"
	"miyou/dal/sm/orm/model"
	v1 "miyou/gen/api/sm/service/v1"
)

var _ biz.TaskTypeRepo = (*taskTypeRepo)(nil)

type taskTypeRepo struct {
	data *Data
	log  *log.Helper
}

func NewTaskTypeRepo(data *Data, logger log.Logger) biz.TaskTypeRepo {
	return &taskTypeRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (this *taskTypeRepo) CreateTaskType(ctx context.Context, fr *v1.TaskType) (*v1.TaskType, error) {
	frModel := this.tranProtocToModel(fr)
	err := this.data.genQ.AppTaskType.WithContext(ctx).Create(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *taskTypeRepo) GetTaskTypeById(ctx context.Context, id int32) (*v1.TaskType, error) {
	q := this.data.genQ.AppTaskType
	out, err := q.WithContext(ctx).Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *taskTypeRepo) GetTaskTypeByIdWithDelete(ctx context.Context, id int32) (*v1.TaskType, error) {
	q := this.data.genQ.AppTaskType
	out, err := q.WithContext(ctx).Unscoped().Where(q.ID.Eq(id)).First()
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(out), nil
}

func (this *taskTypeRepo) UpdateTaskType(ctx context.Context, fr *v1.TaskType) (*v1.TaskType, error) {
	q := this.data.genQ.AppTaskType
	frModel := this.tranProtocToModel(fr)
	_, err := q.WithContext(ctx).Where(q.ID.Eq(frModel.ID)).Updates(frModel)
	if err != nil {
		return nil, err
	}
	return this.tranModelToProtoc(frModel), nil
}

func (this *taskTypeRepo) DeleteTaskType(ctx context.Context, id int32) error {
	q := this.data.genQ.AppTaskType
	_, err := q.WithContext(ctx).Where(q.ID.Eq(id)).Delete()
	if err != nil {
		return err
	}
	return nil
}

func (this *taskTypeRepo) GetTaskTypeList(ctx context.Context, uid int32) ([]*v1.TaskType, error) {
	q := this.data.genQ.AppTaskType
	out := make([]*v1.TaskType, 0)
	list, err := q.WithContext(ctx).Where(q.Where(q.MemberID.Eq(uid)).Or(q.MemberID.Eq(0))).Find()
	if err != nil {
		return nil, err
	}
	for _, v := range list {
		out = append(out, this.tranModelToProtoc(v))
	}
	return out, nil
}

func (this *taskTypeRepo) tranProtocToModel(in *v1.TaskType) *model.AppTaskType {
	out := &model.AppTaskType{}
	out.ID = in.TaskTypeId
	out.TaskName = in.TaskName
	out.TaskCycle = in.TaskCycle
	out.TaskDes = in.TaskDes
	out.TaskTypeStartTime = in.TaskTypeStartTime
	out.TaskTypeEndTime = in.TaskTypeEndTime
	out.MemberID = in.MemberId
	return out
}

func (this *taskTypeRepo) tranModelToProtoc(in *model.AppTaskType) *v1.TaskType {
	out := &v1.TaskType{}
	out.TaskTypeId = in.ID
	out.TaskName = in.TaskName
	out.TaskCycle = in.TaskCycle
	out.TaskDes = in.TaskDes
	out.TaskTypeStartTime = in.TaskTypeStartTime
	out.TaskTypeEndTime = in.TaskTypeEndTime
	out.MemberId = in.MemberID
	return out
}
